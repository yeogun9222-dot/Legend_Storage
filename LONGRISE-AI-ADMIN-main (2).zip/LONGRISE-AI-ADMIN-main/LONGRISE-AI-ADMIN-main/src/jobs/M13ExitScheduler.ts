/**
 * M13 EXIT Scheduler
 * 매일 자정 UTC 기준으로 13개월 만기 도달 회원 자동 정산
 */

import { triggerM13ExitAutomation } from '../services/M13ExitService';
import type { Member, M13ExitSettlement } from '../types/M13Exit';

/**
 * 크론 작업: 매일 자정 UTC 실행
 * Cron: "0 0 * * *" (매일 00:00 UTC)
 */
export class M13ExitScheduler {
  private static isRunning = false;
  private static lastRunTime: Date | null = null;
  private static settlements: M13ExitSettlement[] = [];

  /**
   * 스케줄러 초기화
   */
  static async initialize() {
    console.log('⏰ M13 EXIT Scheduler 초기화...');

    // 개발 환경에서는 매일 자정에 실행
    // 프로덕션에서는 실제 크론 작업으로 설정
    this.scheduleDaily();

    console.log('✅ M13 EXIT Scheduler 준비 완료');
    console.log('   실행 시각: 매일 자정 UTC (00:00)');
  }

  /**
   * 일일 스케줄 설정
   */
  private static scheduleDaily() {
    // 다음 자정까지의 시간 계산
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const msUntilMidnight = tomorrow.getTime() - now.getTime();

    console.log(`📅 다음 실행: ${tomorrow.toISOString()}`);

    // 첫 번째 실행 대기
    setTimeout(() => {
      this.execute();

      // 그 후 매일 실행
      setInterval(() => {
        this.execute();
      }, 24 * 60 * 60 * 1000); // 24시간
    }, msUntilMidnight);
  }

  /**
   * M13 EXIT 자동화 실행
   */
  private static async execute() {
    if (this.isRunning) {
      console.log('⚠️  M13 EXIT 이미 실행 중...');
      return;
    }

    this.isRunning = true;
    const startTime = new Date();

    try {
      console.log(`\n🤖 M13 EXIT 자동화 시작: ${startTime.toISOString()}`);

      // 1. 모든 활성 회원 조회 (실제 구현에서는 DB에서 조회)
      const activeMembers = await this.fetchActiveMembers();

      if (activeMembers.length === 0) {
        console.log('ℹ️  활성 회원 없음');
        return;
      }

      // 2. M13 EXIT 자동화 실행
      const result = await triggerM13ExitAutomation(
        activeMembers,
        this.settlements
      );

      // 3. 결과 저장
      this.settlements.push(...result.settlements);

      // 4. 알림 전송 (시뮬레이션)
      await this.sendNotifications(result.notifications);

      // 5. 로그 저장
      await this.saveAuditLogs(result.logs);

      // 6. 회원 상태 업데이트
      await this.updateMemberStatuses(result.settlements);

      const endTime = new Date();
      const duration = endTime.getTime() - startTime.getTime();

      console.log(`\n✅ M13 EXIT 완료:`);
      console.log(`   처리 건수: ${result.processedCount}명`);
      console.log(`   알림 발송: ${result.notifications.length}건`);
      console.log(`   소요 시간: ${duration}ms`);
      console.log(`   완료 시각: ${endTime.toISOString()}\n`);

      this.lastRunTime = endTime;
    } catch (error) {
      console.error('❌ M13 EXIT 실행 오류:', error);
      await this.handleExecutionError(error);
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * 활성 회원 조회 (Mock 데이터)
   */
  private static async fetchActiveMembers(): Promise<Member[]> {
    // 실제 구현에서는 DB에서 조회
    return [
      // M13 도달한 회원 예시
      {
        id: 'member_001',
        userId: 'user_001',
        package: 'VIP' as const,
        joinDate: new Date(new Date().getTime() - 13 * 30 * 24 * 60 * 60 * 1000), // 13개월 전
        status: 'active' as const,
        balance: 5000,
        rank: 'Master Node Level 4'
      },
      {
        id: 'member_002',
        userId: 'user_002',
        package: 'Premium' as const,
        joinDate: new Date(new Date().getTime() - 13 * 30 * 24 * 60 * 60 * 1000),
        status: 'active' as const,
        balance: 1000,
        rank: 'Master Node Level 3'
      }
      // 실제 데이터는 훨씬 많을 것
    ];
  }

  /**
   * 알림 전송
   */
  private static async sendNotifications(notifications: any[]) {
    for (const notif of notifications) {
      try {
        // SMS 알림
        if (notif.type === 'SMS') {
          console.log(`📱 SMS 발송: ${notif.recipient}`);
          // await sendSMS(notif.recipient, notif.message);
        }

        // 이메일 알림
        if (notif.type === 'EMAIL') {
          console.log(`📧 이메일 발송: ${notif.recipient}`);
          // await sendEmail(notif.recipient, 'M13 EXIT 정산 완료', notif.message);
        }

        // 푸시 알림
        if (notif.type === 'PUSH') {
          console.log(`🔔 푸시 발송: ${notif.recipient}`);
          // await sendPushNotification(notif.recipient, notif.message);
        }

        // 인앱 알림
        if (notif.type === 'IN_APP') {
          console.log(`💬 인앱 알림 생성: ${notif.recipient}`);
          // await createInAppNotification(notif.recipient, notif.message);
        }

        notif.status = 'sent';
      } catch (error) {
        console.error(`❌ 알림 실패 (${notif.type}):`, error);
        notif.status = 'failed';
      }
    }
  }

  /**
   * 감사 로그 저장
   */
  private static async saveAuditLogs(logs: any[]) {
    for (const log of logs) {
      console.log(`📝 감사 로그: ${log.memberId} - $${log.finalRefund.toFixed(2)}`);
      // await db.auditLog.create(log);
    }
  }

  /**
   * 회원 상태 업데이트
   */
  private static async updateMemberStatuses(settlements: any[]) {
    for (const settlement of settlements) {
      console.log(`👤 회원 상태 업데이트: ${settlement.memberId} → completed`);
      // await db.members.update(
      //   { id: settlement.memberId },
      //   { status: 'completed', exitDate: new Date() }
      // );
    }
  }

  /**
   * 실행 오류 처리
   */
  private static async handleExecutionError(error: any) {
    // 실패한 정산들을 큐에 저장해서 나중에 재시도
    console.log('🔄 다음 실행 시 재시도 예약됨');
    // await db.m13ExitErrors.create({
    //   timestamp: new Date(),
    //   error: error.message,
    //   status: 'failed'
    // });
  }

  /**
   * 스케줄러 상태 조회
   */
  static getStatus() {
    return {
      isRunning: this.isRunning,
      lastRunTime: this.lastRunTime,
      processedSettlements: this.settlements.length,
      nextRunTime: this.calculateNextRunTime()
    };
  }

  /**
   * 다음 실행 시각 계산
   */
  private static calculateNextRunTime(): Date {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    return tomorrow;
  }

  /**
   * 모든 정산 기록 조회
   */
  static getSettlements() {
    return this.settlements;
  }
}

// 모듈 초기화
if (typeof window === 'undefined') {
  // Node.js 환경에서만 실행
  M13ExitScheduler.initialize();
}

export default M13ExitScheduler;
