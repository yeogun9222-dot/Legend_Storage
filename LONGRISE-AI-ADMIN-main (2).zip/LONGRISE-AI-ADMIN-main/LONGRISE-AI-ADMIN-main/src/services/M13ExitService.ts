/**
 * M13 EXIT Service
 * 13개월 만기 도달 회원의 자동 정산 처리
 */

import { Member, M13ExitSettlement, M13ExitNotification, M13ExitAuditLog } from '../types/M13Exit';

export class M13ExitService {
  /**
   * M13 도달 회원 확인
   * 매일 자정 UTC 기준으로 실행
   */
  static checkM13ExitSchedule(activeMembers: Member[]): Member[] {
    const now = new Date();
    return activeMembers.filter(member => {
      const joinDate = new Date(member.joinDate);

      // 정확한 13개월 후 계산 (월 기반)
      const m13Date = new Date(joinDate);
      const year = joinDate.getFullYear();
      const month = joinDate.getMonth();

      // 13개월 더하기
      let newYear = year;
      let newMonth = month + 13;

      if (newMonth > 11) {
        newYear += Math.floor(newMonth / 12);
        newMonth = newMonth % 12;
      }

      m13Date.setFullYear(newYear);
      m13Date.setMonth(newMonth);

      // 만기 도달했고 아직 정산되지 않은 회원
      return now >= m13Date && member.status === 'active';
    });
  }

  /**
   * 최종 정산 계산 (15% 최소보장 포함)
   */
  static calculateM13Settlement(
    member: Member,
    principalAmount: number
  ): M13ExitSettlement {
    const joinDate = new Date(member.joinDate);
    const m13Date = new Date(joinDate);
    m13Date.setMonth(m13Date.getMonth() + 13);
    const monthsElapsed = 13;

    // 패키지별 비율
    const usedtRates: Record<string, number> = {
      Flexible: 4,
      Basic: 7,
      Standard: 9,
      Premium: 11,
      VIP: 18
    };

    const cnytRatios: Record<string, number> = {
      Flexible: 2,
      Basic: 2,
      Standard: 4,
      Premium: 6,
      VIP: 10
    };

    const usedtRate = usedtRates[member.package] || 9;
    const cnytRatio = cnytRatios[member.package] || 4;

    // 지출 계산
    const usdt = (principalAmount * usedtRate * monthsElapsed) / 100;
    const cnyt = (principalAmount * cnytRatio * monthsElapsed) / 100;
    const directBonus = principalAmount * 0.12;
    const rollupBonus = usdt * 0.1111;
    const globalPool = (usdt + cnyt) * 0.02;
    const totalExpense = usdt + cnyt + directBonus + rollupBonus + globalPool;

    // M13는 만기 도달이므로 추가 수수료 없음
    const earlyExitFee = 0;

    // 기본 환급액 계산
    const basicRefund = principalAmount - totalExpense - earlyExitFee;

    // 15% 최소보장
    const minimumRefund = principalAmount * 0.15;
    const finalRefund = Math.max(basicRefund, minimumRefund);
    const companyLoss = Math.min(0, basicRefund - minimumRefund);

    const settlement: M13ExitSettlement = {
      id: `m13_${member.id}_${Date.now()}`,
      memberId: member.id,
      joinDate,
      m13Date,
      principal: principalAmount,
      package: member.package,
      usdt: Math.round(usdt * 100) / 100,
      cnyt: Math.round(cnyt * 100) / 100,
      directBonus: Math.round(directBonus * 100) / 100,
      rollupBonus: Math.round(rollupBonus * 100) / 100,
      globalPool: Math.round(globalPool * 100) / 100,
      totalExpense: Math.round(totalExpense * 100) / 100,
      basicRefund: Math.round(basicRefund * 100) / 100,
      minimumRefund: Math.round(minimumRefund * 100) / 100,
      finalRefund: Math.round(finalRefund * 100) / 100,
      floorApplied: finalRefund > basicRefund,
      companyLoss: Math.round(companyLoss * 100) / 100,
      status: 'completed'
    };

    return settlement;
  }

  /**
   * M13 EXIT 회원 자동 알림 생성
   */
  static createM13Notifications(
    settlement: M13ExitSettlement,
    memberEmail: string,
    memberPhone: string
  ): M13ExitNotification[] {
    const timestamp = new Date();
    const message = `🎉 축하합니다! LONGRISE 프로그램 13개월 만기 도달\n\n💰 최종 환급액: $${settlement.finalRefund.toFixed(2)}\n📅 정산일: ${timestamp.toLocaleDateString('ko-KR')}\n\n🔄 다음 단계:\n1. 본인 대시보드에서 출금 신청하기\n2. 관리자 검증 (1-2영업일)\n3. 환급액 입금`;

    return [
      // SMS 알림
      {
        id: `notif_sms_${settlement.id}`,
        memberId: settlement.memberId,
        type: 'SMS',
        status: 'pending',
        recipient: memberPhone,
        message: `[LONGRISE] M13 정산 완료! 환급액: $${settlement.finalRefund.toFixed(2)}`
      },
      // 이메일 알림
      {
        id: `notif_email_${settlement.id}`,
        memberId: settlement.memberId,
        type: 'EMAIL',
        status: 'pending',
        recipient: memberEmail,
        message
      },
      // 푸시 알림
      {
        id: `notif_push_${settlement.id}`,
        memberId: settlement.memberId,
        type: 'PUSH',
        status: 'pending',
        recipient: settlement.memberId,
        message: `M13 EXIT 정산 완료: $${settlement.finalRefund.toFixed(2)} 환급`
      },
      // 인앱 알림
      {
        id: `notif_inapp_${settlement.id}`,
        memberId: settlement.memberId,
        type: 'IN_APP',
        status: 'pending',
        recipient: settlement.memberId,
        message
      }
    ];
  }

  /**
   * 감사 로그 생성
   */
  static createAuditLog(
    settlement: M13ExitSettlement,
    member: Member
  ): M13ExitAuditLog {
    return {
      id: `audit_${settlement.id}`,
      action: 'M13_EXIT_PROCESSED',
      timestamp: new Date(),
      memberId: member.id,
      package: member.package,
      joinDate: settlement.joinDate,
      m13Date: settlement.m13Date,
      finalRefund: settlement.finalRefund,
      executedBy: 'SYSTEM_AUTO',
      ipAddress: '127.0.0.1'
    };
  }

  /**
   * 멱등성 검사 - 중복 처리 방지
   */
  static async checkDuplicateProcessing(
    memberId: string,
    settlementLog: M13ExitSettlement[]
  ): Promise<boolean> {
    return settlementLog.some(
      s => s.memberId === memberId && s.status === 'completed'
    );
  }

  /**
   * 회원 상태 업데이트
   */
  static updateMemberStatus(member: Member): Member {
    return {
      ...member,
      status: 'completed'
    };
  }

  /**
   * 오류 복구 - 실패한 M13 EXIT 재시도
   */
  static async retryFailedM13Exits(
    failedSettlements: M13ExitSettlement[]
  ): Promise<M13ExitSettlement[]> {
    return failedSettlements
      .filter(s => s.status === 'error')
      .map(s => ({
        ...s,
        status: 'pending' as const
      }));
  }
}

/**
 * M13 EXIT 실행 엔진 (메인 함수)
 */
export async function triggerM13ExitAutomation(
  activeMembers: Member[],
  existingSettlements: M13ExitSettlement[] = []
): Promise<{
  processedCount: number;
  settlements: M13ExitSettlement[];
  notifications: M13ExitNotification[];
  logs: M13ExitAuditLog[];
}> {
  console.log('🤖 M13 EXIT 자동화 시작...');

  const service = M13ExitService;
  const m13Members = service.checkM13ExitSchedule(activeMembers);

  console.log(`🔔 M13 도달 회원: ${m13Members.length}명`);

  const settlements: M13ExitSettlement[] = [];
  const notifications: M13ExitNotification[] = [];
  const logs: M13ExitAuditLog[] = [];

  for (const member of m13Members) {
    try {
      // 중복 처리 확인
      const isDuplicate = await service.checkDuplicateProcessing(
        member.id,
        existingSettlements
      );

      if (isDuplicate) {
        console.log(`⚠️  이미 정산됨: ${member.id}`);
        continue;
      }

      // 정산 계산
      const settlement = service.calculateM13Settlement(member, member.balance);
      settlements.push(settlement);

      // 알림 생성
      const memberNotifications = service.createM13Notifications(
        settlement,
        `${member.userId}@example.com`,
        '+82-010-0000-0000'
      );
      notifications.push(...memberNotifications);

      // 로그 생성
      const log = service.createAuditLog(settlement, member);
      logs.push(log);

      console.log(
        `✅ ${member.id} 정산 완료: $${settlement.finalRefund.toFixed(2)}`
      );
    } catch (error) {
      console.error(`❌ ${member.id} 정산 오류:`, error);
    }
  }

  return {
    processedCount: settlements.length,
    settlements,
    notifications,
    logs
  };
}
