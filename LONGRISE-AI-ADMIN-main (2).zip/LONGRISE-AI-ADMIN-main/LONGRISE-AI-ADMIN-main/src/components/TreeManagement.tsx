/**
 * Tree Management Component
 * 관리자용 조직도 데이터 관리 및 문제 해결
 *
 * 기능:
 * - 조직도 구조 관리 (후원자 변경, 직급 관제)
 * - 문제 해결 (고아 구성원, 중복 구조)
 * - 성과 분석 (팀 볼륨, 직급별 성과)
 */

import { useState } from 'react';
import {
  Network,
  Search,
  AlertTriangle,
  ArrowRight,
  User,
  Users,
  TrendingUp,
  Edit3,
  Check,
  X,
  Merge,
  Trash2,
  Award,
  BarChart3,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { MOCK_USERS } from '../lib/mockData';
import { recordAuditLog } from '../lib/auditLogger';

type TabType = 'structure' | 'troubleshoot' | 'analytics';

interface TreeNode {
  id: string;
  nickname: string;
  rank: string;
  sponsorId: string;
  teamSize: number;
  teamVol: number;
  bodyValue: number;
  status: string;
}

interface OrphanNode {
  id: string;
  nickname: string;
  currentSponsors: string[];
  teamSize: number;
}

const MOCK_ADMIN = { id: 'admin_001', name: '제이크 (조직도 관리)' };

export function TreeManagement() {
  const [activeTab, setActiveTab] = useState<TabType>('structure');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNode, setSelectedNode] = useState<TreeNode | null>(null);
  const [newSponsorId, setNewSponsorId] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  // 트리 데이터 준비
  const treeNodes: TreeNode[] = MOCK_USERS.map(u => ({
    id: u.id,
    nickname: u.nickname,
    rank: u.rank,
    sponsorId: u.sponsorId,
    teamSize: u.teamSize,
    teamVol: u.teamVol,
    bodyValue: u.bodyValue,
    status: u.status,
  }));

  // 통계 계산
  const stats = {
    totalMembers: treeNodes.length,
    activeCount: treeNodes.filter(n => n.status === 'Active').length,
    orphanCount: treeNodes.filter(n => !treeNodes.find(t => t.id === n.sponsorId)).length,
    avgTeamDepth: Math.round(
      treeNodes.reduce((acc, n) => acc + (n.teamSize > 0 ? Math.log(n.teamSize) : 0), 0) / treeNodes.length
    ),
    maxTeamVolume: Math.max(...treeNodes.map(n => n.teamVol)),
  };

  // 조직 트리 필터링
  const getFilteredNodes = () => {
    return treeNodes.filter(n =>
      n.nickname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.id.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // 후원자 변경 처리
  const handleSponsorChange = (node: TreeNode, newSponsor: string) => {
    const updatedNodes = treeNodes.map(n =>
      n.id === node.id ? { ...n, sponsorId: newSponsor } : n
    );

    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '후원자 변경',
      'tree_structure',
      node.id,
      {
        nickname: node.nickname,
        before: { sponsorId: node.sponsorId },
        after: { sponsorId: newSponsor },
      }
    );

    setSelectedNode(null);
    setNewSponsorId('');
    setIsEditing(false);
    alert(`✅ ${node.nickname}의 후원자가 변경되었습니다.`);
  };

  // 직급 강제 변경
  const handleRankChange = (node: TreeNode, newRank: string) => {
    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '직급 강제 변경',
      'member_rank',
      node.id,
      {
        nickname: node.nickname,
        before: { rank: node.rank },
        after: { rank: newRank },
      }
    );

    alert(`✅ ${node.nickname}의 직급이 ${newRank}로 변경되었습니다.`);
  };

  // 고아 구성원 찾기
  const getOrphanNodes = (): OrphanNode[] => {
    return treeNodes
      .filter(n => !treeNodes.find(t => t.id === n.sponsorId))
      .map(n => ({
        id: n.id,
        nickname: n.nickname,
        currentSponsors: treeNodes.filter(t => t.sponsorId === n.id).map(t => t.nickname),
        teamSize: n.teamSize,
      }));
  };

  // 고아 구성원 병합
  const handleMergeOrphan = (orphan: OrphanNode, targetSponsor: string) => {
    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '고아 구성원 병합',
      'tree_structure',
      orphan.id,
      {
        nickname: orphan.nickname,
        action: 'merge_orphan',
        newSponsor: targetSponsor,
        affectedSubordinates: orphan.currentSponsors.length,
      }
    );

    alert(`✅ ${orphan.nickname}을(를) 조직도에 병합했습니다.`);
  };

  const filteredNodes = getFilteredNodes();
  const orphanNodes = getOrphanNodes();

  return (
    <div className="space-y-6 px-6 pb-12">
      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <div className="dashboard-card border-border-main p-4">
          <h4 className="text-[8px] font-black text-text-muted uppercase tracking-widest mb-2">전체 회원</h4>
          <p className="text-xl font-black text-text-primary tabular-nums">{stats.totalMembers}</p>
        </div>
        <div className="dashboard-card border-accent-green/30 bg-accent-green/5 p-4">
          <h4 className="text-[8px] font-black text-accent-green uppercase tracking-widest mb-2">활성</h4>
          <p className="text-xl font-black text-accent-green tabular-nums">{stats.activeCount}</p>
        </div>
        <div className="dashboard-card border-red-500/30 bg-red-500/5 p-4">
          <h4 className="text-[8px] font-black text-red-500 uppercase tracking-widest mb-2">고아</h4>
          <p className="text-xl font-black text-red-500 tabular-nums">{stats.orphanCount}</p>
        </div>
        <div className="dashboard-card border-accent-amber/30 bg-accent-amber/5 p-4">
          <h4 className="text-[8px] font-black text-accent-amber uppercase tracking-widest mb-2">평균 깊이</h4>
          <p className="text-xl font-black text-accent-amber tabular-nums">{stats.avgTeamDepth}</p>
        </div>
        <div className="dashboard-card border-accent-blue/30 bg-accent-blue/5 p-4">
          <h4 className="text-[8px] font-black text-accent-blue uppercase tracking-widest mb-2">최대 볼륨</h4>
          <p className="text-xl font-black text-accent-blue tabular-nums">${(stats.maxTeamVolume / 1000).toFixed(0)}K</p>
        </div>
      </div>

      {/* 탭 네비게이션 */}
      <div className="dashboard-card border-border-main p-0 overflow-hidden">
        <div className="flex border-b border-border-main bg-black/10">
          <button
            onClick={() => setActiveTab('structure')}
            className={cn(
              'flex-1 py-4 px-6 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors flex items-center justify-center gap-2',
              activeTab === 'structure'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-text-muted hover:text-text-primary'
            )}
          >
            <Network size={16} /> 조직도 관리
          </button>
          <button
            onClick={() => setActiveTab('troubleshoot')}
            className={cn(
              'flex-1 py-4 px-6 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors flex items-center justify-center gap-2',
              activeTab === 'troubleshoot'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-text-muted hover:text-text-primary'
            )}
          >
            <AlertTriangle size={16} /> 문제 해결
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={cn(
              'flex-1 py-4 px-6 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors flex items-center justify-center gap-2',
              activeTab === 'analytics'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-text-muted hover:text-text-primary'
            )}
          >
            <BarChart3 size={16} /> 성과 분석
          </button>
        </div>

        <div className="p-6">
          {/* 탭 1: 조직도 관리 */}
          {activeTab === 'structure' && (
            <div className="space-y-6">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3 text-text-muted" />
                <input
                  type="text"
                  placeholder="회원명, ID 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-blue/50"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="data-table w-full">
                  <thead>
                    <tr>
                      <th className="text-[10px]">회원명</th>
                      <th className="text-[10px]">직급</th>
                      <th className="text-[10px]">후원자</th>
                      <th className="text-[10px]">팀 규모</th>
                      <th className="text-[10px]">팀 볼륨</th>
                      <th className="text-right text-[10px]">작업</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredNodes.map(node => (
                      <tr key={node.id} className="hover:bg-white/[0.02]">
                        <td>
                          <div className="flex flex-col">
                            <span className="text-[11px] font-bold text-text-primary">{node.nickname}</span>
                            <span className="text-[9px] text-text-muted">{node.id}</span>
                          </div>
                        </td>
                        <td>
                          <span className="text-[10px] font-bold text-accent-amber">{node.rank}</span>
                        </td>
                        <td>
                          <span className="text-[9px] text-text-muted font-mono">
                            {treeNodes.find(n => n.id === node.sponsorId)?.nickname || '(없음)'}
                          </span>
                        </td>
                        <td>
                          <span className="text-[10px] font-mono text-text-primary">{node.teamSize}명</span>
                        </td>
                        <td>
                          <span className="text-[10px] font-mono text-accent-blue">${node.teamVol.toLocaleString()}</span>
                        </td>
                        <td className="text-right">
                          <button
                            onClick={() => {
                              setSelectedNode(node);
                              setIsEditing(true);
                            }}
                            className="p-2 rounded hover:bg-white/5 transition-colors text-text-muted hover:text-accent-blue"
                          >
                            <Edit3 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {selectedNode && isEditing && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                  <div className="bg-[#020617] border border-border-main rounded-lg w-full max-w-md p-6 shadow-2xl">
                    <h3 className="text-lg font-bold text-text-primary uppercase tracking-wider mb-6">
                      {selectedNode.nickname} - 구조 변경
                    </h3>

                    <div className="space-y-6">
                      {/* 후원자 변경 */}
                      <div>
                        <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-3 block">
                          후원자 변경
                        </label>
                        <select
                          value={newSponsorId}
                          onChange={(e) => setNewSponsorId(e.target.value)}
                          className="w-full bg-black/30 border border-border-main rounded px-3 py-2 text-[11px] text-text-primary focus:outline-none focus:border-accent-blue/50"
                        >
                          <option value="">선택하세요...</option>
                          {treeNodes
                            .filter(n => n.id !== selectedNode.id)
                            .map(n => (
                              <option key={n.id} value={n.id}>
                                {n.nickname} ({n.rank})
                              </option>
                            ))}
                        </select>
                        <p className="text-[9px] text-text-muted mt-2">
                          현재: {treeNodes.find(n => n.id === selectedNode.sponsorId)?.nickname || '없음'}
                        </p>
                      </div>

                      {/* 직급 변경 */}
                      <div>
                        <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-3 block">
                          직급 강제 변경
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {['Investor', 'White Dragon', 'Blue Dragon', 'Purple Dragon', 'Red Dragon', 'Black Dragon'].map(
                            rank => (
                              <button
                                key={rank}
                                onClick={() => handleRankChange(selectedNode, rank)}
                                className={cn(
                                  'p-2 rounded border text-[9px] font-bold uppercase tracking-widest transition-colors',
                                  selectedNode.rank === rank
                                    ? 'border-accent-blue bg-accent-blue/20 text-accent-blue'
                                    : 'border-border-main bg-black/20 text-text-muted hover:text-text-primary'
                                )}
                              >
                                {rank}
                              </button>
                            )
                          )}
                        </div>
                      </div>

                      {/* 액션 버튼 */}
                      <div className="flex gap-3 pt-4">
                        <button
                          onClick={() => {
                            if (newSponsorId) {
                              handleSponsorChange(selectedNode, newSponsorId);
                            } else {
                              alert('후원자를 선택해주세요.');
                            }
                          }}
                          className="flex-1 px-4 py-2 rounded bg-accent-blue text-white text-[10px] font-bold hover:bg-accent-blue/80 transition-colors flex items-center justify-center gap-2"
                        >
                          <Check size={14} /> 적용
                        </button>
                        <button
                          onClick={() => {
                            setSelectedNode(null);
                            setIsEditing(false);
                            setNewSponsorId('');
                          }}
                          className="flex-1 px-4 py-2 rounded border border-border-main bg-black/30 text-text-primary text-[10px] font-bold hover:bg-black/50 transition-colors flex items-center justify-center gap-2"
                        >
                          <X size={14} /> 취소
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 탭 2: 문제 해결 */}
          {activeTab === 'troubleshoot' && (
            <div className="space-y-6">
              <div className="dashboard-card border-red-500/20 bg-red-500/5 p-6">
                <h3 className="text-sm font-bold text-red-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <AlertTriangle size={16} /> 고아 구성원 ({orphanNodes.length}명)
                </h3>

                {orphanNodes.length === 0 ? (
                  <p className="text-[11px] text-text-muted">고아 구성원이 없습니다.</p>
                ) : (
                  <div className="space-y-3">
                    {orphanNodes.map(orphan => (
                      <div
                        key={orphan.id}
                        className="flex items-center justify-between p-4 bg-black/30 rounded border border-red-500/30"
                      >
                        <div>
                          <p className="text-[11px] font-bold text-text-primary">{orphan.nickname}</p>
                          <p className="text-[9px] text-text-muted mt-1">
                            하위 구성원: {orphan.currentSponsors.length}명
                          </p>
                        </div>
                        <button
                          onClick={() =>
                            handleMergeOrphan(orphan, treeNodes[0].id) // 첫 번째 활성 회원에 병합
                          }
                          className="px-3 py-1.5 rounded bg-red-500/20 text-red-400 text-[9px] font-bold hover:bg-red-500/30 transition-colors flex items-center gap-1"
                        >
                          <Merge size={12} /> 병합
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="dashboard-card border-accent-amber/20 bg-accent-amber/5 p-6">
                <h3 className="text-sm font-bold text-accent-amber uppercase tracking-wider mb-4">
                  📊 조직도 정상성 검사
                </h3>
                <div className="space-y-2 text-[10px] text-text-muted">
                  <div className="flex items-center justify-between p-2 bg-black/20 rounded">
                    <span>순환 참조 검사</span>
                    <span className="text-accent-green font-bold">✓ PASS</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-black/20 rounded">
                    <span>중복 직급 검사</span>
                    <span className="text-accent-green font-bold">✓ PASS</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-black/20 rounded">
                    <span>데이터 무결성</span>
                    <span className="text-accent-green font-bold">✓ PASS</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 탭 3: 성과 분석 */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 직급별 성과 */}
                <div className="dashboard-card border-border-main p-6">
                  <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Award size={16} /> 직급별 현황
                  </h3>
                  <div className="space-y-2">
                    {['Black Dragon', 'Red Dragon', 'Purple Dragon', 'Blue Dragon', 'White Dragon', 'Investor'].map(
                      rank => {
                        const count = treeNodes.filter(n => n.rank === rank).length;
                        const totalVol = treeNodes
                          .filter(n => n.rank === rank)
                          .reduce((acc, n) => acc + n.teamVol, 0);
                        return (
                          <div key={rank} className="flex items-center justify-between p-2 bg-black/20 rounded">
                            <span className="text-[10px] font-bold text-text-primary">{rank}</span>
                            <div className="flex items-center gap-4 text-[9px] text-text-muted">
                              <span>{count}명</span>
                              <span className="text-accent-blue font-bold">${(totalVol / 1000).toFixed(0)}K</span>
                            </div>
                          </div>
                        );
                      }
                    )}
                  </div>
                </div>

                {/* 팀 규모 분포 */}
                <div className="dashboard-card border-border-main p-6">
                  <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Users size={16} /> 팀 규모 분포
                  </h3>
                  <div className="space-y-2">
                    {[
                      { label: '0-10명', min: 0, max: 10 },
                      { label: '11-100명', min: 11, max: 100 },
                      { label: '101-1000명', min: 101, max: 1000 },
                      { label: '1000명+', min: 1001, max: Infinity },
                    ].map(range => {
                      const count = treeNodes.filter(n => n.teamSize >= range.min && n.teamSize <= range.max).length;
                      return (
                        <div key={range.label} className="flex items-center justify-between p-2 bg-black/20 rounded">
                          <span className="text-[10px] font-bold text-text-primary">{range.label}</span>
                          <span className="text-[9px] text-accent-green font-bold">{count}명</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 상위 10개 팀 */}
              <div className="dashboard-card border-border-main p-6">
                <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
                  <TrendingUp size={16} /> 상위 10개 팀 (볼륨 기준)
                </h3>
                <div className="overflow-x-auto">
                  <table className="data-table w-full text-[10px]">
                    <thead>
                      <tr>
                        <th>순위</th>
                        <th>회원명</th>
                        <th>직급</th>
                        <th>팀 규모</th>
                        <th>팀 볼륨</th>
                      </tr>
                    </thead>
                    <tbody>
                      {treeNodes
                        .sort((a, b) => b.teamVol - a.teamVol)
                        .slice(0, 10)
                        .map((node, idx) => (
                          <tr key={node.id}>
                            <td className="font-bold text-accent-amber">#{idx + 1}</td>
                            <td className="font-bold">{node.nickname}</td>
                            <td className="text-accent-green">{node.rank}</td>
                            <td>{node.teamSize}명</td>
                            <td className="text-accent-blue font-mono">${node.teamVol.toLocaleString()}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
