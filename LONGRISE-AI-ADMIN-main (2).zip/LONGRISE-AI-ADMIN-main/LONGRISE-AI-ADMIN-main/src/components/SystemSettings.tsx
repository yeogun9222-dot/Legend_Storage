import { useState } from 'react';
import { 
  Settings, 
  ShieldAlert, 
  Power, 
  RefreshCw, 
  Globe, 
  Database, 
  Cpu, 
  Lock,
  Eye,
  Bell
} from 'lucide-react';
import { cn } from '../lib/utils';

export function SystemSettings() {
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [emergencyLock, setEmergencyLock] = useState(false);
  const [cnytBasePrice, setCnytBasePrice] = useState(0.01); // 기본 $0.01 고정
  const [cnytCustomPrice, setCnytCustomPrice] = useState(0.01); // 관리자 수동 가격
  const [showCnytUpdate, setShowCnytUpdate] = useState(false);

  const handleCnytPriceUpdate = () => {
    if (cnytCustomPrice >= 0.01 && cnytCustomPrice <= 10) {
      setCnytBasePrice(cnytCustomPrice);
      setShowCnytUpdate(false);
      alert(`✅ CNYT 가격이 $${cnytCustomPrice.toFixed(2)}로 업데이트되었습니다.`);
    } else {
      alert('⚠️ CNYT 가격은 $0.01~$10.00 범위 내에서만 설정 가능합니다.');
    }
  };

  return (
    <div className="space-y-6 px-6 pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Global Toggles */}
        <div className="lg:col-span-2 space-y-6">
          <div className="dashboard-card border-border-main">
            <div className="flex items-center gap-2 mb-6 border-b border-border-main pb-4">
              <Settings size={18} className="text-accent-blue" />
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">플랫폼 핵심 인프라 제어 (CPI)</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <ControlToggle 
                  label="전체 점검 모드" 
                  desc="관리자를 제외한 모든 사용자의 접속을 차단하고 점검 화면을 표시합니다."
                  active={maintenanceMode}
                  onToggle={() => setMaintenanceMode(!maintenanceMode)}
                  urgent
                />
                <ControlToggle 
                  label="출금 게이트웨이 잠금" 
                  desc="모든 외부 블록체인 트랜잭션 전송을 즉시 중단합니다."
                  active={emergencyLock}
                  onToggle={() => setEmergencyLock(!emergencyLock)}
                  urgent
                />
              </div>
              <div className="space-y-4">
                 <ControlToggle 
                    label="P2P 거래 샌드박스" 
                    desc="인증된 노드 사용자만 P2P 마켓에 접근할 수 있도록 제한합니다."
                    active={true}
                    onToggle={() => {}}
                  />
                  <ControlToggle 
                    label="스마트 컨트랙트 자동 감사" 
                    desc="노드 정산 바이트코드의 실시간 무결성 검증을 수행합니다."
                    active={true}
                    onToggle={() => {}}
                  />
              </div>
            </div>
          </div>

          <div className="dashboard-card border-border-main p-0 overflow-hidden">
             <div className="p-6 border-b border-border-main bg-black/10">
                <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">API 및 통합 키 관리자 (Key-Manager)</h3>
             </div>
             <div className="p-6 space-y-4">
                <ApiKeyRow label="ETH/BTC 인덱스 RPC" state="연결됨" latency="42ms" />
                <ApiKeyRow label="KYC 검증 엔진 (PageFace)" state="활성" latency="105ms" />
                <ApiKeyRow label="CloudFlare Firewall V3" state="우회됨" latency="0ms" warning />
             </div>
          </div>

          {/* CNYT 가격 관리 (제인의 요구사항 #1) */}
          <div className="dashboard-card border-accent-amber/20 bg-accent-amber/5">
             <div className="flex items-center gap-2 mb-6 pb-4 border-b border-accent-amber/20">
                <Globe size={18} className="text-accent-amber" />
                <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">CNYT 토큰 가격 관리</h3>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 현재 기본 가격 */}
                <div className="p-4 bg-black/30 border border-accent-amber/20 rounded-lg">
                   <p className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2">현재 시스템 기본가</p>
                   <div className="text-2xl font-bold text-accent-amber tabular-nums">${cnytBasePrice.toFixed(2)}</div>
                   <p className="text-[9px] text-text-muted mt-2">시스템 기준 가격 (고정: $0.01)</p>
                </div>

                {/* 가격 수정 */}
                <div className="space-y-3">
                   <div className="p-4 bg-black/30 border border-border-main rounded-lg">
                      <label className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2 block">
                         수동 가격 업데이트 ($0.01~$10.00)
                      </label>
                      <div className="flex gap-2 items-center">
                         <span className="text-sm font-bold text-text-primary">$</span>
                         <input
                            type="number"
                            min="0.01"
                            max="10.00"
                            step="0.01"
                            value={cnytCustomPrice}
                            onChange={(e) => setCnytCustomPrice(parseFloat(e.target.value) || 0.01)}
                            className="flex-1 bg-black/40 border border-border-main rounded px-3 py-2 text-sm font-bold text-accent-amber outline-none focus:border-accent-amber/50"
                         />
                      </div>
                      <button
                         onClick={handleCnytPriceUpdate}
                         className="w-full mt-3 py-2 bg-accent-amber/20 hover:bg-accent-amber/30 border border-accent-amber/40 text-accent-amber text-[10px] font-black uppercase tracking-widest rounded transition-all"
                      >
                         가격 즉시 반영
                      </button>
                   </div>
                </div>
             </div>

             <div className="mt-4 p-3 bg-black/50 border border-accent-amber/20 rounded text-[9px] text-text-muted leading-relaxed">
                <strong>⚡ 주의:</strong> CNYT 가격 변경 시 모든 회원의 초기 CNYT 지급액이 자동으로 재계산됩니다.
                공정성을 위해 가입 시점 무관 동일 USD 가치가 보장됩니다.
             </div>
          </div>
        </div>

        {/* System Health & Resources */}
        <div className="space-y-6">
          <div className="dashboard-card border-border-main bg-accent-blue/5">
            <h3 className="text-[10px] font-black text-accent-blue uppercase tracking-[0.2em] mb-4">리소스 점유율 현황</h3>
            <div className="space-y-4">
              <ResourceBar label="CPU 부하율" percent={42} />
              <ResourceBar label="메모리 사용량" percent={78} />
              <ResourceBar label="DB 동시 연결" percent={12} />
              <ResourceBar label="DLQ 큐 크기" percent={2} />
            </div>
            <button className="w-full mt-6 py-2 bg-accent-blue/10 border border-accent-blue/30 text-accent-blue text-[9px] font-black uppercase tracking-widest hover:bg-accent-blue/20 transition-all rounded">
              강제 GC / 캐시 퍼지 실행
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ControlToggle({ label, desc, active, onToggle, urgent }: any) {
  return (
    <div className="p-4 bg-black/20 border border-border-main rounded-lg flex items-center justify-between group">
      <div className="pr-4">
        <p className={cn("text-xs font-bold uppercase tracking-tight", urgent ? "text-red-400" : "text-text-primary")}>{label}</p>
        <p className="text-[9px] text-text-muted mt-1 leading-tight font-medium italic">{desc}</p>
      </div>
      <button 
        onClick={onToggle}
        className={cn(
          "w-10 h-5 rounded-full relative transition-all shrink-0",
          active ? (urgent ? "bg-red-500" : "bg-accent-green") : "bg-slate-700"
        )}
      >
        <div className={cn(
          "absolute top-1 w-3 h-3 rounded-full bg-white transition-all shadow-sm",
          active ? "right-1" : "left-1"
        )} />
      </button>
    </div>
  );
}

function ResourceBar({ label, percent }: any) {
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-[10px] font-bold">
        <span className="text-text-muted uppercase">{label}</span>
        <span className="text-text-primary">{percent}%</span>
      </div>
      <div className="h-1 bg-black/30 rounded-full overflow-hidden">
        <div 
          className={cn("h-full transition-all duration-1000", percent > 80 ? "bg-red-500" : "bg-accent-blue")} 
          style={{ width: `${percent}%` }} 
        />
      </div>
    </div>
  );
}

function ApiKeyRow({ label, state, latency, warning }: any) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
      <div className="flex items-center gap-3">
        <div className={cn("w-2 h-2 rounded-full", warning ? "bg-amber-500 animate-pulse" : "bg-accent-green")} />
        <span className="text-[11px] font-bold text-text-primary uppercase tracking-tight">{label}</span>
      </div>
      <div className="flex items-center gap-4">
        <span className="text-[10px] font-mono text-text-muted">{latency}</span>
        <span className={cn("text-[9px] font-black uppercase tracking-widest", warning ? "text-amber-500" : "text-text-muted")}>{state}</span>
      </div>
    </div>
  );
}
