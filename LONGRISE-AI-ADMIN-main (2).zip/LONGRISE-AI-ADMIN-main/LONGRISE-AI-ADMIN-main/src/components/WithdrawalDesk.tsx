import { ClipboardCheck, Clock, ShieldCheck, CheckCircle2, XCircle, AlertCircle, HelpCircle, Search, Filter, TrendingUp, Zap } from 'lucide-react';
import { WithdrawalRequest } from '../types';
import { useState } from 'react';
import { cn } from '../lib/utils';
import { recordAuditLog } from '../lib/auditLogger';

const MOCK_ADMIN = { id: 'admin_001', name: '설리 (출금 관리자)' };

const REJECTION_REASONS = [
  '지갑 주소 미등록',
  '이상 거래 탐지',
  '한도 초과',
  '서류 부족',
  '기타'
];

export function WithdrawalDesk({ withdrawals }: { withdrawals: WithdrawalRequest[] }) {
  const [showProcessGuide, setShowProcessGuide] = useState(false);
  const [requestsData, setRequestsData] = useState<Array<WithdrawalRequest & { status: 'pending' | 'approved' | 'rejected'; autoApproved?: boolean }>>(() =>
    withdrawals.map(w => ({ ...w, status: 'pending' as const }))
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedRequest, setSelectedRequest] = useState<(typeof requestsData)[0] | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [successMessage, setSuccessMessage] = useState<{ id: string; action: string } | null>(null);

  // 필터링
  const filteredRequests = requestsData.filter(w => {
    const matchesSearch = searchTerm === '' ||
      w.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.withdrawalId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = statusFilter === 'all' || w.status === statusFilter;
    return matchesSearch && matchesFilter;
  });

  // 통계
  const stats = {
    pending: requestsData.filter(w => w.status === 'pending').length,
    approved: requestsData.filter(w => w.status === 'approved').length,
    rejected: requestsData.filter(w => w.status === 'rejected').length,
    totalAmount: requestsData.filter(w => w.status === 'approved').reduce((sum, w) => sum + w.amount, 0),
  };

  // 자동 승인 판정 (소액: $5,000 이하)
  const shouldAutoApprove = (amount: number) => amount <= 5000;

  // 승인
  const handleApprove = (request: typeof requestsData[0]) => {
    const isAuto = shouldAutoApprove(request.amount);
    const updatedRequests = requestsData.map(w =>
      w.id === request.id
        ? { ...w, status: 'approved' as const, autoApproved: isAuto }
        : w
    );
    setRequestsData(updatedRequests);

    // 감사 로그
    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '출금 승인',
      'withdrawal',
      request.userId,
      {
        before: { status: 'pending' },
        after: { status: 'approved', autoApproved: isAuto },
        amount: request.amount,
      }
    );

    setSuccessMessage({ id: request.id, action: '승인됨' });
    setTimeout(() => setSuccessMessage(null), 3000);
    setSelectedRequest(null);
  };

  // 반려
  const handleReject = (request: typeof requestsData[0]) => {
    const updatedRequests = requestsData.map(w =>
      w.id === request.id
        ? { ...w, status: 'rejected' as const }
        : w
    );
    setRequestsData(updatedRequests);

    // 감사 로그
    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '출금 반려',
      'withdrawal',
      request.userId,
      {
        before: { status: 'pending' },
        after: { status: 'rejected', reason: rejectionReason },
        amount: request.amount,
      }
    );

    setSuccessMessage({ id: request.id, action: '반려됨' });
    setTimeout(() => setSuccessMessage(null), 3000);
    setSelectedRequest(null);
    setRejectionReason('');
  };

  const getSeverityColor = (amount: number) => {
    if (amount > 10000) return 'text-red-500 bg-red-500/10 border-red-500/30';
    if (amount > 5000) return 'text-accent-amber bg-accent-amber/10 border-accent-amber/30';
    return 'text-accent-green bg-accent-green/10 border-accent-green/30';
  };

  return (
    <div className="space-y-6 px-6 pb-12">
       {/* 프로세스 가이드 */}
       <div className="bg-accent-blue/5 border border-accent-blue/20 rounded-lg p-4">
         <div className="flex items-start justify-between gap-4">
           <div className="flex gap-3 flex-1">
             <HelpCircle size={18} className="text-accent-blue shrink-0 mt-0.5" />
             <div className="min-w-0">
               <h3 className="text-sm font-bold text-text-primary mb-2">출금 프로세스 (설리의 검증 기준)</h3>
               <p className="text-[10px] text-text-muted leading-relaxed mb-3">
                 <strong>✅ 관리자 역할:</strong> 회원이 신청한 '출금 요청'에 대해 [승인] 또는 [반려]만 처리 |
                 <strong>⚡ 자동 경로:</strong> $5,000 이하 소액은 자동 승인 처리<br />
                 <strong>❌ 관리자 불가:</strong> 회원의 '중도 해지'를 강제로 실행할 수 없음 (회원이 본인 화면에서 직접 요청)
               </p>
               {showProcessGuide && (
                 <div className="text-[9px] text-text-muted space-y-2 border-t border-accent-blue/10 pt-3 mt-3">
                   <div><span className="font-bold text-accent-blue">Step 1:</span> 회원이 본인 화면에서 '출금 신청' 제출</div>
                   <div><span className="font-bold text-accent-blue">Step 2:</span> 시스템이 FDS 검증 수행 → 위험도 판정</div>
                   <div><span className="font-bold text-accent-blue">Step 3:</span> 소액($5K 이하)는 자동 승인, 대액은 관리자 검증</div>
                   <div><span className="font-bold text-accent-blue">Step 4:</span> 승인 후 블록체인으로 자동 송금 실행</div>
                 </div>
               )}
             </div>
           </div>
           <button
             onClick={() => setShowProcessGuide(!showProcessGuide)}
             className="text-[10px] font-black text-accent-blue border border-accent-blue/30 px-3 py-1 rounded hover:bg-accent-blue/10 transition-all whitespace-nowrap"
           >
             {showProcessGuide ? '접기' : '자세히'}
           </button>
         </div>
       </div>

       {/* 통계 */}
       <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="dashboard-card border-accent-blue/30 bg-accent-blue/5">
            <div className="flex items-center gap-2 text-accent-blue mb-3">
              <Clock size={14} />
              <h4 className="text-[9px] font-black uppercase tracking-widest">심사 대기</h4>
            </div>
            <p className="text-2xl font-black text-text-primary tabular-nums">{stats.pending}</p>
          </div>
          <div className="dashboard-card border-accent-green/30 bg-accent-green/5">
            <div className="flex items-center gap-2 text-accent-green mb-3">
              <CheckCircle2 size={14} />
              <h4 className="text-[9px] font-black uppercase tracking-widest">승인 완료</h4>
            </div>
            <p className="text-2xl font-black text-accent-green tabular-nums">{stats.approved}</p>
          </div>
          <div className="dashboard-card border-red-500/30 bg-red-500/5">
            <div className="flex items-center gap-2 text-red-500 mb-3">
              <XCircle size={14} />
              <h4 className="text-[9px] font-black uppercase tracking-widest">반려됨</h4>
            </div>
            <p className="text-2xl font-black text-red-500 tabular-nums">{stats.rejected}</p>
          </div>
          <div className="dashboard-card border-accent-amber/30 bg-accent-amber/5">
            <div className="flex items-center gap-2 text-accent-amber mb-3">
              <TrendingUp size={14} />
              <h4 className="text-[9px] font-black uppercase tracking-widest">승인액</h4>
            </div>
            <p className="text-2xl font-black text-accent-amber tabular-nums">${stats.totalAmount.toLocaleString()}</p>
          </div>
       </div>

       {/* 필터 & 검색 */}
       <div className="dashboard-card border-border-main p-6">
         <div className="flex flex-col md:flex-row gap-4 items-center">
           <div className="flex-1 relative">
             <Search size={14} className="absolute left-3 top-3 text-text-muted" />
             <input
               type="text"
               placeholder="회원 ID, 요청번호 검색..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-9 pr-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-blue/50"
             />
           </div>
           <div className="flex gap-2">
             {(['all', 'pending', 'approved', 'rejected'] as const).map(status => (
               <button
                 key={status}
                 onClick={() => setStatusFilter(status)}
                 className={cn(
                   'px-3 py-2 rounded text-[9px] font-bold uppercase tracking-widest transition-colors',
                   statusFilter === status
                     ? 'bg-accent-blue text-white'
                     : 'bg-black/30 text-text-muted border border-border-main hover:text-text-primary'
                 )}
               >
                 {status === 'all' ? '전체' : status === 'pending' ? '대기' : status === 'approved' ? '승인' : '반려'}
               </button>
             ))}
           </div>
         </div>
       </div>

       {/* 요청 테이블 */}
       <div className="dashboard-card p-0 overflow-hidden border-border-main shadow-sm">
          <div className="p-6 border-b border-border-main bg-black/10">
            <div className="flex items-center gap-2 mb-2">
              <Zap size={14} className="text-accent-blue" />
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">출금 신청 관리</h3>
            </div>
            <p className="text-[10px] text-text-muted">자동 검증: $5K 이하 = 자동 승인 | FDS 감시 활성</p>
          </div>

          <div className="overflow-x-auto">
            <table className="data-table table-fixed w-full">
              <thead>
                <tr>
                  <th className="!text-center text-[10px]">요청번호</th>
                  <th className="!text-center text-[10px]">회원</th>
                  <th className="!text-center text-[10px]">출금액</th>
                  <th className="!text-center text-[10px]">인증</th>
                  <th className="!text-center text-[10px]">지갑</th>
                  <th className="!text-center text-[10px]">상태</th>
                  <th className="!text-center text-[10px]">작업</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.map(w => (
                  <tr key={w.id} className={cn("hover:bg-white/[0.02] relative", successMessage?.id === w.id && "bg-accent-green/10")}>
                    {successMessage?.id === w.id && (
                      <div className="absolute inset-0 bg-accent-green/20 animate-pulse pointer-events-none" />
                    )}
                    <td className="!text-center overflow-hidden font-mono text-[10px] text-text-muted font-bold truncate">{w.withdrawalId}</td>
                    <td className="!text-center overflow-hidden">
                      <span className="font-bold text-[11px] text-text-primary truncate block">{w.userId}</span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <span className={cn(
                        'text-xs font-black px-2 py-1 rounded border inline-block',
                        getSeverityColor(w.amount)
                      )}>
                        ${w.amount.toLocaleString()}
                      </span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <div className="flex items-center justify-center gap-1">
                        <CheckCircle2 size={12} className="text-accent-green" />
                        <span className="text-[9px] font-bold text-accent-green">완료</span>
                      </div>
                    </td>
                    <td className="!text-center overflow-hidden max-w-[100px]">
                      <span className="text-[9px] text-text-muted font-mono truncate block">{w.walletAddress}</span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <span className={cn(
                        'text-[9px] font-black px-2 py-1 rounded border inline-block',
                        w.status === 'pending' ? 'bg-accent-amber/10 border-accent-amber/30 text-accent-amber' :
                        w.status === 'approved' ? 'bg-accent-green/10 border-accent-green/30 text-accent-green' :
                        'bg-red-500/10 border-red-500/30 text-red-500'
                      )}>
                        {w.status === 'pending' ? '대기' : w.status === 'approved' ? '승인' : '반려'}
                        {w.autoApproved && ' (자동)'}
                      </span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      {w.status === 'pending' ? (
                        <button
                          onClick={() => setSelectedRequest(w)}
                          className="px-3 py-1 rounded bg-accent-blue/10 text-accent-blue text-[9px] font-bold hover:bg-accent-blue/20 transition-colors"
                        >
                          검토
                        </button>
                      ) : (
                        <span className="text-[9px] text-text-muted">완료</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredRequests.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-[11px] text-text-muted">조건에 맞는 출금 요청이 없습니다</p>
            </div>
          )}
       </div>

       {/* 검토 모달 */}
       {selectedRequest && (
         <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
           <div className="bg-[#020617] border border-border-main rounded-lg w-full max-w-md p-6 shadow-2xl">
             <h3 className="text-lg font-bold text-text-primary uppercase tracking-wider mb-6">
               출금 신청 검토
             </h3>

             <div className="space-y-4 mb-6">
               <div className="bg-black/20 p-4 rounded border border-border-main/30">
                 <p className="text-[10px] text-text-muted uppercase tracking-widest mb-2">회원</p>
                 <p className="text-[12px] font-bold text-text-primary">{selectedRequest.userId}</p>
               </div>

               <div className="grid grid-cols-2 gap-3">
                 <div className="bg-black/20 p-3 rounded border border-border-main/30">
                   <p className="text-[9px] text-text-muted uppercase tracking-widest mb-1">출금액</p>
                   <p className="text-[12px] font-black text-accent-blue">${selectedRequest.amount.toLocaleString()}</p>
                 </div>
                 <div className="bg-black/20 p-3 rounded border border-border-main/30">
                   <p className="text-[9px] text-text-muted uppercase tracking-widest mb-1">자동 경로</p>
                   <p className="text-[12px] font-bold text-accent-green">
                     {shouldAutoApprove(selectedRequest.amount) ? '✓ 승인' : '✗ 검증'}
                   </p>
                 </div>
               </div>

               {!shouldAutoApprove(selectedRequest.amount) && (
                 <div>
                   <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2 block">
                     반려 이유 선택 (선택사항)
                   </label>
                   <select
                     value={rejectionReason}
                     onChange={(e) => setRejectionReason(e.target.value)}
                     className="w-full p-2 bg-black/30 border border-border-main rounded text-[10px] text-text-primary focus:outline-none focus:border-accent-blue/50"
                   >
                     <option value="">- 선택 -</option>
                     {REJECTION_REASONS.map(reason => (
                       <option key={reason} value={reason}>{reason}</option>
                     ))}
                   </select>
                 </div>
               )}
             </div>

             <div className="flex gap-3">
               <button
                 onClick={() => handleReject(selectedRequest)}
                 className="flex-1 px-4 py-2 rounded border border-red-500/30 bg-red-500/10 text-red-500 text-[10px] font-bold hover:bg-red-500/20 transition-colors"
               >
                 반려
               </button>
               <button
                 onClick={() => handleApprove(selectedRequest)}
                 className="flex-1 px-4 py-2 rounded bg-accent-green text-white text-[10px] font-bold hover:bg-accent-green/80 transition-colors"
               >
                 {shouldAutoApprove(selectedRequest.amount) ? '자동 승인' : '승인'}
               </button>
             </div>
           </div>
         </div>
       )}
    </div>
  );
}
