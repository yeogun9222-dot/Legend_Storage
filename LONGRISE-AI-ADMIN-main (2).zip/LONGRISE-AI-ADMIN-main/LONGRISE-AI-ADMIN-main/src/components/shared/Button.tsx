/**
 * Button Component - Reusable button with multiple variants
 */

import { ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children?: ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'outline';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  isLoading?: boolean;
  fullWidth?: boolean;
}

const variantStyles = {
  primary: 'bg-accent-blue text-white hover:bg-accent-blue/80 active:bg-accent-blue/70',
  secondary: 'bg-black/30 text-text-primary hover:bg-black/40 active:bg-black/50 border border-border-main',
  success: 'bg-accent-green text-white hover:bg-accent-green/80 active:bg-accent-green/70',
  danger: 'bg-red-500 text-white hover:bg-red-600 active:bg-red-700',
  warning: 'bg-accent-amber text-white hover:bg-accent-amber/80 active:bg-accent-amber/70',
  outline: 'bg-transparent text-text-primary border border-border-main hover:bg-white/5 active:bg-white/10',
};

const sizeStyles = {
  xs: 'px-2 py-1 text-xs',
  sm: 'px-3 py-1.5 text-xs font-bold',
  md: 'px-4 py-2 text-sm font-bold',
  lg: 'px-6 py-3 text-base font-bold',
};

export function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  isLoading = false,
  fullWidth = false,
  className,
  disabled,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded uppercase tracking-widest',
        'transition-colors disabled:opacity-50 disabled:cursor-not-allowed',
        variantStyles[variant],
        sizeStyles[size],
        fullWidth && 'w-full',
        className
      )}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <>
          <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
          Loading
        </>
      ) : (
        <>
          {icon && iconPosition === 'left' && <span className="flex-shrink-0">{icon}</span>}
          {children}
          {icon && iconPosition === 'right' && <span className="flex-shrink-0">{icon}</span>}
        </>
      )}
    </button>
  );
}

// Preset button variants for common actions
export function PrimaryButton(props: ButtonProps) {
  return <Button variant="primary" size="md" {...props} />;
}

export function SecondaryButton(props: ButtonProps) {
  return <Button variant="secondary" size="md" {...props} />;
}

export function DangerButton(props: ButtonProps) {
  return <Button variant="danger" size="md" {...props} />;
}

export function SuccessButton(props: ButtonProps) {
  return <Button variant="success" size="md" {...props} />;
}
