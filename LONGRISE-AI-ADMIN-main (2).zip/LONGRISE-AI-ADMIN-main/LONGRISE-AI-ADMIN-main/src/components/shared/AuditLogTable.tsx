/**
 * AuditLogTable Component - Specialized table for audit log display
 */

import { Badge } from './Badge';
import { cn } from '../../lib/utils';

interface AuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  resource: 'user' | 'product' | 'transaction' | 'content' | 'system';
  resourceId: string;
  changes?: {
    before: Record<string, any>;
    after: Record<string, any>;
  };
  status: 'success' | 'failure';
  errorMessage?: string;
  timestamp: string;
}

interface AuditLogTableProps {
  logs: AuditLog[];
  compact?: boolean;
  maxItems?: number;
}

export function AuditLogTable({ logs, compact = false, maxItems = 50 }: AuditLogTableProps) {
  const displayLogs = logs.slice(0, maxItems);

  if (displayLogs.length === 0) {
    return (
      <div className="text-center py-8 text-text-muted uppercase text-xs tracking-widest">
        No audit logs
      </div>
    );
  }

  return (
    <div className={cn('space-y-2', compact ? 'space-y-1' : 'space-y-3')}>
      {displayLogs.map((log) => (
        <div
          key={log.id}
          className={cn(
            'border border-border-main rounded transition-all',
            log.status === 'success' ? 'bg-black/20' : 'bg-red-500/5 border-red-500/30',
            compact ? 'p-2' : 'p-3'
          )}
        >
          <div className={cn('space-y-1', compact ? 'space-y-0.5' : 'space-y-2')}>
            {/* Header: Action + Status */}
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={cn(
                  'font-bold uppercase tracking-tighter truncate',
                  compact ? 'text-xs' : 'text-sm'
                )}>
                  {log.action}
                </span>
              </div>
              <Badge
                label={log.status === 'success' ? '성공' : '실패'}
                variant={log.status === 'success' ? 'success' : 'danger'}
                size={compact ? 'xs' : 'sm'}
              />
            </div>

            {/* Admin & Resource Info */}
            <div className={cn('flex items-center gap-4 text-text-muted', compact ? 'text-[9px]' : 'text-xs')}>
              <span>관리자: <span className="font-bold text-text-primary">{log.adminName}</span></span>
              <span>리소스: <span className="font-bold text-text-primary">{log.resourceId}</span></span>
            </div>

            {/* Timestamp */}
            <div className={cn('text-text-muted', compact ? 'text-[8px]' : 'text-xs')}>
              {new Date(log.timestamp).toLocaleString('ko-KR')}
            </div>

            {/* Changes Preview (if available) */}
            {log.changes && (
              <div className={cn(
                'bg-black/30 rounded p-2 text-[9px] text-text-muted font-mono space-y-1',
                compact && 'p-1 text-[8px]'
              )}>
                {Object.entries(log.changes.before).map(([key, beforeVal]) => {
                  const afterVal = log.changes?.after[key];
                  return (
                    <div key={key}>
                      <span className="text-red-400">{key}: {String(beforeVal)}</span>
                      <span className="mx-1">→</span>
                      <span className="text-accent-green">{String(afterVal)}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Error Message (if failure) */}
            {log.status === 'failure' && log.errorMessage && (
              <div className={cn(
                'bg-red-500/10 text-red-400 rounded p-2',
                compact ? 'p-1 text-[8px]' : 'text-xs'
              )}>
                {log.errorMessage}
              </div>
            )}
          </div>
        </div>
      ))}

      {logs.length > maxItems && (
        <p className="text-center text-text-muted text-xs uppercase tracking-widest pt-2">
          Showing {maxItems} of {logs.length}
        </p>
      )}
    </div>
  );
}
