/**
 * StatsCard Component - Reusable statistics/metrics display
 * Used across admin and user platforms for KPIs
 */

import { ReactNode } from 'react';
import { cn } from '../../lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: number;
  color?: 'blue' | 'green' | 'amber' | 'red' | 'purple';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const colorVariants = {
  blue: 'bg-accent-blue/10 border-accent-blue/20 text-accent-blue',
  green: 'bg-accent-green/10 border-accent-green/20 text-accent-green',
  amber: 'bg-accent-amber/10 border-accent-amber/20 text-accent-amber',
  red: 'bg-red-500/10 border-red-500/20 text-red-400',
  purple: 'bg-purple-500/10 border-purple-500/20 text-purple-400',
};

const sizeVariants = {
  sm: 'px-3 py-2',
  md: 'px-4 py-3',
  lg: 'px-6 py-4',
};

export function StatsCard({
  title,
  value,
  unit,
  icon,
  trend,
  trendValue,
  color = 'blue',
  size = 'md',
  className,
}: StatsCardProps) {
  return (
    <div
      className={cn(
        'border rounded-lg transition-all hover:border-opacity-100',
        colorVariants[color],
        sizeVariants[size],
        className
      )}
    >
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-bold uppercase tracking-widest opacity-80">{title}</p>
          {icon && <div className="text-lg">{icon}</div>}
        </div>

        <div className="flex items-baseline gap-2">
          <p className="text-2xl font-black">{value}</p>
          {unit && <span className="text-xs font-bold opacity-60">{unit}</span>}
        </div>

        {trend && trendValue !== undefined && (
          <div className="flex items-center gap-1 text-xs font-bold">
            {trend === 'up' && <TrendingUp size={12} className="text-accent-green" />}
            {trend === 'down' && <TrendingDown size={12} className="text-red-400" />}
            <span className={trend === 'up' ? 'text-accent-green' : trend === 'down' ? 'text-red-400' : ''}>
              {trend === 'up' ? '+' : ''}{trendValue}%
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
