# 🎨 Shared Component Library

Reusable UI component library for LONGRISE Admin Panel and User Platform.

## Overview

This library provides consistent, reusable components to ensure a unified user experience across all pages and features. All components follow the LONGRISE design system with dark theme, uppercase labels, and comprehensive styling.

## Components

### 📊 StatsCard

Display metrics and KPIs with optional trending information.

```tsx
import { StatsCard } from './shared';

<StatsCard
  title="USDT 잔액"
  value={142500.50}
  unit="USDT"
  color="blue"
  trend="up"
  trendValue={15}
  size="md"
/>
```

**Props:**
- `title` - Label text (uppercase)
- `value` - Main value to display
- `unit` - Optional unit (e.g., "USDT", "명")
- `color` - Color variant: `'blue' | 'green' | 'amber' | 'red' | 'purple'`
- `trend` - Optional trend indicator: `'up' | 'down' | 'neutral'`
- `trendValue` - Percentage change
- `size` - `'sm' | 'md' | 'lg'`
- `icon` - Optional icon element

---

### 🏷️ Badge

Status and category indicators with multiple variants.

```tsx
import { Badge, StatusBadge, KYCStatusBadge } from './shared';

// Custom badge
<Badge label="active" variant="success" size="sm" />

// Status badges
<StatusBadge status="active" />
<KYCStatusBadge status="verified" />
```

**Badge Props:**
- `label` - Text to display
- `variant` - `'default' | 'success' | 'warning' | 'danger' | 'info' | 'neutral'`
- `size` - `'xs' | 'sm' | 'md'`
- `icon` - Optional icon

**StatusBadge:**
- `status` - `'active' | 'inactive' | 'banned' | 'suspended' | 'pending'`

**KYCStatusBadge:**
- `status` - `'pending' | 'verified' | 'rejected'`

---

### 📋 DataTable

Reusable table component with sorting, pagination, and custom rendering.

```tsx
import { DataTable } from './shared';

const columns = [
  {
    key: 'nickname',
    label: '닉네임',
    sortable: true,
    width: '150px'
  },
  {
    key: 'balance',
    label: '잔액',
    render: (value, row) => `$${value.toLocaleString()}`
  }
];

<DataTable
  columns={columns}
  data={users}
  striped
  hoverable
  onRowClick={(user) => console.log(user)}
/>
```

**Props:**
- `columns` - Array of ColumnDef
- `data` - Array of data objects
- `striped` - Alternate row colors
- `hoverable` - Highlight on hover
- `compact` - Reduce padding
- `loading` - Show loading state
- `emptyMessage` - Message when no data
- `onRowClick` - Row click handler

**ColumnDef:**
- `key` - Data key (required)
- `label` - Column header
- `width` - Column width
- `sortable` - Enable sorting
- `render` - Custom render function
- `className` - Custom classes

---

### 📝 AuditLogTable

Specialized table for displaying audit logs with status badges and change previews.

```tsx
import { AuditLogTable } from './shared';

<AuditLogTable
  logs={auditLogs}
  compact={false}
  maxItems={50}
/>
```

**Props:**
- `logs` - Array of AuditLog objects
- `compact` - Reduce spacing and text size
- `maxItems` - Limit displayed logs

**Features:**
- Color-coded success/failure status
- Admin name and resource ID
- Timestamp in local format
- Before/after change preview
- Error messages for failures

---

### 🪟 ModalDialog

Base modal component with header, content, and footer sections.

```tsx
import { ModalDialog } from './shared';

<ModalDialog
  isOpen={isOpen}
  onClose={() => setOpen(false)}
  title="User Details"
  subtitle="user_001"
  size="lg"
  footer={
    <>
      <Button variant="secondary">Cancel</Button>
      <Button variant="primary">Save</Button>
    </>
  }
>
  {/* Content here */}
</ModalDialog>
```

**Props:**
- `isOpen` - Modal visibility
- `onClose` - Close handler
- `title` - Header title
- `subtitle` - Optional subtitle
- `children` - Modal content
- `footer` - Footer content (buttons, etc.)
- `size` - `'sm' | 'md' | 'lg' | 'xl'`

---

### 📝 FormInput

Consistent form input with label, error, and hint support.

```tsx
import { FormInput, FormSelect } from './shared';

<FormInput
  label="Amount"
  type="number"
  value={amount}
  onChange={(e) => setAmount(e.target.value)}
  error={errors.amount}
  hint="Enter amount in USD"
  icon={<DollarSign size={16} />}
/>

<FormSelect
  label="Currency"
  options={[
    { value: 'USDT', label: 'USDT' },
    { value: 'CNYT', label: 'CNYT' }
  ]}
  value={currency}
  onChange={(e) => setCurrency(e.target.value)}
/>
```

**FormInput Props:**
- `label` - Field label
- `type` - Input type (text, number, etc.)
- `value` - Input value
- `onChange` - Change handler
- `error` - Error message (shows in red)
- `hint` - Helper text
- `icon` - Icon element
- `size` - `'sm' | 'md' | 'lg'`
- `required` - Mark as required

**FormSelect Props:**
- Same as FormInput plus `options` array

---

### 🔘 Button

Versatile button component with multiple variants and sizes.

```tsx
import { Button, PrimaryButton, DangerButton } from './shared';

// Standard button
<Button
  variant="primary"
  size="md"
  onClick={handleClick}
  icon={<Check size={16} />}
>
  Save
</Button>

// Preset variants
<PrimaryButton>Save</PrimaryButton>
<DangerButton>Delete</DangerButton>
<SuccessButton icon={<Plus size={14} />}>Add</SuccessButton>
```

**Props:**
- `variant` - `'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'outline'`
- `size` - `'xs' | 'sm' | 'md' | 'lg'`
- `icon` - Icon element
- `iconPosition` - `'left' | 'right'` (default: left)
- `isLoading` - Show loading spinner
- `fullWidth` - Expand to 100% width
- `disabled` - Disable button
- `children` - Button text

**Preset Buttons:**
- `PrimaryButton` - Default action
- `SecondaryButton` - Secondary action
- `DangerButton` - Destructive action
- `SuccessButton` - Positive action

---

## Usage Examples

### User Detail Modal

```tsx
import { ModalDialog, StatsCard, Button, AuditLogTable } from './shared';

<ModalDialog
  isOpen={isOpen}
  onClose={onClose}
  title={user.nickname}
  subtitle={user.id}
  size="lg"
  footer={<Button onClick={onClose}>Close</Button>}
>
  <div className="space-y-4">
    <StatsCard
      title="USDT Balance"
      value={user.usdt}
      color="blue"
    />
    <AuditLogTable logs={auditLogs} />
  </div>
</ModalDialog>
```

### User List Page

```tsx
import { DataTable, Badge, Button } from './shared';

const columns = [
  {
    key: 'nickname',
    label: 'User',
    sortable: true
  },
  {
    key: 'status',
    label: 'Status',
    render: (value) => <StatusBadge status={value} />
  },
  {
    key: 'action',
    label: 'Action',
    render: (_, row) => (
      <Button size="sm" onClick={() => openDetails(row)}>
        View
      </Button>
    )
  }
];

<DataTable columns={columns} data={users} hoverable onRowClick={openDetails} />
```

### Balance Adjustment Form

```tsx
import { FormInput, Button, DangerButton } from './shared';

<div className="space-y-4">
  <FormInput
    label="Amount"
    type="number"
    value={amount}
    onChange={(e) => setAmount(e.target.value)}
  />
  <div className="flex gap-2">
    <Button variant="success" fullWidth>Add</Button>
    <DangerButton fullWidth>Remove</DangerButton>
  </div>
</div>
```

---

## Design System

### Colors
- **Primary:** `accent-blue` - Main actions
- **Success:** `accent-green` - Positive actions
- **Warning:** `accent-amber` - Cautions
- **Danger:** `red-500` - Destructive actions
- **Info:** `purple-500` - Informational

### Typography
- **Labels:** UPPERCASE, small font size (9-10px), extra letter spacing
- **Values:** Bold, slightly larger font
- **Hints:** Muted color, very small (8-9px)

### Spacing
- **Compact:** 0.5rem padding (xs/sm sizes)
- **Normal:** 1rem padding (md/lg sizes)
- **Loose:** 1.5rem padding (lg components)

### Borders
- Main border: `border-border-main`
- Status borders: Color-coded (`accent-blue/30`, etc.)
- Rounded corners: `rounded` (4px default)

---

## Integration

### Import Single Component
```tsx
import { StatsCard } from './components/shared';
```

### Import Multiple
```tsx
import { StatsCard, Badge, Button } from './components/shared';
```

### Export All from Index
Components are exported from `src/components/shared/index.ts` for easy importing.

---

## Best Practices

1. **Use Type-Specific Badges**
   - `StatusBadge` for user status
   - `KYCStatusBadge` for KYC status
   - Generic `Badge` for custom status

2. **Consistent Data Table Columns**
   - Make sortable columns for numbers/dates
   - Use render functions for formatted values
   - Set fixed widths for narrow columns

3. **Modal Sizing**
   - `sm` - Confirmations (350px)
   - `md` - Forms (450px)
   - `lg` - Details (700px)
   - `xl` - Large workflows (900px)

4. **Button Hierarchy**
   - Primary: Main action (save, submit)
   - Secondary: Alternative action (cancel)
   - Danger: Destructive action (delete)
   - Outline: Tertiary action

5. **Form Validation**
   - Show error on FormInput when validation fails
   - Disable submit button until valid
   - Show helpful hints for required fields

---

## Customization

All components support `className` prop for additional custom styling:

```tsx
<StatsCard
  title="Custom Stats"
  value={100}
  className="shadow-lg border-2 border-accent-blue"
/>
```

---

## Component Refactoring Checklist

When refactoring a page to use shared components:

- [ ] Replace custom StatsCard implementations with `StatsCard` component
- [ ] Replace custom tables with `DataTable`
- [ ] Replace custom modals with `ModalDialog`
- [ ] Replace custom badges with `Badge` / `StatusBadge`
- [ ] Replace custom buttons with `Button` variants
- [ ] Replace custom form inputs with `FormInput` / `FormSelect`
- [ ] Move audit log display to `AuditLogTable`
- [ ] Verify consistent styling across the page
- [ ] Test all interactive features
- [ ] Verify error states and loading states

---

*Documentation last updated: April 22, 2026*
