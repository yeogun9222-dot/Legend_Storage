/**
 * FormInput Component - Reusable form input with consistent styling
 */

import { ReactNode, InputHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface FormInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  icon?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  type?: string;
  required?: boolean;
}

const sizeVariants = {
  sm: 'px-2 py-1.5 text-xs',
  md: 'px-3 py-2 text-sm',
  lg: 'px-4 py-2.5 text-base',
};

export function FormInput({
  label,
  error,
  hint,
  icon,
  size = 'md',
  className,
  ...props
}: FormInputProps) {
  return (
    <div className="space-y-1">
      {label && (
        <label className="block text-xs font-bold uppercase tracking-widest text-text-primary mb-1.5">
          {label}
          {props.required && <span className="text-red-400 ml-1">*</span>}
        </label>
      )}

      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted">
            {icon}
          </div>
        )}

        <input
          className={cn(
            'w-full bg-black/20 border rounded transition-colors',
            'text-text-primary placeholder-text-muted/50',
            'focus:outline-none focus:border-accent-blue/50 focus:bg-black/30',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            sizeVariants[size],
            icon && 'pl-9',
            error ? 'border-red-500/50 focus:border-red-500/80' : 'border-border-main',
            className
          )}
          {...props}
        />
      </div>

      {error && (
        <p className="text-xs text-red-400 uppercase tracking-tight">{error}</p>
      )}

      {hint && !error && (
        <p className="text-xs text-text-muted uppercase tracking-tight">{hint}</p>
      )}
    </div>
  );
}

interface FormSelectProps extends InputHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: Array<{ value: string | number; label: string }>;
  error?: string;
  hint?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  required?: boolean;
}

export function FormSelect({
  label,
  options,
  error,
  hint,
  size = 'md',
  className,
  ...props
}: FormSelectProps) {
  return (
    <div className="space-y-1">
      {label && (
        <label className="block text-xs font-bold uppercase tracking-widest text-text-primary mb-1.5">
          {label}
          {props.required && <span className="text-red-400 ml-1">*</span>}
        </label>
      )}

      <select
        className={cn(
          'w-full bg-black/20 border rounded transition-colors',
          'text-text-primary',
          'focus:outline-none focus:border-accent-blue/50 focus:bg-black/30',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          sizeVariants[size],
          error ? 'border-red-500/50' : 'border-border-main',
          className
        )}
        {...props}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>

      {error && (
        <p className="text-xs text-red-400 uppercase tracking-tight">{error}</p>
      )}

      {hint && !error && (
        <p className="text-xs text-text-muted uppercase tracking-tight">{hint}</p>
      )}
    </div>
  );
}
