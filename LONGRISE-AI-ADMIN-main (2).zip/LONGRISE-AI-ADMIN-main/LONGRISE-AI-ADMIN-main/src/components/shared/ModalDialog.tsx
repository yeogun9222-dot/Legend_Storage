/**
 * ModalDialog Component - Reusable modal with standard layout
 */

import { ReactNode } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';

interface ModalDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const sizeVariants = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-2xl',
  xl: 'max-w-4xl',
};

export function ModalDialog({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  footer,
  size = 'md',
  className,
}: ModalDialogProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-dashboard-bg flex flex-col items-center justify-start pt-42 px-4">
      <div className={cn(
        'bg-bg-surface border border-border-main/50 rounded-lg w-full max-h-[90vh] flex flex-col shadow-2xl',
        sizeVariants[size],
        className
      )}>
        {/* Header */}
        <div className="p-6 border-b border-border-main flex items-center justify-between bg-black/20">
          <div>
            <h2 className="text-lg font-bold text-text-primary">{title}</h2>
            {subtitle && (
              <p className="text-xs text-text-muted uppercase tracking-widest mt-1">{subtitle}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/5 rounded transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {children}
        </div>

        {/* Footer */}
        {footer && (
          <div className="border-t border-border-main p-4 bg-black/20 flex justify-end gap-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
