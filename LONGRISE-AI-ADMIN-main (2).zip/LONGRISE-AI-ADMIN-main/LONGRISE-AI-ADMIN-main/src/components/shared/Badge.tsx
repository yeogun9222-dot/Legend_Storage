/**
 * Badge Component - Status and category indicators
 * Reusable across all pages
 */

import { ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface BadgeProps {
  label: string;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';
  size?: 'xs' | 'sm' | 'md';
  icon?: ReactNode;
  className?: string;
}

const variantStyles = {
  default: 'bg-accent-blue/20 text-accent-blue border-accent-blue/30',
  success: 'bg-accent-green/20 text-accent-green border-accent-green/30',
  warning: 'bg-accent-amber/20 text-accent-amber border-accent-amber/30',
  danger: 'bg-red-500/20 text-red-400 border-red-500/30',
  info: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  neutral: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
};

const sizeStyles = {
  xs: 'px-1.5 py-0.5 text-[8px]',
  sm: 'px-2 py-0.5 text-[9px]',
  md: 'px-3 py-1 text-[10px]',
};

export function Badge({
  label,
  variant = 'default',
  size = 'sm',
  icon,
  className,
}: BadgeProps) {
  return (
    <div
      className={cn(
        'inline-flex items-center gap-1 font-bold uppercase tracking-tighter border rounded whitespace-nowrap',
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
    >
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{label}</span>
    </div>
  );
}

// Preset badges for common statuses
export function StatusBadge({ status }: { status: 'active' | 'inactive' | 'banned' | 'suspended' | 'pending' }) {
  const variants = {
    active: 'success' as const,
    inactive: 'neutral' as const,
    banned: 'danger' as const,
    suspended: 'warning' as const,
    pending: 'info' as const,
  };

  const labels = {
    active: '정상',
    inactive: '비활성',
    banned: '정지',
    suspended: '일시정지',
    pending: '대기',
  };

  return <Badge label={labels[status]} variant={variants[status]} size="sm" />;
}

export function KYCStatusBadge({ status }: { status: 'pending' | 'verified' | 'rejected' }) {
  const variants = {
    pending: 'warning' as const,
    verified: 'success' as const,
    rejected: 'danger' as const,
  };

  const labels = {
    pending: '심사중',
    verified: '인증완료',
    rejected: '거부됨',
  };

  return <Badge label={labels[status]} variant={variants[status]} size="sm" />;
}
