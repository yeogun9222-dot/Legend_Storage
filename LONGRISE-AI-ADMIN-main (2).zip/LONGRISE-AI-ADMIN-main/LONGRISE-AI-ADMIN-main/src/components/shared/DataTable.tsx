/**
 * DataTable Component - Reusable table with sorting, pagination
 * Flexible column definition and custom rendering
 */

import { ReactNode, useState } from 'react';
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface ColumnDef<T> {
  key: keyof T;
  label: string;
  width?: string;
  sortable?: boolean;
  render?: (value: any, row: T, index: number) => ReactNode;
  className?: string;
}

interface DataTableProps<T extends { id?: string }> {
  columns: ColumnDef<T>[];
  data: T[];
  striped?: boolean;
  hoverable?: boolean;
  compact?: boolean;
  loading?: boolean;
  emptyMessage?: string;
  onRowClick?: (row: T, index: number) => void;
  className?: string;
}

type SortOrder = 'asc' | 'desc' | null;

export function DataTable<T extends { id?: string }>({
  columns,
  data,
  striped = true,
  hoverable = true,
  compact = false,
  loading = false,
  emptyMessage = 'No data available',
  onRowClick,
  className,
}: DataTableProps<T>) {
  const [sortKey, setSortKey] = useState<keyof T | null>(null);
  const [sortOrder, setSortOrder] = useState<SortOrder>(null);

  const handleSort = (key: keyof T) => {
    if (sortKey === key) {
      if (sortOrder === 'asc') {
        setSortOrder('desc');
      } else if (sortOrder === 'desc') {
        setSortKey(null);
        setSortOrder(null);
      }
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };

  let sortedData = [...data];
  if (sortKey && sortOrder) {
    sortedData.sort((a, b) => {
      const aVal = a[sortKey];
      const bVal = b[sortKey];

      if (aVal === bVal) return 0;
      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      return sortOrder === 'asc' ? 1 : -1;
    });
  }

  if (loading) {
    return (
      <div className="text-center py-8 text-text-muted uppercase text-xs tracking-widest">
        Loading...
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="text-center py-8 text-text-muted uppercase text-xs tracking-widest">
        {emptyMessage}
      </div>
    );
  }

  return (
    <div className={cn('overflow-x-auto', className)}>
      <table className={cn(
        'w-full border-collapse',
        compact ? 'text-xs' : 'text-sm'
      )}>
        <thead>
          <tr className="border-b border-border-main bg-black/20">
            {columns.map((col) => (
              <th
                key={String(col.key)}
                className={cn(
                  'text-left font-bold uppercase tracking-widest px-4 py-3',
                  col.width,
                  col.className
                )}
              >
                <div className="flex items-center gap-2">
                  <span>{col.label}</span>
                  {col.sortable && (
                    <button
                      onClick={() => handleSort(col.key)}
                      className="p-1 hover:bg-white/10 rounded transition-colors"
                    >
                      {sortKey === col.key ? (
                        sortOrder === 'asc' ? (
                          <ChevronUp size={14} className="text-accent-blue" />
                        ) : (
                          <ChevronDown size={14} className="text-accent-blue" />
                        )
                      ) : (
                        <ChevronsUpDown size={14} className="text-text-muted opacity-50" />
                      )}
                    </button>
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, idx) => (
            <tr
              key={row.id || idx}
              className={cn(
                'border-b border-border-main transition-colors',
                striped && idx % 2 === 0 && 'bg-white/[0.02]',
                hoverable && 'hover:bg-white/[0.05]',
                onRowClick && 'cursor-pointer'
              )}
              onClick={() => onRowClick?.(row, idx)}
            >
              {columns.map((col) => (
                <td
                  key={String(col.key)}
                  className={cn(
                    'px-4 py-3 text-text-primary',
                    col.className
                  )}
                >
                  {col.render ? col.render(row[col.key], row, idx) : String(row[col.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
