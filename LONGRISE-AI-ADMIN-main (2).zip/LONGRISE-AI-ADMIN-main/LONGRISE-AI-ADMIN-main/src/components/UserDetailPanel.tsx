/**
 * User Detail Panel - Admin View with Controls
 * Shows user details and allows admin operations
 * Now using shared component library
 */

import { useState, useEffect } from 'react';
import { User, AdminUser } from '../types';
import { cn } from '../lib/utils';
import { Lock, Trash2, AlertTriangle, Shield, RotateCcw, Plus, Minus } from 'lucide-react';
import { userApi } from '../lib/api';
import { ModalDialog, StatsCard, AuditLogTable, FormInput, Button, DangerButton, Badge, StatusBadge, KYCStatusBadge } from './shared';

interface UserDetailPanelProps {
  user: User | null;
  isOpen: boolean;
  onClose: () => void;
  currentAdmin?: AdminUser;
  onUpdate?: (user: User) => void;
}

type TabType = 'overview' | 'controls' | 'audit_logs';

export function UserDetailPanel({ user, isOpen, onClose, currentAdmin, onUpdate }: UserDetailPanelProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [adjustAmount, setAdjustAmount] = useState(1000);
  const [selectedCurrency, setSelectedCurrency] = useState<'USDT' | 'CNYT'>('USDT');
  const [loadingLogs, setLoadingLogs] = useState(false);

  // Fetch audit logs when user changes or tab changes
  useEffect(() => {
    if (user && activeTab === 'audit_logs') {
      fetchAuditLogs();
    }
  }, [user?.id, activeTab]);

  const fetchAuditLogs = async () => {
    if (!user) return;

    try {
      setLoadingLogs(true);
      const response = await userApi.getAuditLogs(user.id);

      if (response.success && response.data) {
        setAuditLogs(response.data);
      }
    } catch (err) {
      console.error('Error fetching audit logs:', err);
    } finally {
      setLoadingLogs(false);
    }
  };

  const handleBalanceAdjustment = async (amount: number) => {
    if (!user || !currentAdmin) return;

    try {
      const response = await userApi.adjustBalance(user.id, selectedCurrency, amount, currentAdmin.id, currentAdmin.name);

      if (response.success && response.data) {
        console.log('✅ Balance adjusted');
        setAdjustAmount(1000);
        onUpdate?.(response.data as any);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleSetRestriction = async (restrictionType: 'withdrawal' | 'account' | 'freeze', enabled: boolean) => {
    if (!user || !currentAdmin) return;

    try {
      const response = await userApi.setRestrictions(user.id, restrictionType, enabled, currentAdmin.id, currentAdmin.name);

      if (response.success && response.data) {
        console.log(`✅ ${restrictionType} restriction set`);
        onUpdate?.(response.data as any);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleResetKyc = async () => {
    if (!user || !currentAdmin) return;

    try {
      const response = await userApi.resetKyc(user.id, currentAdmin.id, currentAdmin.name);

      if (response.success && response.data) {
        console.log('✅ KYC reset');
        onUpdate?.(response.data as any);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleBan = async () => {
    if (!user || !currentAdmin) return;

    if (!window.confirm(`${user.nickname} 계정을 영구 정지하시겠습니까?`)) {
      return;
    }

    try {
      const response = await userApi.ban(user.id, currentAdmin.id, currentAdmin.name);

      if (response.success) {
        console.log('✅ User banned');
        onClose();
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  if (!isOpen || !user) return null;

  return (
    <ModalDialog
      isOpen={isOpen}
      onClose={onClose}
      title={user.nickname}
      subtitle={user.id}
      size="lg"
      footer={
        <Button variant="secondary" onClick={onClose}>
          닫기
        </Button>
      }
    >
      {/* Tabs Navigation - Fixed */}
      <div className="sticky -top-6 -mx-6 px-6 py-0 bg-bg-surface border-b-2 border-border-main z-40">
        <div className="flex gap-0">
          {(['overview', 'controls', 'audit_logs'] as TabType[]).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "flex-1 px-4 py-4 text-xs font-bold uppercase tracking-widest border-b-3 transition-all whitespace-nowrap",
                activeTab === tab
                  ? 'border-accent-blue text-accent-blue bg-accent-blue/10'
                  : 'border-transparent text-text-muted hover:text-text-primary hover:bg-white/[0.02]'
              )}
            >
              {tab === 'overview' && '📊 개요'}
              {tab === 'controls' && '⚙️ 제어'}
              {tab === 'audit_logs' && '📋 감사로그'}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="space-y-6 pt-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest mb-3">자산 현황</h3>
              <div className="grid grid-cols-2 gap-4">
                <StatsCard
                  title="USDT 잔액"
                  value={user.usdt?.toLocaleString() || 0}
                  color="blue"
                  size="md"
                />
                <StatsCard
                  title="CNYT 잔액"
                  value={user.cnyt?.toLocaleString() || 0}
                  color="purple"
                  size="md"
                />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest mb-3">계정 정보</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="border border-border-main rounded p-4 bg-black/20">
                  <p className="text-xs text-text-muted uppercase tracking-widest mb-2">직급</p>
                  <p className="text-lg font-bold text-text-primary">{user.rank}</p>
                </div>
                <div className="border border-border-main rounded p-4 bg-black/20">
                  <p className="text-xs text-text-muted uppercase tracking-widest mb-2">상태</p>
                  <StatusBadge status={user.status === 'Active' ? 'active' : 'inactive'} />
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest mb-3">팀 정보</h3>
              <div className="grid grid-cols-2 gap-4">
                <StatsCard
                  title="팀 크기"
                  value={user.teamSize || 0}
                  unit="명"
                  color="green"
                  size="md"
                />
                <StatsCard
                  title="팀 볼륨"
                  value={(user.teamVol || 0).toLocaleString()}
                  unit="$"
                  color="amber"
                  size="md"
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'controls' && (
          <div className="space-y-6">
            {/* Balance Adjustment */}
            <div className="border border-border-main rounded p-4 space-y-3">
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest">잔액 조정</h3>
              <div className="flex gap-2 mb-3">
                <Button
                  variant={selectedCurrency === 'USDT' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setSelectedCurrency('USDT')}
                >
                  USDT
                </Button>
                <Button
                  variant={selectedCurrency === 'CNYT' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setSelectedCurrency('CNYT')}
                >
                  CNYT
                </Button>
              </div>

              <FormInput
                type="number"
                value={adjustAmount}
                onChange={(e) => setAdjustAmount(Number(e.target.value))}
                placeholder="금액 입력"
                label={`${selectedCurrency} 금액`}
              />

              <div className="flex gap-2 pt-2">
                <Button
                  variant="success"
                  size="md"
                  fullWidth
                  icon={<Plus size={14} />}
                  onClick={() => handleBalanceAdjustment(adjustAmount)}
                >
                  지급
                </Button>
                <Button
                  variant="danger"
                  size="md"
                  fullWidth
                  icon={<Minus size={14} />}
                  onClick={() => handleBalanceAdjustment(-adjustAmount)}
                >
                  차감
                </Button>
              </div>
            </div>

            {/* Restrictions */}
            <div className="border border-border-main rounded p-4 space-y-3">
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest">제한 설정</h3>
              <div className="space-y-2">
                <Button
                  variant="danger"
                  fullWidth
                  size="md"
                  icon={<AlertTriangle size={14} />}
                  onClick={() => handleSetRestriction('withdrawal', true)}
                >
                  출금 차단
                </Button>
                <Button
                  variant="danger"
                  fullWidth
                  size="md"
                  icon={<Lock size={14} />}
                  onClick={() => handleSetRestriction('account', true)}
                >
                  계정 잠금
                </Button>
                <Button
                  variant="danger"
                  fullWidth
                  size="md"
                  icon={<Shield size={14} />}
                  onClick={() => handleSetRestriction('freeze', true)}
                >
                  자산 동결
                </Button>
              </div>
            </div>

            {/* KYC Management */}
            <div className="border border-border-main rounded p-4 space-y-3">
              <h3 className="text-sm font-bold text-text-primary uppercase tracking-widest">KYC 관리</h3>
              <p className="text-xs text-text-muted">
                KYC 레벨: <span className="font-bold text-text-primary">{user.kycLevel || 0}</span>
              </p>
              <Button
                variant="warning"
                fullWidth
                size="md"
                icon={<RotateCcw size={14} />}
                onClick={handleResetKyc}
              >
                KYC 초기화
              </Button>
            </div>

            {/* Danger Zone */}
            <div className="border border-red-500/30 rounded p-4 space-y-3 bg-red-500/5">
              <h3 className="text-sm font-bold text-red-400 uppercase tracking-widest">⚠️ 위험 영역</h3>
              <DangerButton
                fullWidth
                size="md"
                icon={<Trash2 size={14} />}
                onClick={handleBan}
              >
                영구 정지
              </DangerButton>
            </div>
          </div>
        )}

        {activeTab === 'audit_logs' && (
          <div>
            {loadingLogs ? (
              <p className="text-text-muted text-xs uppercase tracking-widest text-center py-6">로드 중...</p>
            ) : (
              <AuditLogTable logs={auditLogs} compact={false} />
            )}
          </div>
        )}
      </div>
    </ModalDialog>
  );
}
