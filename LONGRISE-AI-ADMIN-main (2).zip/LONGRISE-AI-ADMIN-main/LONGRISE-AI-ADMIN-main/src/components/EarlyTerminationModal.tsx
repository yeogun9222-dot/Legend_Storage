/**
 * Early Termination Modal Component
 * 중도해지 신청 모달 (핵심 기능)
 * V7.5 정책: 15% 최소환급금 보장
 */

import { useState } from 'react';
import { AlertCircle, DollarSign, Calendar, Check, X } from 'lucide-react';
import { cn } from '../lib/utils';
import type { MemberPackage } from '../lib/mockMemberData';
import { calculateEarlyTerminationRefund, calculateElapsedMonths, calculateEarlyTerminationPenalty } from '../lib/mockMemberData';

interface EarlyTerminationModalProps {
  isOpen: boolean;
  packageId: string | null;
  packages: MemberPackage[];
  onClose: () => void;
  onConfirm: (packageId: string, refundAmount: number) => void;
}

export function EarlyTerminationModal({
  isOpen,
  packageId,
  packages,
  onClose,
  onConfirm,
}: EarlyTerminationModalProps) {
  const [step, setStep] = useState<'select' | 'confirm' | 'success'>('select');
  const [selectedPackageId, setSelectedPackageId] = useState<string | null>(packageId);

  const selectedPackage = packages.find((pkg) => pkg.id === selectedPackageId);
  const elapsedMonths = selectedPackage ? calculateElapsedMonths(selectedPackage.joinDate) : 0;
  const refundCalc = selectedPackage
    ? calculateEarlyTerminationRefund(selectedPackage.principal, selectedPackage.currentBalance)
    : null;
  const penaltyCalc = selectedPackage && selectedPackage.packageType !== 'Flexible'
    ? calculateEarlyTerminationPenalty(selectedPackage.principal, elapsedMonths)
    : null;

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (selectedPackage && refundCalc) {
      setStep('confirm');
    }
  };

  const handleFinalConfirm = () => {
    if (selectedPackage && refundCalc) {
      onConfirm(selectedPackage.id, refundCalc.finalRefund);
      setStep('success');
      setTimeout(() => {
        setStep('select');
        setSelectedPackageId(null);
        onClose();
      }, 2000);
    }
  };

  const handleClose = () => {
    setStep('select');
    setSelectedPackageId(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="dashboard-card border-border-main w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="flex items-center justify-between p-6 border-b border-border-main">
          <h2 className="text-lg font-black text-white uppercase tracking-wider">
            📋 중도해지 신청
          </h2>
          <button
            onClick={handleClose}
            className="text-text-muted hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Step 1: 패키지 선택 */}
        {step === 'select' && (
          <div className="p-6">
            <p className="text-[10px] font-black text-text-muted uppercase mb-4">
              Step 1: 중도해지할 패키지 선택
            </p>

            <div className="space-y-3 mb-6">
              {packages
                .filter((pkg) => pkg.status === 'active')
                .map((pkg) => (
                  <div
                    key={pkg.id}
                    onClick={() => setSelectedPackageId(pkg.id)}
                    className={cn(
                      'p-4 border-2 rounded-lg cursor-pointer transition-all',
                      selectedPackageId === pkg.id
                        ? 'border-accent-blue bg-accent-blue/20'
                        : 'border-white/10 bg-black/20 hover:border-white/20'
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-black text-white">{pkg.packageType}</p>
                        <p className="text-[9px] text-text-muted mt-1">
                          원금: ${pkg.principal.toLocaleString()} | 현재: ${pkg.currentBalance.toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-text-muted">진입일</p>
                        <p className="text-sm font-black text-white">
                          {pkg.joinDate.toLocaleDateString('ko-KR')}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
            </div>

            {selectedPackage && (
              <div className="bg-accent-blue/10 border border-accent-blue/30 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="text-accent-blue mt-1 shrink-0" size={18} />
                  <div>
                    <p className="text-sm font-black text-accent-blue mb-2">⚠️ 중도해지 정보</p>
                    <div className="text-[9px] text-accent-blue/90 space-y-1">
                      <p>
                        • 경과 기간: <span className="font-bold">{elapsedMonths}개월</span>
                      </p>
                      {penaltyCalc && penaltyCalc.penaltyPercent > 0 && (
                        <p>
                          • 해지 페널티: <span className="font-bold">{penaltyCalc.penaltyPercent}%</span> (약 $
                          {penaltyCalc.penalty.toLocaleString()})
                        </p>
                      )}
                      <p>
                        • 최소환급금: 원금의 <span className="font-bold">15%</span> 보장
                      </p>
                      <p>
                        • 환급 기간: <span className="font-bold">3-5 영업일</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {selectedPackage && refundCalc && (
              <div className="bg-black/40 border border-white/5 rounded-lg p-4 mb-6">
                <p className="text-[10px] font-black text-text-muted uppercase mb-3">예상 환급액</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-text-muted">기본 환급</span>
                    <span className="text-sm font-black text-text-primary">
                      ${refundCalc.basicRefund.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-text-muted">최소환급금 (15%)</span>
                    <span className="text-sm font-black text-accent-green">
                      ${refundCalc.minimumRefund.toLocaleString()}
                    </span>
                  </div>
                  <div className="border-t border-white/10 pt-2 flex items-center justify-between">
                    <span className="text-sm font-black text-white">최종 환급액</span>
                    <span className="text-lg font-black text-accent-green">
                      ${refundCalc.finalRefund.toLocaleString()}
                    </span>
                  </div>
                </div>

                {refundCalc.finalRefund === refundCalc.minimumRefund && (
                  <p className="text-[9px] text-accent-green">
                    ✅ 15% 최소환급금이 적용되었습니다. (V7.5 정책)
                  </p>
                )}
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={handleClose}
                className="flex-1 py-2 bg-white/10 hover:bg-white/20 border border-white/10 text-white text-[10px] font-black uppercase rounded transition-all"
              >
                취소
              </button>
              <button
                onClick={handleConfirm}
                disabled={!selectedPackage}
                className={cn(
                  'flex-1 py-2 text-white text-[10px] font-black uppercase rounded transition-all',
                  selectedPackage
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-white/10 cursor-not-allowed opacity-50'
                )}
              >
                다음: 확인
              </button>
            </div>
          </div>
        )}

        {/* Step 2: 최종 확인 */}
        {step === 'confirm' && selectedPackage && refundCalc && (
          <div className="p-6">
            <p className="text-[10px] font-black text-text-muted uppercase mb-4">
              Step 2: 중도해지 신청 확인
            </p>

            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-red-500 mt-1 shrink-0" size={20} />
                <div>
                  <p className="text-sm font-black text-red-500 mb-2">중요: 신청 전 확인하세요</p>
                  <div className="text-[9px] text-red-400 space-y-1">
                    <p>• 중도해지 신청 후 취소할 수 없습니다.</p>
                    <p>• 환급액은 3-5 영업일 이내에 지급됩니다.</p>
                    <p>• 만기까지의 수익을 포기하게 됩니다.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-black/40 border border-white/5 rounded p-4">
                <p className="text-[10px] text-text-muted uppercase font-bold mb-3">신청 정보</p>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-text-muted">패키지</span>
                    <span className="text-sm font-black text-white">{selectedPackage.packageType}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-text-muted">원금</span>
                    <span className="text-sm font-black text-white">
                      ${selectedPackage.principal.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-text-muted">경과 기간</span>
                    <span className="text-sm font-black text-white">{elapsedMonths}개월</span>
                  </div>
                  <div className="border-t border-white/10 pt-2 flex justify-between items-center">
                    <span className="text-sm font-black text-white">환급액</span>
                    <span className="text-lg font-black text-accent-green">
                      ${refundCalc.finalRefund.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-accent-green/10 border border-accent-green/30 rounded p-3">
                <div className="flex items-start gap-2">
                  <Check className="text-accent-green mt-0.5 shrink-0" size={16} />
                  <p className="text-[10px] text-accent-green">
                    <span className="font-bold">15% 최소환급금</span>이 보장됩니다. (V7.5 정책)
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep('select')}
                className="flex-1 py-2 bg-white/10 hover:bg-white/20 border border-white/10 text-white text-[10px] font-black uppercase rounded transition-all"
              >
                이전
              </button>
              <button
                onClick={handleFinalConfirm}
                className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white text-[10px] font-black uppercase rounded transition-all"
              >
                최종 신청
              </button>
            </div>
          </div>
        )}

        {/* Step 3: 완료 */}
        {step === 'success' && (
          <div className="p-6 text-center">
            <div className="mb-6">
              <Check className="text-accent-green mx-auto mb-4" size={48} />
              <p className="text-2xl font-black text-white mb-2">신청 완료!</p>
              <p className="text-[10px] text-text-muted uppercase">중도해지 신청이 접수되었습니다</p>
            </div>

            <div className="bg-accent-green/10 border border-accent-green/30 rounded-lg p-4 mb-6">
              <div className="space-y-2 text-left">
                <p className="text-[10px] text-text-muted uppercase font-bold">처리 현황</p>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Check className="text-accent-green" size={14} />
                    <span className="text-[9px] text-white">신청 접수됨</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-text-muted rounded-full" />
                    <span className="text-[9px] text-text-muted">검증 중...</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-text-muted rounded-full" />
                    <span className="text-[9px] text-text-muted">환급 처리 중...</span>
                  </div>
                </div>
              </div>
            </div>

            <p className="text-[10px] text-text-muted mb-4">
              환급액: <span className="font-black text-accent-green">예상 금액</span> | 기간: <span className="font-black">3-5 영업일</span>
            </p>

            <button
              onClick={handleClose}
              className="w-full py-2 bg-accent-green hover:bg-accent-green/80 text-white text-[10px] font-black uppercase rounded transition-all"
            >
              확인
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
