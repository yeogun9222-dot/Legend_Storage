/**
 * Asset Summary Component
 * 회원 자산 요약 카드
 */

import { Wallet, TrendingUp, Clock } from 'lucide-react';

interface AssetSummaryProps {
  totalAssets: number;
  totalUSDT: number;
  totalCNYT: number;
  dailyEarnings: number;
  dailyEarningsPercent: number;
}

export function AssetSummary({
  totalAssets,
  totalUSDT,
  totalCNYT,
  dailyEarnings,
  dailyEarningsPercent,
}: AssetSummaryProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* 총 자산 */}
      <div className="dashboard-card p-6 border-accent-blue/30 bg-accent-blue/[0.08]">
        <div className="flex items-center gap-2 mb-4">
          <Wallet className="text-accent-blue" size={20} />
          <p className="text-[10px] font-black text-text-muted uppercase">총 자산</p>
        </div>
        <p className="text-3xl font-black text-white mb-2">
          ${totalAssets.toLocaleString('en-US', { maximumFractionDigits: 0 })}
        </p>
        <div className="text-[9px] text-text-muted space-y-1">
          <div className="flex justify-between">
            <span>USDT:</span>
            <span className="text-accent-blue font-bold">${totalUSDT.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span>CNYT:</span>
            <span className="text-accent-amber font-bold">${totalCNYT.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* 오늘 수익 */}
      <div className="dashboard-card p-6 border-accent-green/30 bg-accent-green/[0.08]">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="text-accent-green" size={20} />
          <p className="text-[10px] font-black text-text-muted uppercase">오늘 수익</p>
        </div>
        <p className="text-3xl font-black text-accent-green mb-2">
          ${dailyEarnings.toFixed(2)}
        </p>
        <div className="text-[9px] text-text-muted">
          <span className="text-accent-green font-bold">+{dailyEarningsPercent.toFixed(2)}%</span>
          <span className="text-text-muted"> 일일 수익률</span>
        </div>
      </div>

      {/* 활성 패키지 */}
      <div className="dashboard-card p-6 border-accent-amber/30 bg-accent-amber/[0.08]">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="text-accent-amber" size={20} />
          <p className="text-[10px] font-black text-text-muted uppercase">활성 패키지</p>
        </div>
        <p className="text-3xl font-black text-accent-amber mb-2">2개</p>
        <p className="text-[9px] text-text-muted">진행 중인 투자</p>
      </div>

      {/* 다음 만기일 */}
      <div className="dashboard-card p-6 border-white/10 bg-black/40">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="text-text-muted" size={20} />
          <p className="text-[10px] font-black text-text-muted uppercase">다음 만기</p>
        </div>
        <p className="text-2xl font-black text-white mb-2">2024.01.15</p>
        <p className="text-[9px] text-text-muted">VIP 패키지</p>
      </div>
    </div>
  );
}
