import { Users, ClipboardCheck, Activity, Zap, Ban, ArrowRight, Wallet } from 'lucide-react';
import { cn } from '../lib/utils';
import { RevenueCapProgressChart } from './RevenueCapProgressChart';
import { CostReductionTracker } from './CostReductionTracker';
import { StatsCard } from './shared';

// Mock 데이터 (프론트엔드 독립 실행용)
const MOCK_REVENUE_DATA = {
  totalBalance: 235_000_000,  // 총 입금액
  totalWithdrawals: 125_500_000,  // 총 출금액
  totalRefunds: 750,
  netRevenue: 6_050,
  memberCount: 5
};

const MOCK_MEMBERS_STATS = {
  total: 5,
  byPackage: {
    Flexible: 1,
    Basic: 1,
    Standard: 1,
    Premium: 1,
    VIP: 1
  },
  totalBalance: 235_000_000
};

const MOCK_ALL_MEMBERS = [
  { id: 'member_001', userId: 'user_vip_001', package: 'VIP' },
  { id: 'member_002', userId: 'user_premium_001', package: 'Premium' },
  { id: 'member_003', userId: 'user_standard_001', package: 'Standard' },
  { id: 'member_004', userId: 'user_basic_001', package: 'Basic' },
  { id: 'member_005', userId: 'user_flexible_001', package: 'Flexible' }
];

export function Dashboard() {
  // Mock 데이터 직접 사용 (API 호출 없음)
  const revenueData = MOCK_REVENUE_DATA;
  const membersStats = MOCK_MEMBERS_STATS;
  const allMembers = MOCK_ALL_MEMBERS;
  const error = null;

  return (
    <div className="space-y-6">
      {/* 에러 표시 */}
      {error && (
        <div className="px-6 p-4 rounded-lg border border-red-500/50 bg-red-500/10">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {/* 1. 총 입금/출금 핵심 지표 (Priority Metrics) */}
      <div className="px-6 grid grid-cols-1 md:grid-cols-2 gap-4">
         <StatsCard
            title="총 입금액"
            value={(revenueData?.totalBalance || 0).toLocaleString()}
            unit="USDT"
            color="blue"
            icon={<Wallet size={24} />}
            size="lg"
         />
         <StatsCard
            title="총 출금액"
            value={(revenueData?.totalWithdrawals || 0).toLocaleString()}
            unit="USDT"
            color="amber"
            icon={<ArrowRight size={24} />}
            size="lg"
         />
      </div>

      {/* 2. 추가 모니터링 지표 (Compact Cards) */}
      <div className="px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
         <StatsCard
            title="전체 회원수"
            value={allMembers.length || 0}
            unit="명"
            color="blue"
            icon={<Users size={20} />}
            size="sm"
         />
         <StatsCard
            title="승인 대기 요청"
            value={148}
            unit="건"
            color="amber"
            icon={<ClipboardCheck size={20} />}
            size="sm"
         />
         <StatsCard
            title="이상거래 감지"
            value={3}
            unit="건"
            color="red"
            icon={<Activity size={20} />}
            size="sm"
         />
      </div>

      {/* 2. 패키지 활성화 분포 (Package Activation) - 5가지 등급별 투자 현황 */}
      <div className="px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
         <StatsCard
            title="Flexible"
            value={membersStats?.byPackage?.Flexible || 0}
            unit="100 USDT"
            color="blue"
            size="sm"
         />
         <StatsCard
            title="Basic"
            value={membersStats?.byPackage?.Basic || 0}
            unit="200 USDT"
            color="blue"
            size="sm"
         />
         <StatsCard
            title="Standard"
            value={membersStats?.byPackage?.Standard || 0}
            unit="500 USDT"
            color="purple"
            size="sm"
         />
         <StatsCard
            title="Premium"
            value={membersStats?.byPackage?.Premium || 0}
            unit="1000 USDT"
            color="amber"
            size="sm"
         />
         <StatsCard
            title="VIP"
            value={membersStats?.byPackage?.VIP || 0}
            unit="5000 USDT"
            color="red"
            size="sm"
         />
      </div>

      {/* 3. 메인 제어 센터 (Main Control Hub) - 여기서 다 누르고 조절함 */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 px-6">
        
        {/* Quick ROI & Payout Control */}
        <div className="xl:col-span-2 dashboard-card border-accent-blue/20">
           <div className="flex items-center gap-2 mb-6 pb-4 border-b border-white/5">
              <Zap size={18} className="text-accent-blue" />
              <h3 className="text-sm font-black text-white uppercase tracking-widest">실시간 운영 엔진 제어 (Admin Commander)</h3>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* ROI 제어 섹션 */}
              <div className="space-y-4">
                 <p className="text-[10px] font-black text-text-muted uppercase tracking-widest">데일리 ROI 및 수당 관리</p>
                 <div className="bg-black/40 border border-white/5 p-4 rounded-xl space-y-4">
                    <div className="flex items-center justify-between">
                       <span className="text-xs font-bold text-white">AI 데일리 ROI</span>
                       <div className="flex items-center gap-2 bg-black/60 px-3 py-1 rounded border border-accent-blue/30">
                          <input type="number" defaultValue={1.5} className="bg-transparent text-sm font-black text-accent-blue w-10 outline-none" />
                          <span className="text-[10px] font-bold text-accent-blue/50">%</span>
                       </div>
                    </div>
                    <div className="flex items-center justify-between">
                       <span className="text-xs font-bold text-white">CNYT 가입 정산 엔진</span>
                       <button className="w-10 h-5 bg-accent-green rounded-full relative">
                          <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full" />
                       </button>
                    </div>
                    <button className="w-full py-2 bg-accent-blue text-slate-900 text-[10px] font-black uppercase tracking-widest rounded hover:bg-accent-blue/80 transition-all">설정 수치 즉시 반영</button>
                 </div>
              </div>

              {/* CNYT 리워드 비율 및 긴급 제어 */}
              <div className="space-y-4">
                 <p className="text-[10px] font-black text-text-muted uppercase tracking-widest">기능 제어 및 긴급 액션</p>
                 <div className="bg-black/40 border border-white/5 p-4 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                       <span className="text-xs font-bold text-white">CNYT 리워드 배수</span>
                       <span className="text-xs font-black text-accent-amber">1000 : 10</span>
                    </div>
                    <button className="w-full py-2 bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 text-red-500 text-[10px] font-black uppercase tracking-widest rounded flex items-center justify-center gap-2 transition-all">
                       <Ban size={12} /> 전체 출금 일시 중단
                    </button>
                    <button className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white text-[10px] font-black uppercase tracking-widest rounded transition-all">
                       FDS 이상거래 일괄 동결
                    </button>
                 </div>
              </div>
           </div>
        </div>

        {/* 심사 대기 간략 피드 (Actionable Feed) */}
        <div className="dashboard-card border-border-main bg-black/40">
           <div className="flex items-center justify-between mb-6 pb-2 border-b border-border-main">
              <h3 className="text-[11px] font-black text-white uppercase tracking-widest">미처리 승인 알림 (Pending)</h3>
              <span className="text-[9px] font-black text-accent-blue uppercase">새 알림 5건</span>
           </div>
           
           <div className="space-y-4">
              <QuickTaskItem name="Whale_Hunter" info="50,000 USDT 출금" msg="고액 승인 필요" time="12분 전" />
              <QuickTaskItem name="Investor_99" info="KYC 신원 인증" msg="서류 검토 대기" time="24분 전" />
              <QuickTaskItem name="LR-1004" info="비정상 롤업 탐지" msg="수당 감사 요망" time="1시간 전" />
              <QuickTaskItem name="New_Dragon" info="Black 등급 승급" msg="매출 검증 필요" time="3시간 전" />
           </div>

           <button className="w-full mt-8 py-2 border border-white/10 rounded text-[10px] font-black text-text-muted uppercase hover:bg-white/5 transition-all">전체 업무 창으로 이동</button>
        </div>

      </div>

      {/* 3. 처리 대기 큐 (Simplified Work Queue) - 바로 버튼 눌러서 처리 */}
      <div className="px-6 pb-12">
         <div className="dashboard-card p-0 overflow-hidden border-border-main">
            <div className="p-6 border-b border-border-main bg-black/10 flex items-center justify-between">
               <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">주요 업무 승인 대기열 (Action Queue)</h3>
               <button className="text-[10px] font-bold text-accent-blue uppercase">전체 보기</button>
            </div>

            <table className="data-table table-fixed">
               <thead>
                  <tr>
                     <th className="!text-center text-[10px]">유형</th>
                     <th className="!text-center text-[10px]">회원 정보</th>
                     <th className="!text-center text-[10px]">요청 내용</th>
                     <th className="!text-center text-[10px]">시간</th>
                     <th className="!text-center text-[10px]">최종 결정</th>
                  </tr>
               </thead>
               <tbody>
                  <QueueRow type="출금" user="Whale_Hunter (LR-0051)" amount="50,000 USDT" time="12분 전" />
                  <QueueRow type="KYC" user="Investor_99 (LR-1002)" amount="신분증 검토" time="24분 전" />
                  <QueueRow type="승급" user="Leader_X (LR-0881)" amount="Black Dragon" time="1시간 전" />
               </tbody>
            </table>
         </div>
      </div>
    </div>
  );
}


function QueueRow({ type, user, amount, time }: any) {
  return (
    <tr className="hover:bg-white/[0.01]">
       <td className="!text-center overflow-hidden">
          <div className="flex items-center justify-center"><span className={cn("text-[9px] font-black uppercase px-2 py-0.5 rounded border", type === '출금' ? 'text-red-400 border-red-500/20' : 'text-accent-blue border-accent-blue/20')}>{type}</span></div>
       </td>
       <td className="!text-center overflow-hidden"><span className="text-[11px] font-bold text-white truncate block">{user}</span></td>
       <td className="text-center overflow-hidden text-[11px] font-black text-accent-blue truncate">{amount}</td>
       <td className="text-center overflow-hidden text-[10px] text-text-muted font-mono truncate">{time}</td>
       <td className="!text-center overflow-hidden">
          <div className="flex items-center justify-center">
             <div className="flex justify-center gap-2">
                <button className="px-3 py-1 bg-red-500 text-white text-[10px] font-black rounded hover:bg-red-600 transition-all uppercase tracking-widest">반려</button>
                <button className="px-3 py-1 bg-accent-green text-white text-[10px] font-black rounded hover:bg-accent-green/80 transition-all uppercase tracking-widest">승인</button>
             </div>
          </div>
       </td>
    </tr>
  );
}

function QuickTaskItem({ name, info, msg, time }: any) {
  return (
    <div className="flex items-center justify-between group py-1.5 border-b border-white/[0.03] last:border-0">
       <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex flex-col shrink-0">
             <span className="text-[11px] font-bold text-white group-hover:text-accent-blue transition-colors whitespace-nowrap">{name}</span>
             <span className="text-[8px] text-text-muted font-bold uppercase tracking-tighter">{time}</span>
          </div>
          <div className="h-3 w-px bg-white/10 shrink-0" />
          <div className="flex items-center gap-2 overflow-hidden">
             <span className="text-[10px] text-text-muted font-bold uppercase shrink-0">[{info}]</span>
             <span className="text-[10px] text-red-400 font-bold tracking-tighter truncate">{msg}</span>
          </div>
       </div>
       <ArrowRight size={12} className="text-text-muted opacity-0 group-hover:opacity-100 transition-all shrink-0" />
    </div>
  );
}
