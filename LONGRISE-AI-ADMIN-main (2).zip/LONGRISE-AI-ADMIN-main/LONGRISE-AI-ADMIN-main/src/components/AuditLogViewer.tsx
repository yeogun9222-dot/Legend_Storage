/**
 * Audit Log Viewer
 * 모든 관리자 작업 감사 로그 조회 및 필터링
 */

import { useState } from 'react';
import {
  Search,
  Download,
  Filter,
  ChevronDown,
  Clock,
  User,
  FileText,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AuditLog } from '../types';
import { getAuditLogs, exportAuditLogsAsCSV } from '../lib/auditLogger';

type FilterStatus = 'all' | 'success' | 'failed';
type FilterAction = 'all' | string;

// Mock audit logs for demonstration
const MOCK_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'audit_001',
    adminId: 'admin_001',
    adminName: '제이크 (총괄 관리자)',
    action: '잔액 조정',
    resource: 'user',
    resourceId: 'user_001',
    changes: {
      before: { usdt: 1000 },
      after: { usdt: 1500 },
    },
    status: 'success',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    ipAddress: '192.168.1.1',
  },
  {
    id: 'audit_002',
    adminId: 'admin_001',
    adminName: '제이크 (총괄 관리자)',
    action: '계정 잠금',
    resource: 'user',
    resourceId: 'user_002',
    changes: {
      before: { isLocked: false },
      after: { isLocked: true },
    },
    status: 'success',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    ipAddress: '192.168.1.1',
  },
  {
    id: 'audit_003',
    adminId: 'admin_002',
    adminName: '제인 (재무 담당자)',
    action: '출금 승인',
    resource: 'withdrawal',
    resourceId: 'wd_001',
    changes: {
      before: { status: 'pending' },
      after: { status: 'approved' },
    },
    status: 'success',
    timestamp: new Date(Date.now() - 10800000).toISOString(),
    ipAddress: '192.168.1.2',
  },
  {
    id: 'audit_004',
    adminId: 'admin_001',
    adminName: '제이크 (총괄 관리자)',
    action: 'KYC 초기화',
    resource: 'kyc',
    resourceId: 'user_003',
    changes: {
      before: { status: 'approved' },
      after: { status: 'pending' },
    },
    status: 'success',
    timestamp: new Date(Date.now() - 14400000).toISOString(),
    ipAddress: '192.168.1.1',
  },
  {
    id: 'audit_005',
    adminId: 'admin_003',
    adminName: '마이크 (보안 담당자)',
    action: '자산 동결',
    resource: 'user',
    resourceId: 'user_004',
    changes: {
      before: { isFrozen: false },
      after: { isFrozen: true },
    },
    status: 'success',
    timestamp: new Date(Date.now() - 18000000).toISOString(),
    ipAddress: '192.168.1.3',
  },
];

export function AuditLogViewer() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [actionFilter, setActionFilter] = useState<FilterAction>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  // Get audit logs (prioritize local storage, fallback to mock)
  const allLogs = [...getAuditLogs(), ...MOCK_AUDIT_LOGS];
  const uniqueLogs = Array.from(new Map(allLogs.map(log => [log.id, log])).values());

  // Filter logs
  const filteredLogs = uniqueLogs.filter(log => {
    const matchesSearch = searchTerm === '' ||
      log.adminName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.resourceId.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || log.status === statusFilter;
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;

    const logDate = new Date(log.timestamp);
    const matchesDateRange =
      (!dateRange.start || logDate >= new Date(dateRange.start)) &&
      (!dateRange.end || logDate <= new Date(dateRange.end));

    return matchesSearch && matchesStatus && matchesAction && matchesDateRange;
  });

  // Get unique actions for filter
  const uniqueActions = Array.from(new Set(uniqueLogs.map(log => log.action)));

  const handleExport = () => {
    const csv = exportAuditLogsAsCSV(filteredLogs);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `audit_logs_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 px-6 pb-12">
      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="dashboard-card border-border-main">
          <h4 className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-2">
            총 로그 수
          </h4>
          <p className="text-2xl font-black text-text-primary tabular-nums">
            {uniqueLogs.length}
          </p>
        </div>
        <div className="dashboard-card border-border-main">
          <h4 className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-2">
            성공한 작업
          </h4>
          <p className="text-2xl font-black text-accent-green tabular-nums">
            {uniqueLogs.filter(l => l.status === 'success').length}
          </p>
        </div>
        <div className="dashboard-card border-border-main">
          <h4 className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-2">
            실패한 작업
          </h4>
          <p className="text-2xl font-black text-red-500 tabular-nums">
            {uniqueLogs.filter(l => l.status === 'failed').length}
          </p>
        </div>
        <div className="dashboard-card border-border-main">
          <h4 className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-2">
            고유 관리자
          </h4>
          <p className="text-2xl font-black text-accent-blue tabular-nums">
            {Array.from(new Set(uniqueLogs.map(l => l.adminId))).length}
          </p>
        </div>
      </div>

      {/* 필터 및 검색 */}
      <div className="dashboard-card border-border-main p-6 space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter size={16} className="text-accent-blue" />
          <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">
            필터 & 검색
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* 검색 */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-3 text-text-muted" />
            <input
              type="text"
              placeholder="관리자명, 액션, 리소스 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-blue/50"
            />
          </div>

          {/* 상태 필터 */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as FilterStatus)}
            className="px-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary focus:outline-none focus:border-accent-blue/50"
          >
            <option value="all">모든 상태</option>
            <option value="success">성공</option>
            <option value="failed">실패</option>
          </select>

          {/* 액션 필터 */}
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="px-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary focus:outline-none focus:border-accent-blue/50"
          >
            <option value="all">모든 액션</option>
            {uniqueActions.map(action => (
              <option key={action} value={action}>
                {action}
              </option>
            ))}
          </select>

          {/* 내보내기 */}
          <button
            onClick={handleExport}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-accent-blue/10 text-accent-blue border border-accent-blue/30 rounded text-[11px] font-bold hover:bg-accent-blue/20 transition-colors"
          >
            <Download size={14} />
            CSV 내보내기
          </button>
        </div>

        {/* 날짜 범위 */}
        <div className="grid grid-cols-2 md:grid-cols-2 gap-4 pt-2 border-t border-border-main/30">
          <div>
            <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2 block">
              시작 날짜
            </label>
            <input
              type="datetime-local"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="w-full px-3 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary focus:outline-none focus:border-accent-blue/50"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2 block">
              종료 날짜
            </label>
            <input
              type="datetime-local"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="w-full px-3 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary focus:outline-none focus:border-accent-blue/50"
            />
          </div>
        </div>
      </div>

      {/* 로그 테이블 */}
      <div className="dashboard-card p-0 overflow-hidden border-border-main shadow-sm">
        <div className="p-6 border-b border-border-main bg-black/10">
          <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">
            📋 감사 로그 ({filteredLogs.length}개)
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="data-table table-fixed w-full">
            <thead>
              <tr>
                <th className="!text-center text-[10px]">시간</th>
                <th className="!text-center text-[10px]">관리자</th>
                <th className="!text-center text-[10px]">액션</th>
                <th className="!text-center text-[10px]">리소스</th>
                <th className="!text-center text-[10px]">상태</th>
                <th className="!text-center text-[10px]">IP 주소</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log) => (
                <tr
                  key={log.id}
                  className="hover:bg-white/[0.02] group cursor-pointer"
                  onClick={() => setExpandedId(expandedId === log.id ? null : log.id)}
                >
                  <td className="!text-center overflow-hidden">
                    <div className="flex items-center justify-center gap-2">
                      <Clock size={12} className="text-text-muted" />
                      <span className="text-[10px] text-text-muted font-mono">
                        {new Date(log.timestamp).toLocaleString('ko-KR')}
                      </span>
                    </div>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <div className="flex items-center justify-center gap-2">
                      <User size={12} className="text-accent-blue" />
                      <span className="text-[11px] font-bold text-text-primary truncate">
                        {log.adminName}
                      </span>
                    </div>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <div className="flex items-center justify-center gap-2">
                      <FileText size={12} className="text-accent-amber" />
                      <span className="text-[11px] font-bold text-text-primary truncate">
                        {log.action}
                      </span>
                    </div>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span className="text-[10px] text-text-muted font-mono truncate block">
                      {log.resource} ({log.resourceId})
                    </span>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span
                      className={cn(
                        'text-[9px] font-black px-2 py-1 rounded uppercase inline-flex items-center gap-1',
                        log.status === 'success'
                          ? 'bg-accent-green/20 text-accent-green'
                          : 'bg-red-500/20 text-red-400'
                      )}
                    >
                      {log.status === 'success' ? (
                        <CheckCircle2 size={10} />
                      ) : (
                        <XCircle size={10} />
                      )}
                      {log.status === 'success' ? '성공' : '실패'}
                    </span>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span className="text-[10px] text-text-muted font-mono truncate block">
                      {log.ipAddress || 'N/A'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredLogs.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-[11px] text-text-muted">조건에 맞는 로그가 없습니다</p>
          </div>
        )}
      </div>

      {/* 상세 정보 */}
      {expandedId && (
        <div className="dashboard-card border-accent-blue/30 bg-accent-blue/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-bold text-text-primary uppercase tracking-wider">
              상세 정보
            </h4>
            <button
              onClick={() => setExpandedId(null)}
              className="text-text-muted hover:text-text-primary transition-colors"
            >
              <ChevronDown size={16} />
            </button>
          </div>

          {filteredLogs
            .filter(log => log.id === expandedId)
            .map(log => (
              <div key={log.id} className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-widest mb-1">
                      로그 ID
                    </p>
                    <p className="text-[10px] text-text-primary font-mono">{log.id}</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-widest mb-1">
                      관리자 ID
                    </p>
                    <p className="text-[10px] text-text-primary font-mono">{log.adminId}</p>
                  </div>
                </div>

                {log.changes && Object.keys(log.changes).length > 0 && (
                  <div>
                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-widest mb-2">
                      변경사항
                    </p>
                    <pre className="text-[8px] text-text-muted bg-black/40 p-3 rounded overflow-auto max-h-48 font-mono">
                      {JSON.stringify(log.changes, null, 2)}
                    </pre>
                  </div>
                )}

                {log.errorMessage && (
                  <div>
                    <p className="text-[9px] font-bold text-red-400 uppercase tracking-widest mb-1">
                      오류 메시지
                    </p>
                    <p className="text-[10px] text-red-300">{log.errorMessage}</p>
                  </div>
                )}
              </div>
            ))}
        </div>
      )}
    </div>
  );
}
