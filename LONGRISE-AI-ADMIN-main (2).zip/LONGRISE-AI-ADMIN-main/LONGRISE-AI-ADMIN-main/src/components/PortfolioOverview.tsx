/**
 * Portfolio Overview Component
 * 투자 패키지 현황
 */

import { Calendar, DollarSign, TrendingUp, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';
import type { MemberPackage } from '../lib/mockMemberData';

interface PortfolioOverviewProps {
  packages: MemberPackage[];
  onTerminationClick: (packageId: string) => void;
}

export function PortfolioOverview({ packages, onTerminationClick }: PortfolioOverviewProps) {
  const getPackageColor = (type: string) => {
    switch (type) {
      case 'Flexible':
        return 'border-slate-500 bg-slate-900/30';
      case 'Basic':
        return 'border-accent-blue/30 bg-accent-blue/[0.08]';
      case 'Standard':
        return 'border-purple-500/30 bg-purple-500/[0.08]';
      case 'Premium':
        return 'border-accent-amber/30 bg-accent-amber/[0.08]';
      case 'VIP':
        return 'border-red-500/30 bg-red-500/[0.08]';
      default:
        return 'border-white/10 bg-black/40';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-accent-green bg-accent-green/20';
      case 'early_termination_pending':
        return 'text-accent-amber bg-accent-amber/20';
      case 'early_terminated':
        return 'text-red-500 bg-red-500/20';
      case 'matured':
        return 'text-accent-blue bg-accent-blue/20';
      default:
        return 'text-text-muted bg-white/10';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return '✅ 진행중';
      case 'early_termination_pending':
        return '⏳ 환급처리중';
      case 'early_terminated':
        return '❌ 중도해지';
      case 'matured':
        return '🎉 만기도달';
      default:
        return status;
    }
  };

  const calculateDaysRemaining = (maturityDate: Date) => {
    const now = new Date();
    const diffTime = maturityDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };

  return (
    <div className="dashboard-card p-6 border-border-main mb-6">
      <div className="mb-6">
        <h2 className="text-sm font-black text-white uppercase tracking-widest mb-1">
          📊 투자 현황 (포트폴리오)
        </h2>
        <p className="text-[10px] text-text-muted">총 {packages.length}개 패키지 진행 중</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {packages.map((pkg) => {
          const daysRemaining = calculateDaysRemaining(pkg.maturityDate);
          const progressPercent = (pkg.expectedROI > 0 ? pkg.currentROI / pkg.expectedROI : 0) * 100;

          return (
            <div
              key={pkg.id}
              className={cn('border rounded-lg p-4 transition-all hover:border-white/20', getPackageColor(pkg.packageType))}
            >
              {/* 헤더 */}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm font-black text-white">{pkg.packageType}</p>
                  <p className="text-[9px] text-text-muted uppercase mt-0.5">패키지</p>
                </div>
                <span className={cn('text-[9px] font-black uppercase px-2 py-1 rounded', getStatusColor(pkg.status))}>
                  {getStatusLabel(pkg.status)}
                </span>
              </div>

              {/* 주요 정보 */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                {/* 원금 */}
                <div className="bg-black/20 p-2 rounded">
                  <p className="text-[8px] text-text-muted uppercase font-bold mb-1">원금</p>
                  <p className="text-lg font-black text-white">
                    ${pkg.principal.toLocaleString()}
                  </p>
                </div>

                {/* 현재 잔액 */}
                <div className="bg-black/20 p-2 rounded">
                  <p className="text-[8px] text-text-muted uppercase font-bold mb-1">현재 잔액</p>
                  <p className="text-lg font-black text-accent-green">
                    ${pkg.currentBalance.toLocaleString()}
                  </p>
                </div>

                {/* ROI 진행률 */}
                <div className="bg-black/20 p-2 rounded">
                  <p className="text-[8px] text-text-muted uppercase font-bold mb-1">현재 ROI</p>
                  <p className="text-lg font-black text-accent-blue">
                    {pkg.currentROI.toFixed(1)}%
                  </p>
                </div>

                {/* 예상 ROI */}
                <div className="bg-black/20 p-2 rounded">
                  <p className="text-[8px] text-text-muted uppercase font-bold mb-1">예상 ROI</p>
                  <p className="text-lg font-black text-accent-amber">
                    {pkg.expectedROI.toFixed(1)}%
                  </p>
                </div>
              </div>

              {/* ROI 진행도 바 */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[9px] text-text-muted font-bold">진행도</span>
                  <span className="text-[9px] font-black text-accent-blue">
                    {progressPercent.toFixed(0)}%
                  </span>
                </div>
                <div className="h-2 bg-black/40 rounded-full overflow-hidden border border-white/5">
                  <div
                    className="h-full bg-gradient-to-r from-accent-blue to-accent-blue/60 transition-all"
                    style={{ width: `${Math.min(progressPercent, 100)}%` }}
                  />
                </div>
              </div>

              {/* 일정 정보 */}
              <div className="grid grid-cols-2 gap-3 mb-4 text-[9px]">
                <div className="flex items-start gap-2">
                  <Calendar size={14} className="text-text-muted mt-0.5" />
                  <div>
                    <p className="text-text-muted uppercase font-bold">진입일</p>
                    <p className="text-white font-bold">
                      {pkg.joinDate.toLocaleDateString('ko-KR')}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Calendar size={14} className="text-text-muted mt-0.5" />
                  <div>
                    <p className="text-text-muted uppercase font-bold">만기일</p>
                    <p className="text-accent-amber font-bold">
                      {pkg.maturityDate.toLocaleDateString('ko-KR')}
                    </p>
                  </div>
                </div>
              </div>

              {/* 남은 날짜 */}
              {pkg.status === 'active' && (
                <div className="bg-accent-blue/20 border border-accent-blue/30 rounded p-2 mb-4 flex items-start gap-2">
                  <AlertCircle size={14} className="text-accent-blue mt-0.5 shrink-0" />
                  <p className="text-[9px] text-accent-blue font-bold">
                    만기까지 <span className="font-black">{daysRemaining}일</span> 남음
                  </p>
                </div>
              )}

              {/* 환급 정보 */}
              <div className="bg-black/20 p-2 rounded mb-4">
                <div className="flex items-center gap-2 mb-1">
                  <DollarSign size={12} className="text-text-muted" />
                  <p className="text-[8px] text-text-muted uppercase font-bold">만기 환급액</p>
                </div>
                <p className="text-lg font-black text-accent-green">
                  ${pkg.expectedRefund.toLocaleString()}
                </p>
                <p className="text-[8px] text-text-muted mt-1">
                  수익: ${(pkg.expectedRefund - pkg.principal).toLocaleString()}
                </p>
              </div>

              {/* 중도해지 버튼 */}
              {pkg.status === 'active' && (
                <button
                  onClick={() => onTerminationClick(pkg.id)}
                  className="w-full py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-500 text-[10px] font-black uppercase rounded transition-all"
                >
                  📋 중도해지 신청
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
