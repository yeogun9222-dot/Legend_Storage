/**
 * Transaction History Component
 * 거래 이력 표시
 */

import { ArrowUpRight, ArrowDownLeft, Zap, TrendingUp, CheckCircle2, Clock } from 'lucide-react';
import { cn } from '../lib/utils';
import type { Transaction } from '../lib/mockMemberData';

interface TransactionHistoryProps {
  transactions: Transaction[];
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownLeft className="text-accent-green" size={16} />;
      case 'withdrawal':
        return <ArrowUpRight className="text-red-500" size={16} />;
      case 'earning':
        return <Zap className="text-accent-blue" size={16} />;
      case 'bonus':
        return <TrendingUp className="text-accent-amber" size={16} />;
      case 'termination':
        return <ArrowUpRight className="text-text-muted" size={16} />;
      default:
        return <Zap className="text-text-muted" size={16} />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'deposit':
        return 'text-accent-green';
      case 'withdrawal':
        return 'text-red-500';
      case 'earning':
        return 'text-accent-blue';
      case 'bonus':
        return 'text-accent-amber';
      case 'termination':
        return 'text-text-muted';
      default:
        return 'text-text-primary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="text-accent-green" size={14} />;
      case 'pending':
        return <Clock className="text-accent-amber" size={14} />;
      case 'failed':
        return <div className="w-3.5 h-3.5 rounded-full bg-red-500" />;
      default:
        return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return '완료';
      case 'pending':
        return '진행중';
      case 'failed':
        return '실패';
      default:
        return status;
    }
  };

  const getSignPrefix = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'earning':
      case 'bonus':
        return '+';
      case 'withdrawal':
      case 'termination':
        return '-';
      default:
        return '';
    }
  };

  return (
    <div className="dashboard-card p-6 border-border-main">
      <div className="mb-6">
        <h2 className="text-sm font-black text-white uppercase tracking-widest mb-1">
          📜 거래 이력
        </h2>
        <p className="text-[10px] text-text-muted">최근 {transactions.length}개 거래</p>
      </div>

      <div className="space-y-2">
        {transactions.length === 0 ? (
          <p className="text-center text-[10px] text-text-muted py-8">거래 이력이 없습니다</p>
        ) : (
          transactions.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between p-3 bg-black/20 border border-white/5 rounded hover:bg-black/30 transition-all"
            >
              {/* 좌측: 아이콘 & 정보 */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="flex-shrink-0">{getTransactionIcon(tx.type)}</div>

                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-black text-white truncate">{tx.description}</p>
                  <p className="text-[8px] text-text-muted mt-0.5">
                    {tx.date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>

              {/* 우측: 금액 & 상태 */}
              <div className="flex items-center gap-4 flex-shrink-0">
                <div className="text-right">
                  <p className={cn('text-sm font-black', getTransactionColor(tx.type))}>
                    {getSignPrefix(tx.type)}${tx.amount.toLocaleString()}
                  </p>
                  <p className="text-[8px] text-text-muted mt-0.5">{tx.asset}</p>
                </div>

                <div className="flex items-center gap-1">
                  {getStatusIcon(tx.status)}
                  <span className="text-[8px] text-text-muted uppercase font-bold">
                    {getStatusLabel(tx.status)}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 더보기 버튼 */}
      {transactions.length > 0 && (
        <button className="w-full py-2 mt-4 text-[10px] font-black text-accent-blue uppercase hover:text-accent-blue/80 transition-colors">
          모든 거래 보기
        </button>
      )}
    </div>
  );
}
