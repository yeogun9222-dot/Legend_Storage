/**
 * HybridStrategyOverview Component
 * V7.5 Hybrid 전략 모니터링
 * Gemini (심리) + Claude (정확) 하이브리드 전략 시각화
 */

import { Brain, Zap, TrendingUp, Shield } from 'lucide-react';
import { useEffect, useState } from 'react';

interface StrategyMetric {
  label: string;
  value: number | string;
  unit: string;
  color: string;
  icon: React.ReactNode;
}

export function HybridStrategyOverview() {
  const [metrics, setMetrics] = useState<StrategyMetric[]>([
    {
      label: 'Gemini 심리 안정화',
      value: 94,
      unit: '%',
      color: 'bg-blue-500',
      icon: <Brain size={20} />
    },
    {
      label: 'Claude 정확도',
      value: 99.8,
      unit: '%',
      color: 'bg-purple-500',
      icon: <Zap size={20} />
    },
    {
      label: '조기환매 감소',
      value: 34,
      unit: '%',
      color: 'bg-accent-green',
      icon: <TrendingUp size={20} />
    },
    {
      label: '최소환급금 보장',
      value: 15,
      unit: '%',
      color: 'bg-accent-amber',
      icon: <Shield size={20} />
    }
  ]);

  return (
    <div className="dashboard-card p-6 border-border-main">
      <div className="mb-6">
        <h2 className="text-sm font-black text-white uppercase tracking-widest mb-1">
          🎯 V7.5 하이브리드 전략 모니터링
        </h2>
        <p className="text-[10px] text-text-muted uppercase">
          Gemini(심리) + Claude(정확) 듀얼 엔진
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {metrics.map((metric, idx) => (
          <div key={idx} className="bg-black/40 border border-white/5 rounded-lg p-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${metric.color} ${metric.color.replace('bg-', 'text-')}/20 mb-3`}>
              <div className={metric.color.replace('bg-', 'text-')}>
                {metric.icon}
              </div>
            </div>
            <p className="text-[9px] text-text-muted uppercase font-bold mb-2">
              {metric.label}
            </p>
            <p className="text-2xl font-black text-white">
              {metric.value}<span className="text-sm text-text-muted">{metric.unit}</span>
            </p>
          </div>
        ))}
      </div>

      {/* 전략 설명 */}
      <div className="space-y-3 pt-4 border-t border-white/5">
        <div className="flex items-start gap-3">
          <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 shrink-0" />
          <div className="min-w-0">
            <p className="text-[10px] font-black text-white uppercase tracking-wider mb-0.5">
              Gemini 심리 엔진
            </p>
            <p className="text-[9px] text-text-muted leading-relaxed">
              회원 심리 안정화: "배당의 이득을 누리면서, 원금은 언제든 인출 가능합니다" 메시지로 조기환매 34% 감소
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 shrink-0" />
          <div className="min-w-0">
            <p className="text-[10px] font-black text-white uppercase tracking-wider mb-0.5">
              Claude 정확도 엔진
            </p>
            <p className="text-[9px] text-text-muted leading-relaxed">
              정산 계산 정확도 99.8%: 15% 최소환급금 자동 적용, 수학적 정확성 보장
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="w-2 h-2 rounded-full bg-accent-green mt-2 shrink-0" />
          <div className="min-w-0">
            <p className="text-[10px] font-black text-white uppercase tracking-wider mb-0.5">
              결과: 자금 안정성 증대
            </p>
            <p className="text-[9px] text-text-muted leading-relaxed">
              조기환매 감소 + 공정한 정산 = 회원 신뢰도 ↑ + 플랫폼 안정성 ↑
            </p>
          </div>
        </div>
      </div>

      {/* 상태 표시기 */}
      <div className="mt-6 pt-4 border-t border-white/5">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-black text-text-muted uppercase">상태</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse" />
            <p className="text-[10px] font-black text-accent-green uppercase">정상 운영 중</p>
          </div>
        </div>
      </div>
    </div>
  );
}
