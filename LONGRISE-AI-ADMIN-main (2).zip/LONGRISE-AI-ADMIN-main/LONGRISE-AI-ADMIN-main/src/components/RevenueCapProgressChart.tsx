/**
 * RevenueCapProgressChart Component
 * 수익 캡 진행도 모니터링
 * 목표: $300M (80% = $240M 경고, 90% = $270M 긴급)
 */

import { AlertCircle, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { cn } from '../lib/utils';

interface RevenueMetrics {
  currentRevenue: number;
  target: number;
  warningThreshold: number; // 80%
  criticalThreshold: number; // 90%
  lastUpdate: string;
}

export function RevenueCapProgressChart() {
  const [metrics, setMetrics] = useState<RevenueMetrics>({
    currentRevenue: 235_000_000,
    target: 300_000_000,
    warningThreshold: 240_000_000,
    criticalThreshold: 270_000_000,
    lastUpdate: new Date().toLocaleTimeString('ko-KR')
  });

  const percent = (metrics.currentRevenue / metrics.target) * 100;
  const isWarning = percent >= 80 && percent < 90;
  const isCritical = percent >= 90;

  // 실시간 수익 데이터 갱신 (5초마다 시뮬레이션)
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        currentRevenue: Math.min(
          prev.currentRevenue + Math.random() * 5_000_000,
          prev.target
        ),
        lastUpdate: new Date().toLocaleTimeString('ko-KR')
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = () => {
    if (isCritical) return 'text-red-500';
    if (isWarning) return 'text-amber-500';
    return 'text-accent-green';
  };

  const getStatusBg = () => {
    if (isCritical) return 'bg-red-500/20 border-red-500/50';
    if (isWarning) return 'bg-amber-500/20 border-amber-500/50';
    return 'bg-accent-green/20 border-accent-green/50';
  };

  return (
    <div className="dashboard-card p-6 border-border-main">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-widest">
              📊 수익 캡 진행도 모니터링
            </h2>
            <p className="text-[10px] text-text-muted uppercase mt-1">
              목표: $300M | 업데이트: {metrics.lastUpdate}
            </p>
          </div>
          <div className={cn(
            "px-3 py-1.5 rounded-lg border text-center",
            getStatusBg()
          )}>
            <p className={cn("text-[10px] font-black uppercase", getStatusColor())}>
              {isCritical ? '🔴 긴급' : isWarning ? '🟡 경고' : '🟢 정상'}
            </p>
          </div>
        </div>
      </div>

      {/* 메인 진행 바 */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-white">
            진행도: {percent.toFixed(1)}%
          </span>
          <span className="text-xs font-black text-text-muted">
            ${(metrics.currentRevenue / 1_000_000).toFixed(0)}M / ${(metrics.target / 1_000_000).toFixed(0)}M
          </span>
        </div>

        <div className="relative h-8 bg-black/40 border border-white/10 rounded-lg overflow-hidden">
          {/* 안전 구간 (0-80%) */}
          <div
            className="absolute h-full bg-gradient-to-r from-accent-green to-accent-green/60"
            style={{ width: '80%' }}
          />

          {/* 경고 구간 (80-90%) */}
          <div
            className="absolute h-full bg-gradient-to-r from-accent-amber to-amber-600/60"
            style={{ left: '80%', width: '10%' }}
          />

          {/* 긴급 구간 (90-100%) */}
          <div
            className="absolute h-full bg-gradient-to-r from-red-600 to-red-700/60"
            style={{ left: '90%', width: '10%' }}
          />

          {/* 현재 위치 표시 */}
          <div
            className={cn(
              "absolute h-full border-r-2 transition-all",
              isCritical ? 'border-red-500' : isWarning ? 'border-amber-500' : 'border-accent-green'
            )}
            style={{ left: `${Math.min(percent, 100)}%` }}
          />

          {/* 진행도 텍스트 */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-sm font-black text-white drop-shadow-lg">
              {percent.toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* 임계값 표시 */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-black/40 border border-accent-green/30 rounded-lg p-3 text-center">
          <p className="text-[8px] text-text-muted uppercase font-bold mb-1">안전</p>
          <p className="text-sm font-black text-accent-green">0-240M</p>
          <p className="text-[9px] text-text-muted mt-1">정상 범위</p>
        </div>

        <div className="bg-black/40 border border-amber-500/30 rounded-lg p-3 text-center">
          <p className="text-[8px] text-text-muted uppercase font-bold mb-1">경고</p>
          <p className="text-sm font-black text-amber-500">240-270M</p>
          <p className="text-[9px] text-text-muted mt-1">관심 필요</p>
        </div>

        <div className="bg-black/40 border border-red-500/30 rounded-lg p-3 text-center">
          <p className="text-[8px] text-text-muted uppercase font-bold mb-1">긴급</p>
          <p className="text-sm font-black text-red-500">270M+</p>
          <p className="text-[9px] text-text-muted mt-1">즉시 조치</p>
        </div>
      </div>

      {/* 상태 메시지 */}
      {isCritical && (
        <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-red-500 shrink-0 mt-0.5" size={18} />
            <div className="min-w-0">
              <p className="text-sm font-black text-red-500 mb-1">⚠️ 긴급: 수익 캡 임계값 도달!</p>
              <p className="text-[10px] text-red-400 leading-relaxed">
                현재 수익이 $270M을 초과했습니다. 즉시 운영 회의를 소집하여 수익 조정 정책을 검토하세요.
              </p>
            </div>
          </div>
        </div>
      )}

      {isWarning && !isCritical && (
        <div className="bg-amber-500/20 border border-amber-500/50 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-amber-500 shrink-0 mt-0.5" size={18} />
            <div className="min-w-0">
              <p className="text-sm font-black text-amber-500 mb-1">주의: 수익 캡 경고 레벨</p>
              <p className="text-[10px] text-amber-400 leading-relaxed">
                현재 수익이 $240M을 초과했습니다. 수익 상황을 모니터링하고 필요시 조정을 준비하세요.
              </p>
            </div>
          </div>
        </div>
      )}

      {!isWarning && !isCritical && (
        <div className="bg-accent-green/20 border border-accent-green/50 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="text-accent-green shrink-0 mt-0.5" size={18} />
            <div className="min-w-0">
              <p className="text-sm font-black text-accent-green mb-1">정상: 안전 범위 내</p>
              <p className="text-[10px] text-accent-green/80 leading-relaxed">
                수익이 안전한 범위 내에 있습니다. 현재 추세가 지속되면 약 {Math.ceil((metrics.target - metrics.currentRevenue) / 5_000_000 * 5)} 초 후 경고 레벨 도달 예상입니다.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 상세 정보 */}
      <div className="pt-4 border-t border-white/5 space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-[10px] font-bold text-text-muted">현재 수익</span>
          <span className="text-[10px] font-black text-white">${(metrics.currentRevenue / 1_000_000).toFixed(0)}M</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-[10px] font-bold text-text-muted">남은 여유</span>
          <span className={cn(
            "text-[10px] font-black",
            isCritical ? 'text-red-500' : isWarning ? 'text-amber-500' : 'text-accent-green'
          )}>
            ${((metrics.target - metrics.currentRevenue) / 1_000_000).toFixed(0)}M
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-[10px] font-bold text-text-muted">시간당 증가율</span>
          <span className="text-[10px] font-black text-text-primary">+${(5 / 1_000_000).toFixed(3)}M</span>
        </div>
      </div>
    </div>
  );
}
