import { Clock, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import M13ExitScheduler from '../jobs/M13ExitScheduler';

// Mock 데이터 (프론트엔드 독립 실행용)
const MOCK_M13_SETTLEMENTS = [
  {
    id: 'settlement_001',
    memberId: 'member_001',
    package: 'VIP',
    joinDate: new Date('2022-01-15'),
    m13Date: new Date('2023-02-15'),
    finalRefund: 750,
    minimumRefund: 750,
    floorApplied: true,
    status: 'completed'
  }
];

const MOCK_SCHEDULER_STATUS = {
  isRunning: false,
  processedSettlements: 1,
  nextRunTime: new Date(Date.now() + 24 * 60 * 60 * 1000),
  lastRunTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
};

/**
 * M13 EXIT 처리 큐 컴포넌트
 * Dashboard에 표시되는 M13 EXIT 상태 (Mock 데이터)
 */
export function M13ExitQueue() {
  const [m13Queue] = useState<any[]>(MOCK_M13_SETTLEMENTS);
  const [schedulerStatus] = useState<any>(MOCK_SCHEDULER_STATUS);
  const [loading] = useState(false);
  const [error] = useState<string | null>(null);

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  };

  return (
    <div className="dashboard-card p-0 overflow-hidden border-border-main">
      {/* 헤더 */}
      <div className="p-6 border-b border-border-main bg-black/10 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">
            🔔 M13 EXIT 처리 큐
          </h3>
          <p className="text-[10px] text-text-muted mt-1 uppercase font-medium">
            {loading ? '데이터 로딩 중...' : '만기 도달 회원 자동 정산 현황'}
          </p>
        </div>
        {schedulerStatus && (
          <div className="text-right text-[9px]">
            <p className="font-black text-text-muted">다음 실행</p>
            <p className="text-accent-blue font-black">
              {schedulerStatus.nextRunTime
                ? new Date(schedulerStatus.nextRunTime).toLocaleDateString(
                    'ko-KR',
                    { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }
                  )
                : '계산 중...'}
            </p>
          </div>
        )}
      </div>

      {/* 에러 표시 */}
      {error && (
        <div className="px-6 py-3 border-b border-border-main/50 bg-red-500/10">
          <p className="text-[10px] text-red-400">{error}</p>
        </div>
      )}

      {/* 통계 */}
      {schedulerStatus && (
        <div className="px-6 py-4 border-b border-border-main/50 bg-black/5">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-[9px] text-text-muted uppercase font-bold">처리 중</p>
              <p className="text-lg font-black text-accent-blue">
                {schedulerStatus.isRunning ? '🔄 진행' : '⏸️ 대기'}
              </p>
            </div>
            <div>
              <p className="text-[9px] text-text-muted uppercase font-bold">누적 처리</p>
              <p className="text-lg font-black text-accent-green">
                {schedulerStatus.processedSettlements}명
              </p>
            </div>
            <div>
              <p className="text-[9px] text-text-muted uppercase font-bold">마지막 실행</p>
              <p className="text-lg font-black text-text-primary">
                {schedulerStatus.lastRunTime
                  ? new Date(schedulerStatus.lastRunTime).toLocaleDateString('ko-KR', {
                      month: '2-digit',
                      day: '2-digit'
                    })
                  : '미실행'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 큐 목록 */}
      {loading ? (
        <div className="p-6 text-center">
          <p className="text-text-muted text-[10px]">M13 EXIT 데이터를 로드 중입니다...</p>
        </div>
      ) : m13Queue.length === 0 ? (
        <div className="p-6 text-center">
          <p className="text-text-muted text-[10px]">진행 중인 M13 EXIT이 없습니다</p>
        </div>
      ) : (
        <table className="data-table table-fixed">
          <thead>
            <tr>
              <th className="!text-center text-[10px]">회원 ID</th>
              <th className="!text-center text-[10px]">패키지</th>
              <th className="!text-center text-[10px]">진입일</th>
              <th className="!text-center text-[10px]">만기일</th>
              <th className="!text-center text-[10px]">환급액</th>
              <th className="!text-center text-[10px]">최소보장</th>
              <th className="!text-center text-[10px]">상태</th>
            </tr>
          </thead>
          <tbody>
            {m13Queue.map((item) => (
              <tr key={item.id} className="hover:bg-white/[0.02]">
                <td className="!text-center overflow-hidden font-mono text-[10px] text-text-muted uppercase font-bold truncate">
                  {item.memberId}
                </td>
                <td className="!text-center overflow-hidden text-[10px] font-bold text-text-primary truncate">
                  {item.package}
                </td>
                <td className="!text-center overflow-hidden text-[10px] text-text-muted truncate">
                  {formatDate(item.joinDate)}
                </td>
                <td className="!text-center overflow-hidden text-[10px] text-text-muted truncate">
                  {formatDate(item.m13Date)}
                </td>
                <td className="!text-center overflow-hidden font-mono text-xs font-black text-accent-blue truncate">
                  ${item.finalRefund.toFixed(2)}
                </td>
                <td className="!text-center overflow-hidden text-[10px] font-bold text-accent-green truncate">
                  {item.floorApplied ? '✅ 적용' : '❌ 미적용'}
                </td>
                <td className="!text-center overflow-hidden">
                  <div className="flex items-center justify-center">
                  <span
                    className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${
                      item.status === 'completed'
                        ? 'text-accent-green border-accent-green/30 bg-accent-green/10'
                        : 'text-accent-blue border-accent-blue/30 bg-accent-blue/10'
                    }`}
                  >
                    {item.status === 'completed' ? '✅ 완료' : '⏳ 진행'}
                  </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* 푸터 정보 */}
      <div className="px-6 py-3 border-t border-border-main/50 bg-black/5">
        <div className="text-[9px] text-text-muted space-y-1">
          <p>
            ⏰ <strong>실행 주기:</strong> 매일 자정 UTC (00:00)
          </p>
          <p>
            🛡️ <strong>보장:</strong> 15% 최소환급금 자동 적용
          </p>
          <p>
            📧 <strong>알림:</strong> SMS + 이메일 + 푸시 + 인앱
          </p>
        </div>
      </div>
    </div>
  );
}
