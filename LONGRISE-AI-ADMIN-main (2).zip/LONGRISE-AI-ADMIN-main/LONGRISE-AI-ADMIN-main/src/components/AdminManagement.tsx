import { useState } from 'react';
import { Shield, UserPlus, Key, RefreshCcw, Search, X, Save, Trash2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { AdminUser, AdminRole } from '../types';

const MOCK_ADMINS: AdminUser[] = [
  {
    id: 'admin_001',
    username: 'jake_admin',
    email: 'jake@longrise.com',
    role: 'super',
    name: '제이크 (총괄 관리자)',
    permissions: ['*'],
    isActive: true,
    createdAt: '2024-01-01',
    updatedAt: '2024-12-21',
    lastLogin: '2024-12-21 18:00:00'
  },
  {
    id: 'admin_002',
    username: 'finance_op',
    email: 'finance@longrise.com',
    role: 'finance',
    name: '재무 운영자',
    permissions: ['dashboard', 'products', 'payouts', 'withdrawals', 'tokens', 'reconciliation', 'settings'],
    isActive: true,
    createdAt: '2024-03-15',
    updatedAt: '2024-12-20',
    lastLogin: '2024-12-21 10:30:00'
  },
  {
    id: 'admin_003',
    username: 'community_op',
    email: 'community@longrise.com',
    role: 'community',
    name: '커뮤니티 운영자',
    permissions: ['dashboard', 'member_dashboard', 'users', 'referrals', 'board', 'fds_monitoring', 'p2p_disputes', 'approvals'],
    isActive: true,
    createdAt: '2024-04-10',
    updatedAt: '2024-12-19',
    lastLogin: '2024-12-21 09:15:00'
  },
  {
    id: 'admin_004',
    username: 'content_team',
    email: 'content@longrise.com',
    role: 'content',
    name: '콘텐츠 관리자',
    permissions: ['dashboard', 'fe_hero', 'fe_features', 'fe_whyus', 'fe_crypto_ai', 'fe_news'],
    isActive: false,
    createdAt: '2024-05-20',
    updatedAt: '2024-12-10',
    lastLogin: '2024-12-10 15:45:00'
  }
];

export function AdminManagement() {
  const [admins, setAdmins] = useState<AdminUser[]>(MOCK_ADMINS);
  const [showModal, setShowModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    name: '',
    role: 'community' as AdminRole,
    password: ''
  });

  const roleLabels: Record<AdminRole, string> = {
    'super': '슈퍼 관리자',
    'finance': '재무 운영자',
    'community': '커뮤니티 운영자',
    'content': '콘텐츠 관리자'
  };

  const roleDescriptions: Record<AdminRole, string> = {
    'super': '모든 메뉴 및 기능 접근 가능',
    'finance': '재정 관리 및 정산 기능만 접근',
    'community': '회원 관리 및 커뮤니티 기능',
    'content': '콘텐츠/CMS 관리만 접근'
  };

  const filteredAdmins = admins.filter(admin =>
    admin.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    admin.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    admin.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openCreateModal = () => {
    setEditingAdmin(null);
    setFormData({ username: '', email: '', name: '', role: 'community', password: '' });
    setShowModal(true);
  };

  const openEditModal = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setFormData({
      username: admin.username,
      email: admin.email,
      name: admin.name,
      role: admin.role,
      password: ''
    });
    setShowModal(true);
  };

  const saveAdmin = () => {
    if (!formData.username || !formData.email || !formData.name) {
      alert('모든 필수 항목을 입력하세요.');
      return;
    }

    if (editingAdmin) {
      // 편집
      setAdmins(admins.map(a => a.id === editingAdmin.id ? {
        ...a,
        username: formData.username,
        email: formData.email,
        name: formData.name,
        role: formData.role,
        updatedAt: new Date().toISOString().split('T')[0]
      } : a));
    } else {
      // 신규 생성
      const newAdmin: AdminUser = {
        id: `admin_${Date.now()}`,
        username: formData.username,
        email: formData.email,
        name: formData.name,
        role: formData.role,
        permissions: getPermissionsByRole(formData.role),
        isActive: true,
        createdAt: new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString().split('T')[0],
        lastLogin: undefined
      };
      setAdmins([...admins, newAdmin]);
    }
    setShowModal(false);
  };

  const deleteAdmin = (id: string) => {
    if (confirm('이 관리자를 삭제하시겠습니까?')) {
      setAdmins(admins.filter(a => a.id !== id));
    }
  };

  const toggleAdminStatus = (id: string) => {
    setAdmins(admins.map(a => a.id === id ? { ...a, isActive: !a.isActive } : a));
  };

  const getPermissionsByRole = (role: AdminRole): string[] => {
    const rolePermissions: Record<AdminRole, string[]> = {
      'super': ['*'],
      'finance': ['dashboard', 'products', 'payouts', 'withdrawals', 'tokens', 'reconciliation', 'settings'],
      'community': ['dashboard', 'member_dashboard', 'users', 'referrals', 'board', 'fds_monitoring', 'p2p_disputes', 'approvals'],
      'content': ['dashboard', 'fe_hero', 'fe_features', 'fe_whyus', 'fe_crypto_ai', 'fe_faq_footer', 'fe_wall_of_fame', 'fe_team', 'fe_tree', 'fe_ranks', 'fe_invite', 'fe_support', 'fe_news', 'fe_auth', 'fe_security', 'fe_profile', 'fe_my_wealth']
    };
    return rolePermissions[role];
  };

  return (
    <div className="space-y-6 px-6 pb-12">
      <div className="flex items-center justify-between mb-2">
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
            <div className="dashboard-card border-border-main py-4 flex items-center justify-between">
               <div>
                  <p className="text-[9px] font-black text-text-muted uppercase tracking-[0.2em]">활성 관리자 수</p>
                  <p className="text-xl font-black text-text-primary">{admins.filter(a => a.isActive).length}</p>
               </div>
               <Shield className="text-accent-blue" size={24} />
            </div>
            <div className="dashboard-card border-border-main py-4 flex items-center justify-between">
               <div>
                  <p className="text-[9px] font-black text-text-muted uppercase tracking-[0.2em]">전체 관리자</p>
                  <p className="text-xl font-black text-text-primary">{admins.length}</p>
               </div>
               <Key className="text-accent-amber" size={24} />
            </div>
         </div>
         <div className="ml-6 flex items-center gap-3">
            <button onClick={openCreateModal} className="btn-gold text-[10px] py-1.5 px-6 font-bold flex items-center gap-2">
               <UserPlus size={14} /> 신규 관리자 계정 생성
            </button>
         </div>
      </div>

      <div className="dashboard-card border-border-main p-0 overflow-hidden shadow-sm">
         <div className="p-6 border-b border-border-main bg-black/10 flex items-center justify-between">
            <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">내부 권한 매트릭스 (Authority Matrix)</h3>
            <div className="flex gap-3">
               <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={12} />
                  <input
                     type="text"
                     value={searchTerm}
                     onChange={(e) => setSearchTerm(e.target.value)}
                     placeholder="관리자 검색..."
                     className="bg-black/20 border border-border-main rounded-md pl-8 pr-4 py-1.5 text-[10px] text-text-primary focus:outline-none focus:border-accent-blue/50 w-48"
                  />
               </div>
               <button className="p-1.5 border border-border-main rounded hover:bg-white/5 text-text-muted">
                  <RefreshCcw size={14} />
               </button>
            </div>
         </div>
         <table className="data-table table-fixed">
            <thead>
               <tr>
                  <th className="!text-center text-[10px]">사용자명</th>
                  <th className="!text-center text-[10px]">이메일</th>
                  <th className="!text-center text-[10px]">역할</th>
                  <th className="!text-center text-[10px]">마지막 로그인</th>
                  <th className="!text-center text-[10px]">상태</th>
                  <th className="!text-center text-[10px]">관리</th>
               </tr>
            </thead>
            <tbody>
               {filteredAdmins.map(admin => (
                  <tr key={admin.id} className="hover:bg-white/[0.01] group">
                     <td className="!text-center overflow-hidden font-bold text-[11px] text-text-primary truncate">{admin.name}</td>
                     <td className="!text-center overflow-hidden font-mono text-[10px] text-text-muted truncate">{admin.email}</td>
                     <td className="!text-center overflow-hidden">
                        <div className="flex items-center justify-center">
                           <span className="text-[9px] font-black uppercase text-accent-blue/80 tracking-widest">{roleLabels[admin.role]}</span>
                        </div>
                     </td>
                     <td className="!text-center overflow-hidden text-[9px] text-text-muted font-bold truncate">{admin.lastLogin || '로그인 기록 없음'}</td>
                     <td className="!text-center overflow-hidden">
                        <div className="flex items-center justify-center">
                           <button
                              onClick={() => toggleAdminStatus(admin.id)}
                              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
                           >
                              <div className={cn("w-1.5 h-1.5 rounded-full shadow-[0_0_8px]", admin.isActive ? "bg-accent-green shadow-accent-green/40" : "bg-red-500 shadow-red-500/40")} />
                              <span className="text-[9px] font-black uppercase tracking-widest text-text-muted">{admin.isActive ? '활성' : '비활성'}</span>
                           </button>
                        </div>
                     </td>
                     <td className="!text-center overflow-hidden">
                        <div className="flex items-center justify-center">
                           <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                              <button onClick={() => openEditModal(admin)} className="text-[9px] font-black uppercase border border-accent-blue/30 px-3 py-1.5 rounded text-accent-blue hover:bg-accent-blue/10">편집</button>
                              <button onClick={() => deleteAdmin(admin.id)} className="text-[9px] font-black uppercase border border-red-500/30 px-3 py-1.5 rounded text-red-400 hover:bg-red-500/10">삭제</button>
                           </div>
                        </div>
                     </td>
                  </tr>
               ))}
            </tbody>
         </table>
         <div className="p-6 bg-black/30 border-t border-border-main">
            <div className="flex items-center gap-3">
               <Shield className="text-accent-blue opacity-50" size={16} />
               <p className="text-[9px] text-text-muted font-medium italic">
                  중요: 관리자 계정의 모든 작업은 감사 로그에 기록됩니다. 각 역할별로 접근 가능한 메뉴가 자동으로 제한됩니다.
               </p>
            </div>
         </div>
      </div>

      {/* Admin Create/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#020617] border border-border-main rounded-lg p-8 w-full max-w-2xl">
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-border-main">
              <h3 className="text-lg font-bold text-text-primary uppercase tracking-wider">
                {editingAdmin ? '관리자 계정 편집' : '신규 관리자 계정 생성'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-text-muted hover:text-white">
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2 block">사용자명</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full bg-black/40 border border-border-main rounded px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-accent-blue/50"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2 block">이메일</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-black/40 border border-border-main rounded px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-accent-blue/50"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2 block">관리자 이름</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-black/40 border border-border-main rounded px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-accent-blue/50"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-text-muted uppercase tracking-widest mb-2 block">역할</label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as AdminRole })}
                  className="w-full bg-black/40 border border-border-main rounded px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-accent-blue/50"
                >
                  {(Object.keys(roleLabels) as AdminRole[]).map(role => (
                    <option key={role} value={role}>{roleLabels[role]}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Role Description */}
            <div className="mb-6 p-4 bg-accent-blue/5 border border-accent-blue/20 rounded">
              <p className="text-[10px] font-black text-accent-blue uppercase tracking-widest mb-2">선택된 역할 설명</p>
              <p className="text-[11px] text-text-primary">{roleDescriptions[formData.role]}</p>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-border-main rounded text-[10px] font-bold text-text-muted hover:bg-white/5 uppercase"
              >
                취소
              </button>
              <button
                onClick={saveAdmin}
                className="btn-gold px-6 py-2 flex items-center gap-2 text-[10px] font-bold uppercase"
              >
                <Save size={14} /> {editingAdmin ? '변경사항 저장' : '계정 생성'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
