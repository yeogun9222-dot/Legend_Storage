import { useState, useEffect } from 'react';
import { User, DragonRank, AdminUser } from '../types';
import { cn } from '../lib/utils';
import { Search, Filter, MoreHorizontal, UserCog, Ban, Lock, Unlock, LogOut, Wallet, ShieldCheck, ShieldAlert, X, Package, Users, History, ArrowDownRight, ArrowUpRight, ArrowRight, Loader } from 'lucide-react';
import { userApi } from '../lib/api';
import { UserData } from '../shared/types';
import { UserDetailPanel } from './UserDetailPanel';

// Convert UserData from API to User type for UI
function convertApiUserToUIUser(apiUser: UserData): User {
  return {
    ...apiUser,
    usdt: apiUser.balanceUSDT,
    cnyt: apiUser.balanceCNYT,
    pageface: apiUser.pageface === true ? 'Approved' : 'Pending',
    isFrozen: apiUser.restrictions?.isFrozen || false,
    status: apiUser.status === 'active' ? 'Active' : 'Inactive',
    isTradingPasswordVerified: apiUser.isTradingPasswordVerified || false,
    maxOutRatio: Math.random() * 10, // Placeholder calculation
    packages: [], // Will be populated if available
  };
}

export function UserManagement({ users: propUsers, currentAdmin }: { users?: User[]; currentAdmin?: AdminUser }) {
  const [users, setUsers] = useState<User[]>(propUsers || []);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [search, setSearch] = useState('');
  const [activeRank, setActiveRank] = useState<DragonRank | 'All'>('All');
  const [sortBy, setSortBy] = useState<'balance' | 'activity' | 'security' | 'rank'>('balance');
  const [loading, setLoading] = useState(!propUsers);
  const [error, setError] = useState<string | null>(null);

  // Fetch users from API on mount or update UI with propUsers
  useEffect(() => {
    if (propUsers) {
      // Use provided mock data
      setUsers(propUsers);
      setLoading(false);
      setError(null);
    } else {
      // Fetch from API
      const fetchUsers = async () => {
        try {
          setLoading(true);
          setError(null);
          const response = await userApi.list(1, 500, search) as any;

          if (response?.success && response?.data?.data) {
            const uiUsers = (response.data.data as UserData[]).map(convertApiUserToUIUser);
            setUsers(uiUsers);
          } else {
            setError((response as any)?.error?.message || 'Failed to fetch users');
            setLoading(false);
          }
        } catch (err) {
          console.error('Error fetching users:', err);
          setError('API 서버 연결 실패. 백엔드 서버를 실행해주세요: npm run dev (backend 디렉토리)');
          setLoading(false);
        }
      };

      fetchUsers();
    }
  }, [propUsers]);

  const rankPriority: Record<DragonRank, number> = {
    'Black Dragon': 6,
    'Red Dragon': 5,
    'Purple Dragon': 4,
    'Blue Dragon': 3,
    'White Dragon': 2,
    'Investor': 0
  };

  // 보안 수준 계산 (리리의 우선순위)
  const getSecurityLevel = (user: User): number => {
    let level = 0;
    if (user.otp) level += 3; // OTP 최상
    if (user.pageface === 'Approved') level += 2; // 얼굴인증
    if (user.mobileBinding) level += 1; // 휴대폰인증
    return level;
  };

  // 최근 활동도 계산 (더미 데이터 기반)
  const getActivityScore = (user: User): number => {
    return Math.random() * 100; // 실제로는 거래 이력에서 계산
  };

  const filteredUsers = users
    .filter(u =>
      (activeRank === 'All' || u.rank === activeRank) &&
      (u.nickname.toLowerCase().includes(search.toLowerCase()) ||
       u.id.toLowerCase().includes(search.toLowerCase()))
    )
    .sort((a, b) => {
      // 리리의 우선순위: 잔액 > 활동 > CNYT 거래 > 보안
      if (sortBy === 'balance') {
        return (b.usdt || 0) - (a.usdt || 0);
      } else if (sortBy === 'activity') {
        return getActivityScore(b) - getActivityScore(a);
      } else if (sortBy === 'security') {
        return getSecurityLevel(b) - getSecurityLevel(a);
      } else {
        return rankPriority[b.rank] - rankPriority[a.rank];
      }
    });

  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredUsers.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredUsers.map(u => u.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const getRankColor = (rank: DragonRank) => {
    const colors: Record<DragonRank, string> = {
      'Investor': 'text-slate-400 bg-slate-500/10 border-slate-500/20',
      'White Dragon': 'text-slate-100 border-slate-100/20 bg-slate-100/5',
      'Blue Dragon': 'text-accent-blue border-accent-blue/20 bg-accent-blue/5',
      'Purple Dragon': 'text-purple-400 border-purple-400/20 bg-purple-400/5',
      'Red Dragon': 'text-red-400 border-red-400/20 bg-red-400/5',
      'Black Dragon': 'text-accent-amber border-accent-amber/20 bg-accent-amber/10'
    };
    return colors[rank];
  };

  const translateRank = (rank: string) => {
    const ranks: any = {
      'Investor': '일반 회원',
      'White Dragon': '화이트 드래곤',
      'Blue Dragon': '블루 드래곤',
      'Purple Dragon': '퍼플 드래곤',
      'Red Dragon': '레드 드래곤',
      'Black Dragon': '블랙 드래곤'
    };
    return ranks[rank] || rank;
  };

  // Handle balance adjustment through API
  const handleBalanceAdjustment = async (userId: string, currency: 'USDT' | 'CNYT', amount: number) => {
    if (!currentAdmin) return;

    try {
      const response = await userApi.adjustBalance(userId, currency, amount, currentAdmin.id, currentAdmin.name) as any;

      if (response?.success && response?.data) {
        // Update UI with new user data
        const updatedUser = convertApiUserToUIUser(response.data as UserData);
        setUsers(prev => prev.map(u => u.id === userId ? updatedUser : u));

        if (selectedUser?.id === userId) {
          setSelectedUser(updatedUser);
        }

        console.log(`✅ Balance adjusted: +${amount} ${currency} for user ${userId}`);
      } else {
        console.error('Failed to adjust balance:', (response as any)?.error?.message);
      }
    } catch (err) {
      console.error('Error adjusting balance:', err);
    }
  };

  // Handle user restriction through API
  const handleSetRestriction = async (userId: string, restrictionType: 'withdrawal' | 'account' | 'freeze', enabled: boolean) => {
    if (!currentAdmin) return;

    try {
      const response = await userApi.setRestrictions(userId, restrictionType, enabled, currentAdmin.id, currentAdmin.name) as any;

      if (response?.success && response?.data) {
        const updatedUser = convertApiUserToUIUser(response.data as UserData);
        setUsers(prev => prev.map(u => u.id === userId ? updatedUser : u));

        if (selectedUser?.id === userId) {
          setSelectedUser(updatedUser);
        }

        console.log(`✅ Restriction set: ${restrictionType} = ${enabled} for user ${userId}`);
      }
    } catch (err) {
      console.error('Error setting restriction:', err);
    }
  };

  // Handle ban through API
  const handleBanUser = async (userId: string) => {
    if (!currentAdmin) return;

    try {
      const response = await userApi.ban(userId, currentAdmin.id, currentAdmin.name) as any;

      if (response?.success && response?.data) {
        const updatedUser = convertApiUserToUIUser(response.data as UserData);
        setUsers(prev => prev.map(u => u.id === userId ? updatedUser : u));
        setSelectedUser(null);
        console.log(`✅ User banned: ${userId}`);
      }
    } catch (err) {
      console.error('Error banning user:', err);
    }
  };

  // Show loading state
  if (loading) {
    return (
      <div className="space-y-6 px-6 relative">
        <div className="dashboard-card border-border-main p-12 flex flex-col items-center justify-center min-h-[400px]">
          <Loader className="animate-spin text-accent-blue mb-4" size={32} />
          <p className="text-text-muted text-sm uppercase tracking-widest">회원 목록 로드 중...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="space-y-6 px-6 relative">
        <div className="dashboard-card border-border-main p-12 flex flex-col items-center justify-center min-h-[400px] border-red-500/20 bg-red-500/5">
          <p className="text-red-400 text-sm uppercase tracking-widest mb-4">⚠️ API 연결 오류</p>
          <p className="text-text-muted text-xs">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-6 px-4 py-2 bg-red-500 text-white text-xs rounded uppercase font-bold hover:bg-red-600 transition-all"
          >
            다시 시도
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 px-6 relative">
      <div className="dashboard-card border-border-main p-0 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-border-main bg-black/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">회원 통합 제어 센터</h3>
            <p className="text-[10px] text-text-muted mt-1 uppercase tracking-widest font-medium">관리 레벨: 관리자 전용 엑세스 V7.2</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={12} />
              <input 
                type="text" 
                placeholder="UID, 닉네임 검색..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-black/20 border border-border-main rounded-md pl-8 pr-4 py-1.5 text-[10px] text-text-primary focus:outline-none focus:border-accent-blue/50 w-64"
              />
            </div>
            <button className="btn-gold text-[10px] py-1.5 px-4 uppercase tracking-widest">회원 추가</button>
            <button className="btn-outline-gold text-[10px] py-1.5 px-4 uppercase tracking-widest">CSV 내보내기</button>
          </div>
        </div>

        {/* Rank Filter Tabs & Sort Options */}
        <div className="px-6 py-4 border-b border-border-main bg-black/5 space-y-3">
          <div className="flex items-center justify-between gap-4">
            {/* Rank Filter */}
            <div className="flex overflow-x-auto no-scrollbar gap-1">
              {['All', 'Black Dragon', 'Red Dragon', 'Purple Dragon', 'Blue Dragon', 'White Dragon', 'Investor'].map((r) => (
                <button
                  key={r}
                  onClick={() => setActiveRank(r as any)}
                  className={cn(
                    "px-3 py-1.5 text-[9px] font-black uppercase tracking-widest whitespace-nowrap transition-all border-b-2",
                    activeRank === r
                      ? 'border-accent-blue text-accent-blue'
                      : 'border-transparent text-text-muted hover:text-text-primary'
                  )}
                >
                  {r}
                </button>
              ))}
            </div>

            {/* Sort Options (리리의 우선순위) */}
            <div className="flex gap-2 whitespace-nowrap">
              <button
                onClick={() => setSortBy('balance')}
                className={cn(
                  "px-3 py-1.5 text-[9px] font-black uppercase tracking-widest rounded transition-all",
                  sortBy === 'balance'
                    ? 'bg-accent-blue text-white'
                    : 'bg-black/30 text-text-muted hover:text-text-primary border border-border-main'
                )}
              >
                💰 잔액순
              </button>
              <button
                onClick={() => setSortBy('activity')}
                className={cn(
                  "px-3 py-1.5 text-[9px] font-black uppercase tracking-widest rounded transition-all",
                  sortBy === 'activity'
                    ? 'bg-accent-blue text-white'
                    : 'bg-black/30 text-text-muted hover:text-text-primary border border-border-main'
                )}
              >
                📊 활동순
              </button>
              <button
                onClick={() => setSortBy('security')}
                className={cn(
                  "px-3 py-1.5 text-[9px] font-black uppercase tracking-widest rounded transition-all",
                  sortBy === 'security'
                    ? 'bg-accent-blue text-white'
                    : 'bg-black/30 text-text-muted hover:text-text-primary border border-border-main'
                )}
              >
                🔐 보안순
              </button>
            </div>
          </div>
        </div>

        {/* Original Rank Filter Tabs (유지) */}
        <div className="flex px-6 border-b border-border-main bg-black/5 overflow-x-auto no-scrollbar hidden">
           {['All', 'Black Dragon', 'Red Dragon', 'Purple Dragon', 'Blue Dragon', 'White Dragon', 'Investor'].map((r) => (
             <button
               key={r}
               onClick={() => setActiveRank(r as any)}
               className={cn(
                 "px-4 py-3 text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border-b-2",
                 activeRank === r
                   ? "text-accent-blue border-accent-blue bg-accent-blue/5" 
                   : "text-text-muted border-transparent hover:text-white hover:bg-white/5"
               )}
             >
               {r === 'All' ? '전체 회원' : translateRank(r)}
             </button>
           ))}
        </div>
        
        <div className="overflow-x-auto">
          <table className="data-table table-fixed">
            <thead>
              <tr className="whitespace-nowrap">
                <th className="w-10 !text-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === filteredUsers.length && filteredUsers.length > 0}
                    onChange={toggleSelectAll}
                    className="accent-accent-blue"
                  />
                </th>
                <th className="w-12 !text-center text-[10px]">고유번호</th>
                <th className="min-w-[120px] !text-center text-[10px]">회원 프로필</th>
                <th className="min-w-[100px] !text-center text-[10px]">직급 상태</th>
                <th className="min-w-[80px] !text-center text-[10px]">활성 패키지</th>
                <th className="min-w-[140px] !text-center text-[10px]">보유 자산</th>
                <th className="min-w-[100px] !text-center text-[10px]">팀 실적</th>
                <th className="min-w-[100px] !text-center text-[10px]">얼굴인증</th>
                <th className="min-w-[90px] text-center text-[10px]">거래 비밀번호</th>
                <th className="min-w-[80px] !text-center text-[10px]">Max-Out</th>
                <th className="min-w-[80px] !text-center text-[10px]">계정 상태</th>
                <th className="sticky right-0 top-0 bg-bg-surface z-10 !text-center text-[10px] border-l border-white/10 px-6 min-w-[140px]">제어</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(u => (
                <tr key={u.id} className={cn("hover:bg-white/[0.01] transition-colors", selectedIds.includes(u.id) && "bg-accent-blue/5")}>
                  <td className="!text-center overflow-hidden">
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(u.id)}
                      onChange={() => toggleSelectOne(u.id)}
                      className="accent-accent-blue"
                    />
                  </td>
                  <td className="text-center overflow-hidden font-mono text-[10px] text-text-muted italic opacity-50 truncate">{u.id.split('-')[1]}</td>
                  <td className="text-center overflow-hidden cursor-pointer group/profile" onClick={() => setSelectedUser(u)}>
                    <div className="flex items-center justify-center gap-2 whitespace-nowrap min-w-0">
                      <span className="font-bold text-text-primary text-[11px] group-hover/profile:text-accent-blue transition-colors truncate">{u.nickname}</span>
                      <span className="text-[9px] text-text-muted font-mono opacity-50 group-hover/profile:opacity-100 shrink-0">{u.id}</span>
                    </div>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span className={cn(
                      "inline-block text-[9px] font-black px-2 py-0.5 rounded border uppercase tracking-tighter shadow-sm whitespace-nowrap",
                      getRankColor(u.rank)
                    )}>
                      {translateRank(u.rank)}
                    </span>
                  </td>
                  <td className="text-center overflow-hidden flex items-center justify-center min-w-0">
                    <PortfolioBadges packages={u.packages} />
                  </td>
                  <td className="text-center overflow-hidden font-mono text-xs whitespace-nowrap">
                    <span className="text-accent-blue font-bold">{u.usdt.toLocaleString()} USDT</span>
                    <span className="text-text-muted mx-2">/</span>
                    <span className="text-purple-400 font-bold opacity-60 text-[9px]">{u.cnyt.toLocaleString()} CNYT</span>
                  </td>
                  <td className="text-center overflow-hidden font-mono text-xs font-black text-slate-300 truncate">
                    ${u.teamVol.toLocaleString()}
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span className={cn(
                      "inline-block text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded whitespace-nowrap",
                      u.pageface === 'Approved' ? "text-accent-green bg-accent-green/10" : u.pageface === 'Pending' ? "text-accent-amber bg-accent-amber/10" : "text-red-500 bg-red-500/10"
                    )}>
                      {u.pageface === 'Approved' ? '인증 완료' : u.pageface === 'Pending' ? '심사 중' : '미인증'}
                    </span>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <span className={cn(
                      "inline-block text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded whitespace-nowrap",
                      u.hasSetTradingPassword && u.isTradingPasswordVerified ? "text-accent-green bg-accent-green/10" : u.hasSetTradingPassword ? "text-accent-amber bg-accent-amber/10" : "text-red-500 bg-red-500/10"
                    )}>
                      {u.hasSetTradingPassword && u.isTradingPasswordVerified ? '설정됨 ✓' : u.hasSetTradingPassword ? '검증 필요' : '미설정'}
                    </span>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <div className="w-24 mx-auto min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <span className={cn(
                          "text-[9px] font-black tabular-nums",
                          u.maxOutRatio >= 9 ? "text-red-500 animate-pulse" : u.maxOutRatio >= 7 ? "text-accent-amber" : "text-accent-green"
                        )}>
                          {u.maxOutRatio.toFixed(1)}x
                        </span>
                        <span className="text-[8px] text-text-muted opacity-50 uppercase font-bold">Limit</span>
                      </div>
                      <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                        <div
                          className={cn(
                            "h-full transition-all duration-1000",
                            u.maxOutRatio >= 9 ? "bg-red-500" : u.maxOutRatio >= 7 ? "bg-accent-amber" : "bg-accent-green"
                          )}
                          style={{ width: `${Math.min(u.maxOutRatio * 10, 100)}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="!text-center overflow-hidden">
                    <div className="flex items-center justify-center gap-2 min-w-0">
                      <div className={cn(
                        "w-1.5 h-1.5 rounded-full shrink-0",
                        u.isFrozen ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]" : u.status === 'Active' ? "bg-accent-green shadow-[0_0_8px_rgba(74,222,128,0.4)]" : "bg-slate-500"
                      )} />
                      <span className="text-[9px] font-bold uppercase text-text-muted">
                        {u.isFrozen ? '동결됨' : u.status === 'Active' ? '정상' : '정지'}
                      </span>
                    </div>
                  </td>
                  <td className="sticky right-0 bg-bg-surface z-10 text-center border-l border-white/10 px-6">
                    <button
                      onClick={() => setSelectedUser(u)}
                      className="text-[9px] text-accent-blue border border-accent-blue/30 px-3 py-1.5 rounded hover:bg-accent-blue hover:text-white transition-all font-black uppercase tracking-tighter bg-bg-surface whitespace-nowrap"
                    >
                      상세보기
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Bulk Action Bar */}
        {selectedIds.length > 0 && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-accent-blue px-6 py-3 rounded-full shadow-2xl flex items-center gap-6 animate-in slide-in-from-bottom-8 duration-300 z-40">
            <span className="text-xs font-black text-slate-900 uppercase tracking-widest leading-none">
              {selectedIds.length}명의 회원 선택됨
            </span>
            <div className="h-4 w-px bg-slate-900/20" />
            <div className="flex gap-2">
              <button className="flex items-center gap-2 bg-slate-900 text-white px-4 py-1.5 rounded-full text-[10px] font-bold uppercase hover:bg-slate-800 transition-all">
                <Ban size={12} /> 계정 일괄 정지
              </button>
              <button className="flex items-center gap-2 bg-white text-slate-900 px-4 py-1.5 rounded-full text-[10px] font-bold uppercase hover:bg-slate-100 transition-all shadow-sm">
                <Wallet size={12} /> 포인트 일괄 지급
              </button>
              <button 
                onClick={() => setSelectedIds([])}
                className="p-1.5 text-slate-900/60 hover:text-slate-900 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        <div className="p-4 bg-black/20 flex items-center justify-between text-[10px] font-bold text-text-muted uppercase tracking-widest border-t border-border-main">
          <span>활성 노드 총계: {users.length}</span>
          <div className="flex gap-4 items-center">
             <button disabled className="opacity-30 cursor-not-allowed">이전</button>
             <div className="bg-black/40 px-3 py-1 rounded border border-white/5">
                <span className="text-accent-blue font-black">페이지 01 // 01</span>
             </div>
             <button disabled className="opacity-30 cursor-not-allowed">다음</button>
          </div>
        </div>
      </div>

      {/* User Detail Panel */}
      <UserDetailPanel
        user={selectedUser}
        isOpen={selectedUser !== null}
        onClose={() => setSelectedUser(null)}
        currentAdmin={currentAdmin}
        onUpdate={(updatedUser) => {
          setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
          setSelectedUser(updatedUser);
        }}
      />
    </div>
  );
}

// Helper components for UserManagement table (kept for compatibility)
function SectionTitle({ title }: { title: string }) {
  return (
    <div className="flex items-center gap-2 mb-4">
       <div className="h-4 w-1 bg-accent-blue rounded-full" />
       <h4 className="text-[11px] font-black text-text-primary uppercase tracking-[0.1em]">{title}</h4>
    </div>
  );
}

function DetailRow({ label, value, controllable }: { label: string, value: string, controllable?: boolean }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-white/[0.03]">
       <span className="text-[11px] text-text-muted">{label}</span>
       <div className="flex items-center gap-3">
          <span className="text-[11px] font-bold text-text-primary font-mono">{value}</span>
          {controllable && (
            <button className="text-[9px] text-accent-blue opacity-50 hover:opacity-100 transition-opacity font-bold uppercase italic border-b border-accent-blue/30">수정</button>
          )}
       </div>
    </div>
  );
}

function RestrictionItem({ icon: Icon, label, desc, active }: any) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg border border-white/5 bg-black/20">
       <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded bg-white/5", active ? "text-red-400" : "text-text-muted")}>
             <Icon size={14} />
          </div>
          <div>
             <p className="text-[10px] font-bold text-text-primary uppercase tracking-tight">{label}</p>
             <p className="text-[9px] text-text-muted italic">{desc}</p>
          </div>
       </div>
       <div className={cn(
         "w-8 h-4 rounded-full relative transition-colors",
         active ? "bg-red-500" : "bg-slate-700"
       )}>
         <div className={cn(
           "absolute top-1 w-2 h-2 rounded-full bg-white transition-all",
           active ? "right-1" : "left-1"
         )} />
       </div>
    </div>
  );
}

function PortfolioBadges({ packages }: { packages: any[] }) {
  const counts = packages.reduce((acc: any, p: any) => {
    acc[p.type] = (acc[p.type] || 0) + 1;
    return acc;
  }, {});

  const pTypes = [
    { type: 'Flexible', color: 'bg-slate-500/20 text-slate-400 border-slate-500/30' },
    { type: 'Basic', color: 'bg-accent-blue/20 text-accent-blue border-accent-blue/30' },
    { type: 'Standard', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
    { type: 'Premium', color: 'bg-accent-amber/20 text-accent-amber border-accent-amber/30' },
    { type: 'VIP', color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  ];

  return (
    <div className="flex gap-1" title="패키지 활성화 분포 (F | B | S | P | V)">
      {pTypes.map(p => {
        const count = counts[p.type] || 0;
        return (
          <div 
            key={p.type} 
            className={cn(
              "w-6 h-6 rounded flex items-center justify-center text-[9px] font-black border transition-all",
              count > 0 ? p.color : "opacity-10 border-white/5 grayscale"
            )}
          >
            {count}
          </div>
        );
      })}
    </div>
  );
}
