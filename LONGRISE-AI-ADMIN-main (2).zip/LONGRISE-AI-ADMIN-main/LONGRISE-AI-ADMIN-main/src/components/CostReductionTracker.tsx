/**
 * CostReductionTracker Component
 * V7.5 비용 절감 추적
 * V7.4 $978K → V7.5 $98K: 67% 절감 (M1-M6)
 */

import { TrendingDown, Zap, DollarSign, Target } from 'lucide-react';
import { useState, useEffect } from 'react';

interface CostData {
  month: string;
  v74Cost: number;
  v75Cost: number;
  savings: number;
  savingsPercent: number;
}

export function CostReductionTracker() {
  const [costData] = useState<CostData[]>([
    { month: 'M1', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 },
    { month: 'M2', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 },
    { month: 'M3', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 },
    { month: 'M4', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 },
    { month: 'M5', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 },
    { month: 'M6', v74Cost: 978, v75Cost: 98, savings: 880, savingsPercent: 90 }
  ]);

  const totalV74Cost = costData.reduce((sum, d) => sum + d.v74Cost, 0);
  const totalV75Cost = costData.reduce((sum, d) => sum + d.v75Cost, 0);
  const totalSavings = totalV74Cost - totalV75Cost;
  const avgSavingsPercent = (totalSavings / totalV74Cost) * 100;

  return (
    <div className="dashboard-card p-6 border-border-main">
      <div className="mb-6">
        <h2 className="text-sm font-black text-white uppercase tracking-widest mb-1">
          💚 V7.5 비용 절감 추적 (M1-M6)
        </h2>
        <p className="text-[10px] text-text-muted uppercase">
          마이크의 전략: CNYT 유동성 조정 + 시스템 최적화
        </p>
      </div>

      {/* 핵심 지표 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-black/40 border border-accent-green/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="text-accent-green" size={18} />
            <p className="text-[10px] font-black text-text-muted uppercase">총 절감액</p>
          </div>
          <p className="text-2xl font-black text-accent-green">${totalSavings.toLocaleString()}K</p>
          <p className="text-[9px] text-text-muted mt-1">6개월 누적</p>
        </div>

        <div className="bg-black/40 border border-accent-blue/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="text-accent-blue" size={18} />
            <p className="text-[10px] font-black text-text-muted uppercase">절감율</p>
          </div>
          <p className="text-2xl font-black text-accent-blue">{avgSavingsPercent.toFixed(1)}%</p>
          <p className="text-[9px] text-text-muted mt-1">평균 절감율</p>
        </div>

        <div className="bg-black/40 border border-accent-amber/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="text-accent-amber" size={18} />
            <p className="text-[10px] font-black text-text-muted uppercase">월간 감소</p>
          </div>
          <p className="text-2xl font-black text-accent-amber">${(totalSavings / costData.length).toLocaleString()}K</p>
          <p className="text-[9px] text-text-muted mt-1">한 달 평균</p>
        </div>
      </div>

      {/* 월별 비용 비교 */}
      <div className="mb-6">
        <p className="text-[10px] font-black text-text-muted uppercase mb-3">월별 비용 현황</p>
        <div className="space-y-2">
          {costData.map((data, idx) => (
            <div key={idx} className="bg-black/20 border border-white/5 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black text-white uppercase">{data.month}</span>
                <span className="text-[9px] font-black text-accent-green">↓ {data.savingsPercent}%</span>
              </div>
              <div className="flex items-center gap-2">
                {/* V7.4 비용 바 */}
                <div className="flex-1">
                  <div className="h-6 bg-red-500/30 border border-red-500/50 rounded relative flex items-center px-2">
                    <p className="text-[8px] font-black text-red-400">${data.v74Cost}K</p>
                  </div>
                </div>

                {/* 화살표 */}
                <span className="text-accent-green font-black">→</span>

                {/* V7.5 비용 바 */}
                <div className="flex-1">
                  <div className="h-6 bg-accent-green/30 border border-accent-green/50 rounded relative flex items-center px-2">
                    <p className="text-[8px] font-black text-accent-green">${data.v75Cost}K</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 전략 설명 */}
      <div className="bg-accent-green/[0.08] border border-accent-green/30 rounded-lg p-4 mb-6">
        <p className="text-[10px] font-black text-accent-green uppercase mb-2">✅ 절감 전략</p>
        <div className="space-y-1.5">
          <div className="flex items-start gap-2">
            <span className="text-accent-green font-black mt-1">→</span>
            <p className="text-[9px] text-text-muted">
              <span className="text-white font-bold">CNYT 유동성 조정:</span> M1-M6 기간 CNYT 분배 비율 최적화로 달러 지출 최소화
            </p>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-accent-green font-black mt-1">→</span>
            <p className="text-[9px] text-text-muted">
              <span className="text-white font-bold">시스템 최적화:</span> 자동 정산 프로세스로 인건비 감소 ($500K 절감)
            </p>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-accent-green font-black mt-1">→</span>
            <p className="text-[9px] text-text-muted">
              <span className="text-white font-bold">인프라 효율화:</span> 클라우드 비용 최적화로 운영 비용 감소 ($380K 절감)
            </p>
          </div>
        </div>
      </div>

      {/* 재정 영향도 */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-black/40 border border-white/5 rounded-lg p-3">
          <p className="text-[9px] font-black text-text-muted uppercase mb-2">원본 비용 (V7.4)</p>
          <p className="text-lg font-black text-red-500">${totalV74Cost.toLocaleString()}K</p>
          <p className="text-[8px] text-text-muted mt-1">M1-M6 누적</p>
        </div>

        <div className="bg-black/40 border border-white/5 rounded-lg p-3">
          <p className="text-[9px] font-black text-text-muted uppercase mb-2">최적화 비용 (V7.5)</p>
          <p className="text-lg font-black text-accent-green">${totalV75Cost.toLocaleString()}K</p>
          <p className="text-[8px] text-text-muted mt-1">M1-M6 누적</p>
        </div>
      </div>

      {/* 예상 효과 */}
      <div className="mt-6 pt-4 border-t border-white/5">
        <p className="text-[10px] font-black text-text-muted uppercase mb-3">예상 효과 (M7 이후)</p>
        <div className="bg-accent-blue/10 border border-accent-blue/30 rounded-lg p-3">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-text-muted">절감액 누적 추가</span>
              <span className="text-[10px] font-black text-accent-blue">+$880K/월</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-text-muted">연간 예상 절감</span>
              <span className="text-[10px] font-black text-accent-blue">~$10.6M</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-text-muted">회원 환급 증대</span>
              <span className="text-[10px] font-black text-accent-green">+5-8%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
