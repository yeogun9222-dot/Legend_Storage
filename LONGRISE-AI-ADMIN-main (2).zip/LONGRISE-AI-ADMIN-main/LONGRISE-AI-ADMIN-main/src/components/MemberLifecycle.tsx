/**
 * Member Lifecycle Management Component
 * 회원 생명주기 상태 관리 및 모니터링
 */

import { useState } from 'react';
import {
  Users,
  TrendingUp,
  AlertTriangle,
  Clock,
  Trash2,
  ArrowRight,
  Search,
  Filter,
  Activity,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { MOCK_USERS } from '../lib/mockData';
import { recordAuditLog } from '../lib/auditLogger';

type LifecycleStatus = 'new' | 'active' | 'suspended' | 'inactive' | 'withdrew';

interface MemberLifecycleData {
  userId: string;
  nickname: string;
  rank: string;
  status: LifecycleStatus;
  joinDate: string;
  lastActivityDate: string;
  daysActive: number;
  inactivityDays: number;
}

const MOCK_ADMIN = { id: 'admin_001', name: '제이크 (회원 관리자)' };

const getStatusColor = (status: LifecycleStatus) => {
  switch(status) {
    case 'new': return { bg: 'bg-accent-amber/10', border: 'border-accent-amber/30', text: 'text-accent-amber', label: '신규' };
    case 'active': return { bg: 'bg-accent-green/10', border: 'border-accent-green/30', text: 'text-accent-green', label: '활성' };
    case 'suspended': return { bg: 'bg-red-500/10', border: 'border-red-500/30', text: 'text-red-500', label: '거래정지' };
    case 'inactive': return { bg: 'bg-slate-500/10', border: 'border-slate-500/30', text: 'text-slate-400', label: '휴면' };
    case 'withdrew': return { bg: 'bg-red-600/10', border: 'border-red-600/30', text: 'text-red-600', label: '탈퇴' };
  }
};

const getStatusDescription = (status: LifecycleStatus) => {
  switch(status) {
    case 'new': return '가입 후 KYC 미완료';
    case 'active': return 'KYC 완료, 정상 거래';
    case 'suspended': return '이상거래 탐지로 거래 정지';
    case 'inactive': return '30일 이상 활동 없음';
    case 'withdrew': return '계정 삭제 완료';
  }
};

export function MemberLifecycle() {
  const [members, setMembers] = useState<MemberLifecycleData[]>(
    MOCK_USERS.map(u => ({
      userId: u.id,
      nickname: u.nickname,
      rank: u.rank,
      status: (u.memberLifecycleStatus || 'active') as LifecycleStatus,
      joinDate: u.joinDate,
      lastActivityDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      daysActive: Math.floor((Date.now() - new Date(u.joinDate).getTime()) / (24 * 60 * 60 * 1000)),
      inactivityDays: Math.floor(Math.random() * 60),
    }))
  );

  const [activeFilter, setActiveFilter] = useState<LifecycleStatus | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMember, setSelectedMember] = useState<MemberLifecycleData | null>(null);
  const [transitionReason, setTransitionReason] = useState('');

  // 상태별 분류
  const getMembers = () => {
    let filtered = members;
    if (activeFilter !== 'all') {
      filtered = filtered.filter(m => m.status === activeFilter);
    }
    return filtered.filter(m =>
      m.nickname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.userId.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // 통계
  const stats = {
    total: members.length,
    new: members.filter(m => m.status === 'new').length,
    active: members.filter(m => m.status === 'active').length,
    suspended: members.filter(m => m.status === 'suspended').length,
    inactive: members.filter(m => m.status === 'inactive').length,
    withdrew: members.filter(m => m.status === 'withdrew').length,
  };

  const handleStatusChange = (member: MemberLifecycleData, newStatus: LifecycleStatus) => {
    const updatedMembers = members.map(m =>
      m.userId === member.userId
        ? { ...m, status: newStatus }
        : m
    );
    setMembers(updatedMembers);

    // 감사 로그
    recordAuditLog(
      MOCK_ADMIN.id,
      MOCK_ADMIN.name,
      '회원 생명주기 변경',
      'member_lifecycle',
      member.userId,
      {
        before: { status: member.status },
        after: { status: newStatus },
        reason: transitionReason || '관리자 변경',
      }
    );

    setSelectedMember(null);
    setTransitionReason('');
  };

  const filteredMembers = getMembers();

  return (
    <div className="space-y-6 px-6 pb-12">
      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
        <div className="dashboard-card border-border-main p-4">
          <h4 className="text-[8px] font-black text-text-muted uppercase tracking-widest mb-2">전체</h4>
          <p className="text-xl font-black text-text-primary tabular-nums">{stats.total}</p>
        </div>
        <div className="dashboard-card border-accent-amber/30 bg-accent-amber/5 p-4">
          <h4 className="text-[8px] font-black text-accent-amber uppercase tracking-widest mb-2">신규</h4>
          <p className="text-xl font-black text-accent-amber tabular-nums">{stats.new}</p>
        </div>
        <div className="dashboard-card border-accent-green/30 bg-accent-green/5 p-4">
          <h4 className="text-[8px] font-black text-accent-green uppercase tracking-widest mb-2">활성</h4>
          <p className="text-xl font-black text-accent-green tabular-nums">{stats.active}</p>
        </div>
        <div className="dashboard-card border-red-500/30 bg-red-500/5 p-4">
          <h4 className="text-[8px] font-black text-red-500 uppercase tracking-widest mb-2">정지</h4>
          <p className="text-xl font-black text-red-500 tabular-nums">{stats.suspended}</p>
        </div>
        <div className="dashboard-card border-slate-500/30 bg-slate-500/5 p-4">
          <h4 className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-2">휴면</h4>
          <p className="text-xl font-black text-slate-400 tabular-nums">{stats.inactive}</p>
        </div>
        <div className="dashboard-card border-red-600/30 bg-red-600/5 p-4">
          <h4 className="text-[8px] font-black text-red-600 uppercase tracking-widest mb-2">탈퇴</h4>
          <p className="text-xl font-black text-red-600 tabular-nums">{stats.withdrew}</p>
        </div>
      </div>

      {/* 필터 및 검색 */}
      <div className="dashboard-card border-border-main p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search size={14} className="absolute left-3 top-3 text-text-muted" />
            <input
              type="text"
              placeholder="회원명, ID 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-black/30 border border-border-main rounded text-[11px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-blue/50"
            />
          </div>
          <div className="flex gap-2">
            {(['all', 'new', 'active', 'suspended', 'inactive', 'withdrew'] as const).map(status => {
              const colors = status === 'all' ? { text: 'text-text-primary' } : getStatusColor(status);
              return (
                <button
                  key={status}
                  onClick={() => setActiveFilter(status)}
                  className={cn(
                    'px-3 py-2 rounded text-[9px] font-bold uppercase tracking-widest transition-colors',
                    activeFilter === status
                      ? `bg-accent-blue text-white`
                      : `bg-black/30 text-text-muted border border-border-main hover:text-text-primary`
                  )}
                >
                  {status === 'all' ? '전체' : getStatusColor(status as any).label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 회원 목록 */}
      <div className="dashboard-card p-0 overflow-hidden border-border-main shadow-sm">
        <div className="p-6 border-b border-border-main bg-black/10 flex items-center gap-2">
          <Activity size={16} className="text-accent-blue" />
          <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">
            회원 생명주기 관리
          </h3>
          <p className="text-[10px] text-text-muted ml-auto">총 {filteredMembers.length}명</p>
        </div>

        <div className="overflow-x-auto">
          <table className="data-table table-fixed w-full">
            <thead>
              <tr>
                <th className="!text-center text-[10px]">회원 정보</th>
                <th className="!text-center text-[10px]">현재 상태</th>
                <th className="!text-center text-[10px]">가입 이후</th>
                <th className="!text-center text-[10px]">마지막 활동</th>
                <th className="!text-center text-[10px]">설명</th>
                <th className="!text-center text-[10px]">작업</th>
              </tr>
            </thead>
            <tbody>
              {filteredMembers.map(member => {
                const statusColor = getStatusColor(member.status);
                return (
                  <tr key={member.userId} className="hover:bg-white/[0.02]">
                    <td className="!text-center overflow-hidden">
                      <div className="flex flex-col items-center">
                        <span className="text-[11px] font-bold text-text-primary truncate">{member.nickname}</span>
                        <span className="text-[9px] text-text-muted truncate">{member.rank}</span>
                      </div>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <div className="flex items-center justify-center">
                        <span className={cn(
                          'text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded border whitespace-nowrap',
                          `${statusColor.bg} ${statusColor.border} ${statusColor.text}`
                        )}>
                          {statusColor.label}
                        </span>
                      </div>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <span className="text-[10px] font-mono text-text-muted truncate block">
                        {member.daysActive}일
                      </span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <div className="flex items-center justify-center gap-1">
                        <Clock size={12} className={member.inactivityDays > 30 ? 'text-red-500' : 'text-text-muted'} />
                        <span className="text-[10px] text-text-muted truncate">
                          {member.inactivityDays}일 전
                        </span>
                      </div>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <span className="text-[9px] text-text-muted truncate block">
                        {getStatusDescription(member.status)}
                      </span>
                    </td>
                    <td className="!text-center overflow-hidden">
                      <div className="flex items-center justify-center">
                        <button
                          onClick={() => setSelectedMember(member)}
                          className="p-2 rounded hover:bg-white/5 transition-colors text-text-muted hover:text-text-primary"
                        >
                          <ArrowRight size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredMembers.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-[11px] text-text-muted">조건에 맞는 회원이 없습니다</p>
          </div>
        )}
      </div>

      {/* 상태 변경 모달 */}
      {selectedMember && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#020617] border border-border-main rounded-lg w-full max-w-lg p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-text-primary uppercase tracking-wider mb-6">
              {selectedMember.nickname} - 상태 변경
            </h3>

            <div className="mb-6 p-4 bg-black/20 rounded border border-border-main/30">
              <p className="text-[10px] text-text-muted uppercase tracking-widest mb-2">현재 상태</p>
              <p className="text-[12px] font-bold text-text-primary">
                {getStatusColor(selectedMember.status).label}
              </p>
            </div>

            <div className="mb-6">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-3">
                변경 가능한 상태
              </p>
              <div className="space-y-2">
                {(['new', 'active', 'suspended', 'inactive', 'withdrew'] as const).map(status => {
                  const colors = getStatusColor(status);
                  const isCurrentStatus = status === selectedMember.status;
                  return (
                    <button
                      key={status}
                      onClick={() => {
                        if (!isCurrentStatus) {
                          handleStatusChange(selectedMember, status);
                        }
                      }}
                      disabled={isCurrentStatus}
                      className={cn(
                        'w-full p-3 rounded border transition-colors text-left',
                        isCurrentStatus
                          ? 'bg-black/20 border-border-main/30 opacity-50 cursor-not-allowed'
                          : `${colors.bg} ${colors.border} hover:opacity-80`
                      )}
                    >
                      <span className={cn('text-[11px] font-bold uppercase', colors.text)}>
                        {colors.label}
                      </span>
                      <p className="text-[9px] text-text-muted mt-1">
                        {getStatusDescription(status)}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mb-6">
              <label className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2 block">
                변경 사유
              </label>
              <textarea
                placeholder="상태 변경 이유를 입력하세요..."
                value={transitionReason}
                onChange={(e) => setTransitionReason(e.target.value)}
                className="w-full p-3 bg-black/30 border border-border-main rounded text-[10px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-blue/50 resize-none"
                rows={3}
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setSelectedMember(null)}
                className="flex-1 px-4 py-2 rounded border border-border-main bg-black/30 text-text-primary text-[10px] font-bold hover:bg-black/50 transition-colors"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
