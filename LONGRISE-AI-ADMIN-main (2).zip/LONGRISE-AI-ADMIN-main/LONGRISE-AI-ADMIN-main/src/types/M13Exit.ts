/**
 * M13 EXIT 타입 정의
 * V7.5 마스터 플랜 - 13개월 자동 정산 시스템
 */

export interface Member {
  id: string;
  userId: string;
  package: 'Flexible' | 'Basic' | 'Standard' | 'Premium' | 'VIP';
  joinDate: Date;
  status: 'active' | 'completed' | 'paused';
  balance: number;
  rank?: string;
}

export interface M13ExitSettlement {
  id: string;
  memberId: string;
  joinDate: Date;
  m13Date: Date;
  principal: number;
  package: string;

  // 지출 항목
  usdt: number;
  cnyt: number;
  directBonus: number;
  rollupBonus: number;
  globalPool: number;
  totalExpense: number;

  // 정산 결과
  basicRefund: number;
  minimumRefund: number;  // 15% 보장
  finalRefund: number;
  floorApplied: boolean;
  companyLoss: number;

  // 상태
  status: 'pending' | 'completed' | 'error';
  processedAt?: Date;
  errorMessage?: string;
}

export interface M13ExitNotification {
  id: string;
  memberId: string;
  type: 'SMS' | 'EMAIL' | 'PUSH' | 'IN_APP';
  status: 'pending' | 'sent' | 'failed';
  recipient: string;
  message: string;
  sentAt?: Date;
  failureReason?: string;
}

export interface M13ExitAuditLog {
  id: string;
  action: string;
  timestamp: Date;
  memberId: string;
  package: string;
  joinDate: Date;
  m13Date: Date;
  finalRefund: number;
  executedBy: string;
  ipAddress: string;
}

export interface M13ExitQueue {
  id: string;
  memberId: string;
  joinDate: Date;
  m13Date: Date;
  principal: number;
  package: string;
  finalRefund: number;
  status: 'pending' | 'processing' | 'completed';
  createdAt: Date;
  processedAt?: Date;
}
