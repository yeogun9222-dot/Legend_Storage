/**
 * Mock Member Data
 * 회원 대시보드용 테스트 데이터
 */

import { MemberPackage } from '../types';

// 회원 수익
export interface MemberEarnings {
  totalUSDT: number;           // 누적 USDT 수익
  totalCNYT: number;           // 누적 CNYT 수익
  dailyUSDT: number;           // 오늘 USDT 수익
  dailyCNYT: number;           // 오늘 CNYT 수익
  teamBonus: number;           // 팀 보너스
  referralBonus: number;       // 추천 보너스
}

// 거래 기록
export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'earning' | 'termination' | 'bonus';
  date: Date;
  amount: number;
  asset: 'USDT' | 'CNYT';
  description: string;
  status: 'completed' | 'pending' | 'failed';
}

// 중도해지 신청 기록
export interface EarlyTerminationRecord {
  id: string;
  packageId: string;
  packageType: string;
  requestDate: Date;
  principal: number;           // 원금
  refundAmount: number;        // 환급액
  minimumRefund: number;       // 최소보장금
  appliedFloor: boolean;       // 최소보장 적용 여부
  status: 'pending' | 'processing' | 'completed' | 'failed';
  expectedDate: Date;          // 환급 예상일
  completedDate?: Date;        // 완료일
}

// 회원 프로필 인터페이스
export interface MemberProfile {
  id: string;
  userId: string;
  nickname: string;
  rank: string;
  package: string;
  joinDate: Date;
  totalBalance: number;           // USDT 잔액
  totalBalanceCNYT: number;       // CNYT 잔액
  totalAssets: number;            // 총 자산
}

// Mock 회원 프로필 (여러 회원)
const MOCK_MEMBER_PROFILES: Record<string, MemberProfile> = {
  'LR-1001': {
    id: 'member_001',
    userId: 'LR-1001',
    nickname: 'CryptoWhale',
    rank: 'Master Node Level 4',
    package: 'VIP',
    joinDate: new Date('2023-01-15'),
    totalBalance: 5000,           // USDT 잔액
    totalBalanceCNYT: 2500,       // CNYT 잔액
    totalAssets: 7500,            // 총 자산
  },
  'LR-1002': {
    id: 'member_002',
    userId: 'LR-1002',
    nickname: 'InvestJP',
    rank: 'Master Node Level 2',
    package: 'Premium',
    joinDate: new Date('2023-06-01'),
    totalBalance: 1200,
    totalBalanceCNYT: 800,
    totalAssets: 2000,
  },
  'LR-1003': {
    id: 'member_003',
    userId: 'LR-1003',
    nickname: 'Global_Max',
    rank: 'Master Node Level 3',
    package: 'VIP',
    joinDate: new Date('2023-02-10'),
    totalBalance: 8000,
    totalBalanceCNYT: 4000,
    totalAssets: 12000,
  },
};

// Default: VIP_Member_001 (자신의 데이터)
export const MOCK_MEMBER_PROFILE = MOCK_MEMBER_PROFILES['LR-1001'];

// Mock 회원 포트폴리오 (회원별 패키지)
const MOCK_MEMBER_PORTFOLIOS: Record<string, MemberPackage[]> = {
  'LR-1001': [
    {
      id: 'pkg_001',
      packageType: 'VIP',
      principal: 5000,
      joinDate: new Date('2023-01-15'),
      maturityDate: new Date('2024-01-15'),  // 12개월 후
      currentBalance: 5450,        // 원금 + ROI
      currentROI: 9,               // 현재까지 9%
      expectedROI: 18,             // 최종 예상 18%
      status: 'active',
      expectedRefund: 5900,        // 원금 + 최종 ROI
    },
    {
      id: 'pkg_002',
      packageType: 'Premium',
      principal: 1000,
      joinDate: new Date('2023-06-01'),
      maturityDate: new Date('2024-06-01'),
      currentBalance: 1055,
      currentROI: 5.5,
      expectedROI: 11,
      status: 'active',
      expectedRefund: 1110,
    },
  ],
  'LR-1002': [
    {
      id: 'pkg_003',
      packageType: 'Premium',
      principal: 1000,
      joinDate: new Date('2023-06-01'),
      maturityDate: new Date('2024-06-01'),
      currentBalance: 1100,
      currentROI: 10,
      expectedROI: 11,
      status: 'active',
      expectedRefund: 1110,
    },
  ],
  'LR-1003': [
    {
      id: 'pkg_004',
      packageType: 'VIP',
      principal: 8000,
      joinDate: new Date('2023-02-10'),
      maturityDate: new Date('2024-02-10'),
      currentBalance: 8800,
      currentROI: 10,
      expectedROI: 20,
      status: 'active',
      expectedRefund: 9600,
    },
  ],
};

// Default portfolio
export const MOCK_MEMBER_PORTFOLIO = MOCK_MEMBER_PORTFOLIOS['LR-1001'];

// Mock 회원별 수익
const MOCK_MEMBER_EARNINGS_MAP: Record<string, MemberEarnings> = {
  'LR-1001': {
    totalUSDT: 450,              // 누적 USDT 수익
    totalCNYT: 2500,             // 누적 CNYT 수익
    dailyUSDT: 15.2,             // 오늘 USDT
    dailyCNYT: 85.5,             // 오늘 CNYT
    teamBonus: 250,              // 팀 보너스
    referralBonus: 0,            // 추천 보너스
  },
  'LR-1002': {
    totalUSDT: 180,
    totalCNYT: 800,
    dailyUSDT: 5.5,
    dailyCNYT: 25.0,
    teamBonus: 50,
    referralBonus: 0,
  },
  'LR-1003': {
    totalUSDT: 800,
    totalCNYT: 3500,
    dailyUSDT: 25.5,
    dailyCNYT: 120.0,
    teamBonus: 500,
    referralBonus: 0,
  },
};

// Default earnings
export const MOCK_MEMBER_EARNINGS = MOCK_MEMBER_EARNINGS_MAP['LR-1001'];

// Mock 회원별 거래 이력
const MOCK_TRANSACTION_HISTORIES: Record<string, Transaction[]> = {
  'LR-1001': [
    {
      id: 'tx_001',
      type: 'deposit',
      date: new Date('2023-01-15'),
      amount: 5000,
      asset: 'USDT',
      description: 'VIP 패키지 투자',
      status: 'completed',
    },
    {
      id: 'tx_002',
      type: 'earning',
      date: new Date('2023-02-01'),
      amount: 85.5,
      asset: 'CNYT',
      description: '2월 일일 수익',
      status: 'completed',
    },
    {
      id: 'tx_003',
      type: 'bonus',
      date: new Date('2023-02-28'),
      amount: 250,
      asset: 'USDT',
      description: '팀 보너스',
      status: 'completed',
    },
    {
      id: 'tx_004',
      type: 'earning',
      date: new Date('2026-04-21'),
      amount: 15.2,
      asset: 'USDT',
      description: '오늘 수익',
      status: 'completed',
    },
  ],
  'LR-1002': [
    {
      id: 'tx_005',
      type: 'deposit',
      date: new Date('2023-06-01'),
      amount: 1000,
      asset: 'USDT',
      description: 'Premium 패키지 투자',
      status: 'completed',
    },
    {
      id: 'tx_006',
      type: 'earning',
      date: new Date('2026-04-21'),
      amount: 5.5,
      asset: 'USDT',
      description: '오늘 수익',
      status: 'completed',
    },
  ],
  'LR-1003': [
    {
      id: 'tx_007',
      type: 'deposit',
      date: new Date('2023-02-10'),
      amount: 8000,
      asset: 'USDT',
      description: 'VIP 패키지 투자',
      status: 'completed',
    },
    {
      id: 'tx_008',
      type: 'earning',
      date: new Date('2026-04-21'),
      amount: 25.5,
      asset: 'USDT',
      description: '오늘 수익',
      status: 'completed',
    },
  ],
};

// Default transaction history
export const MOCK_TRANSACTION_HISTORY = MOCK_TRANSACTION_HISTORIES['LR-1001'];

// Mock 중도해지 신청 기록
export const MOCK_EARLY_TERMINATION_HISTORY: EarlyTerminationRecord[] = [
  {
    id: 'term_001',
    packageId: 'pkg_history_001',
    packageType: 'Standard',
    requestDate: new Date('2023-09-01'),
    principal: 500,
    refundAmount: 150,           // 15% 최소보장 적용
    minimumRefund: 75,           // 500 × 15%
    appliedFloor: true,
    status: 'completed',
    expectedDate: new Date('2023-09-06'),
    completedDate: new Date('2023-09-05'),
  },
];

// 환급액 계산 함수 (V7.5 정책: 15% 최소보장)
export function calculateEarlyTerminationRefund(
  principal: number,
  currentBalance: number
): { basicRefund: number; minimumRefund: number; finalRefund: number } {
  const minimumRefund = principal * 0.15;  // 15% 최소보장
  const basicRefund = currentBalance - principal; // 이익만 계산하는 경우
  const finalRefund = Math.max(basicRefund, minimumRefund);

  return {
    basicRefund: Math.max(0, basicRefund),
    minimumRefund,
    finalRefund,
  };
}

// 경과 월수 계산
export function calculateElapsedMonths(joinDate: Date): number {
  const now = new Date();
  const months =
    (now.getFullYear() - joinDate.getFullYear()) * 12 +
    (now.getMonth() - joinDate.getMonth());
  return Math.max(0, months);
}

// 조기해지 페널티 계산 (Standard, Premium, VIP)
export function calculateEarlyTerminationPenalty(
  principal: number,
  elapsedMonths: number
): { penalty: number; penaltyPercent: number } {
  let penaltyPercent = 0;

  if (elapsedMonths < 6) {
    penaltyPercent = 30;
  } else if (elapsedMonths < 9) {
    penaltyPercent = 20;
  } else if (elapsedMonths < 12) {
    penaltyPercent = 15;
  }
  // 12개월 이상: 페널티 없음

  const penalty = (principal * penaltyPercent) / 100;
  return { penalty, penaltyPercent };
}

// ========== 회원 데이터 조회 함수 ==========

/**
 * 회원 프로필 조회 (memberId 기반)
 * memberId가 없으면 기본값 (자신의 데이터) 반환
 */
export function getMemberProfile(memberId?: string): MemberProfile {
  if (!memberId || !MOCK_MEMBER_PROFILES[memberId]) {
    return MOCK_MEMBER_PROFILE;
  }
  return MOCK_MEMBER_PROFILES[memberId];
}

/**
 * 회원 포트폴리오 조회 (memberId 기반)
 * memberId가 없으면 기본값 반환
 */
export function getMemberPortfolio(memberId?: string): MemberPackage[] {
  if (!memberId || !MOCK_MEMBER_PORTFOLIOS[memberId]) {
    return MOCK_MEMBER_PORTFOLIO;
  }
  return MOCK_MEMBER_PORTFOLIOS[memberId];
}

/**
 * 회원 수익 조회 (memberId 기반)
 * memberId가 없으면 기본값 반환
 */
export function getMemberEarnings(memberId?: string): MemberEarnings {
  if (!memberId || !MOCK_MEMBER_EARNINGS_MAP[memberId]) {
    return MOCK_MEMBER_EARNINGS;
  }
  return MOCK_MEMBER_EARNINGS_MAP[memberId];
}

/**
 * 회원 거래 이력 조회 (memberId 기반)
 * memberId가 없으면 기본값 반환
 */
export function getMemberTransactionHistory(memberId?: string): Transaction[] {
  if (!memberId || !MOCK_TRANSACTION_HISTORIES[memberId]) {
    return MOCK_TRANSACTION_HISTORY;
  }
  return MOCK_TRANSACTION_HISTORIES[memberId];
}
