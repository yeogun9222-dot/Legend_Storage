/**
 * Audit Logger Utility
 * 관리자 작업 기록 관리
 */

import { AuditLog } from '../types';

// 로컬 저장소에서 감사 로그 관리
const AUDIT_LOG_STORAGE_KEY = 'longrise_audit_logs';

/**
 * 감사 로그 기록
 */
export function recordAuditLog(
  adminId: string,
  adminName: string,
  action: string,
  resource: string,
  resourceId: string,
  changes?: Record<string, any>,
  status: 'success' | 'failed' = 'success',
  errorMessage?: string,
  ipAddress?: string
): AuditLog {
  const log: AuditLog = {
    id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    adminId,
    adminName,
    action,
    resource,
    resourceId,
    changes,
    status,
    errorMessage,
    timestamp: new Date().toISOString(),
    ipAddress,
  };

  // 로컬 스토리지에 저장
  const existingLogs = getAuditLogs();
  const updatedLogs = [log, ...existingLogs].slice(0, 1000); // 최대 1000개 보관
  localStorage.setItem(AUDIT_LOG_STORAGE_KEY, JSON.stringify(updatedLogs));

  // 콘솔 로그
  console.log('[AUDIT LOG]', log);

  // 실제 환경에서는 백엔드로 전송
  // await fetch('/api/audit-logs', { method: 'POST', body: JSON.stringify(log) });

  return log;
}

/**
 * 감사 로그 조회
 */
export function getAuditLogs(limit?: number): AuditLog[] {
  try {
    const logs = localStorage.getItem(AUDIT_LOG_STORAGE_KEY);
    const parsedLogs = logs ? JSON.parse(logs) : [];
    return limit ? parsedLogs.slice(0, limit) : parsedLogs;
  } catch {
    console.warn('Failed to retrieve audit logs from storage');
    return [];
  }
}

/**
 * 특정 리소스의 감사 로그 조회
 */
export function getAuditLogsByResource(
  resource: string,
  resourceId?: string,
  limit?: number
): AuditLog[] {
  const allLogs = getAuditLogs();
  const filtered = allLogs.filter(
    (log) => log.resource === resource && (!resourceId || log.resourceId === resourceId)
  );
  return limit ? filtered.slice(0, limit) : filtered;
}

/**
 * 특정 관리자의 감사 로그 조회
 */
export function getAuditLogsByAdmin(adminId: string, limit?: number): AuditLog[] {
  const allLogs = getAuditLogs();
  const filtered = allLogs.filter((log) => log.adminId === adminId);
  return limit ? filtered.slice(0, limit) : filtered;
}

/**
 * 감사 로그 삭제 (관리자 권한 필요)
 */
export function clearAuditLogs(): void {
  localStorage.removeItem(AUDIT_LOG_STORAGE_KEY);
  console.log('All audit logs cleared');
}

/**
 * 감사 로그 내보내기 (CSV)
 */
export function exportAuditLogsAsCSV(logs?: AuditLog[]): string {
  const dataToExport = logs || getAuditLogs();

  const headers = ['ID', 'Admin ID', 'Admin Name', 'Action', 'Resource', 'Resource ID', 'Status', 'Timestamp'];
  const rows = dataToExport.map((log) => [
    log.id,
    log.adminId,
    log.adminName,
    log.action,
    log.resource,
    log.resourceId,
    log.status,
    log.timestamp,
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n');

  return csvContent;
}

/**
 * 감사 로그를 파일로 다운로드
 */
export function downloadAuditLogs(logs?: AuditLog[]): void {
  const csv = exportAuditLogsAsCSV(logs);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', `audit_logs_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * 일반적인 관리 작업 로깅 헬퍼
 */
export const AuditActions = {
  // 사용자 관련
  CREATE_USER: 'create_user',
  UPDATE_USER: 'update_user',
  DELETE_USER: 'delete_user',
  BAN_USER: 'ban_user',
  UNBAN_USER: 'unban_user',
  RESET_PASSWORD: 'reset_password',
  RESET_KYC: 'reset_kyc',
  FORCE_LOGOUT: 'force_logout',

  // 잔액 관련
  ADJUST_BALANCE: 'adjust_balance',
  ADJUST_POINTS: 'adjust_points',
  FREEZE_ASSET: 'freeze_asset',
  UNFREEZE_ASSET: 'unfreeze_asset',

  // 거래 관련
  APPROVE_WITHDRAWAL: 'approve_withdrawal',
  REJECT_WITHDRAWAL: 'reject_withdrawal',
  BLOCK_WITHDRAWAL: 'block_withdrawal',
  UNBLOCK_WITHDRAWAL: 'unblock_withdrawal',

  // 지갑 관련
  RESET_WALLET: 'reset_wallet',
  UPDATE_WALLET: 'update_wallet',

  // 계정 관련
  LOCK_ACCOUNT: 'lock_account',
  UNLOCK_ACCOUNT: 'unlock_account',
  CHANGE_SPONSOR: 'change_sponsor',
  UPDATE_RANK: 'update_rank',

  // 시스템
  UPDATE_SETTINGS: 'update_settings',
  CREATE_ADMIN: 'create_admin',
  UPDATE_ADMIN: 'update_admin',
  DELETE_ADMIN: 'delete_admin',
} as const;

export type AuditAction = typeof AuditActions[keyof typeof AuditActions];
