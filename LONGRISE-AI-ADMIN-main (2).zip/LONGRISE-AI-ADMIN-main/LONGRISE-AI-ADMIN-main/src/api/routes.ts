/**
 * API Routes
 * V7.5 관리자 대시보드 API 엔드포인트
 */

import { Router, Request, Response } from 'express';
import { db } from '../db';
import { M13ExitService } from '../services/M13ExitService';
import type { Member, M13ExitSettlement } from '../types/M13Exit';

const router = Router();

/**
 * Health Check
 */
router.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// =============================================================================
// Members API
// =============================================================================

/**
 * GET /api/members
 * 모든 회원 조회 (필터 가능)
 */
router.get('/members', async (req: Request, res: Response) => {
  try {
    const { status, package: pkg } = req.query;

    let members = await db.findAllMembers();

    if (status) {
      members = members.filter(m => m.status === status);
    }

    if (pkg) {
      members = members.filter(m => m.package === pkg);
    }

    res.json({
      count: members.length,
      data: members
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch members' });
  }
});

/**
 * GET /api/members/:id
 * 특정 회원 조회
 */
router.get('/members/:id', async (req: Request, res: Response) => {
  try {
    const member = await db.findMemberById(req.params.id);

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    res.json(member);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch member' });
  }
});

/**
 * POST /api/members
 * 회원 생성 (테스트용)
 */
router.post('/members', async (req: Request, res: Response) => {
  try {
    const { userId, package: pkg, balance } = req.body;

    const newMember: Member = {
      id: `member_${Date.now()}`,
      userId,
      package: pkg as any,
      joinDate: new Date(),
      status: 'active',
      balance,
      rank: 'Associate'
    };

    const created = await db.createMember(newMember);
    res.status(201).json(created);
  } catch (error) {
    res.status(400).json({ error: 'Failed to create member' });
  }
});

/**
 * PATCH /api/members/:id
 * 회원 정보 업데이트
 */
router.patch('/members/:id', async (req: Request, res: Response) => {
  try {
    const updated = await db.updateMember(req.params.id, req.body);

    if (!updated) {
      return res.status(404).json({ error: 'Member not found' });
    }

    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: 'Failed to update member' });
  }
});

// =============================================================================
// Settlements API
// =============================================================================

/**
 * GET /api/settlements
 * 모든 정산 기록 조회
 */
router.get('/settlements', async (req: Request, res: Response) => {
  try {
    const settlements = await db.findAllSettlements();

    res.json({
      count: settlements.length,
      data: settlements
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch settlements' });
  }
});

/**
 * GET /api/settlements/:memberId
 * 특정 회원의 정산 기록 조회
 */
router.get('/settlements/:memberId', async (req: Request, res: Response) => {
  try {
    const settlements = await db.findSettlementsByMemberId(req.params.memberId);

    res.json({
      memberId: req.params.memberId,
      count: settlements.length,
      data: settlements
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch settlements' });
  }
});

/**
 * POST /api/settlements
 * 정산 기록 생성
 */
router.post('/settlements', async (req: Request, res: Response) => {
  try {
    const settlement = await db.createSettlement(req.body as M13ExitSettlement);

    res.status(201).json(settlement);
  } catch (error) {
    res.status(400).json({ error: 'Failed to create settlement' });
  }
});

// =============================================================================
// M13 EXIT API
// =============================================================================

/**
 * GET /api/m13-exit/pending
 * M13 EXIT 대기 회원 조회
 */
router.get('/m13-exit/pending', async (req: Request, res: Response) => {
  try {
    const pending = await db.getM13ExitPending();

    res.json({
      count: pending.length,
      data: pending
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch pending M13 exits' });
  }
});

/**
 * POST /api/m13-exit/calculate
 * M13 EXIT 정산 계산
 */
router.post('/m13-exit/calculate', async (req: Request, res: Response) => {
  try {
    const { memberId, principal } = req.body;

    const member = await db.findMemberById(memberId);
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const settlement = M13ExitService.calculateM13Settlement(member, principal);

    res.json(settlement);
  } catch (error) {
    res.status(400).json({ error: 'Failed to calculate M13 exit' });
  }
});

/**
 * POST /api/m13-exit/process
 * M13 EXIT 자동 정산 실행
 */
router.post('/m13-exit/process', async (req: Request, res: Response) => {
  try {
    const members = await db.findActiveMembers();
    const pending = await db.getM13ExitPending();

    let processedCount = 0;

    for (const member of pending) {
      const settlement = M13ExitService.calculateM13Settlement(member, member.balance);
      await db.createSettlement(settlement);

      const log = M13ExitService.createAuditLog(settlement, member);
      // await db.createAuditLog(log);

      await db.updateMember(member.id, { status: 'completed' });

      processedCount++;
    }

    res.json({
      processedCount,
      message: `M13 EXIT 처리 완료: ${processedCount}명`
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process M13 exit' });
  }
});

// =============================================================================
// Statistics API
// =============================================================================

/**
 * GET /api/statistics/members
 * 회원 통계
 */
router.get('/statistics/members', async (req: Request, res: Response) => {
  try {
    const summary = await db.getActiveMembersSummary();

    res.json(summary);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

/**
 * GET /api/statistics/monthly/:month
 * 월간 정산 통계
 */
router.get('/statistics/monthly/:month', async (req: Request, res: Response) => {
  try {
    const [year, month] = req.params.month.split('-').map(Number);
    const monthDate = new Date(year, month - 1, 1);

    const summary = await db.getMonthlySummary(monthDate);

    res.json(summary);
  } catch (error) {
    res.status(400).json({ error: 'Invalid month format' });
  }
});

/**
 * GET /api/statistics/revenue
 * 누적 수익
 */
router.get('/statistics/revenue', async (req: Request, res: Response) => {
  try {
    const members = await db.findAllMembers();
    const totalBalance = members.reduce((sum, m) => sum + m.balance, 0);

    const settlements = await db.findAllSettlements();
    const totalRefunds = settlements.reduce((sum, s) => sum + s.finalRefund, 0);

    res.json({
      totalBalance,
      totalRefunds,
      netRevenue: totalBalance - totalRefunds,
      memberCount: members.length
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch revenue statistics' });
  }
});

// =============================================================================
// Health & Debug
// =============================================================================

/**
 * GET /api/debug/data
 * 현재 데이터 상태 (개발용)
 */
router.get('/debug/data', async (req: Request, res: Response) => {
  try {
    const members = await db.findAllMembers();
    const settlements = await db.findAllSettlements();

    res.json({
      membersCount: members.length,
      settlementsCount: settlements.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch debug data' });
  }
});

export default router;
