/**
 * API Client
 * Dashboard 컴포넌트에서 API 호출
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

interface ApiResponse<T> {
  status: number;
  data?: T;
  error?: string;
  message?: string;
}

/**
 * 기본 API 호출 함수
 */
async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const url = `${API_BASE_URL}${endpoint}`;
    const defaultOptions: RequestInit = {
      headers: {
        'Content-Type': 'application/json'
      },
      ...options
    };

    const response = await fetch(url, defaultOptions);
    const data = await response.json();

    return {
      status: response.status,
      data: response.ok ? data : undefined,
      error: !response.ok ? data.error : undefined,
      message: data.message
    };
  } catch (error) {
    console.error(`API 호출 오류 [${endpoint}]:`, error);
    return {
      status: 0,
      error: 'Network error'
    };
  }
}

// =============================================================================
// Members API
// =============================================================================

export async function fetchAllMembers() {
  return apiCall('/members');
}

export async function fetchMemberById(id: string) {
  return apiCall(`/members/${id}`);
}

export async function createMember(memberData: any) {
  return apiCall('/members', {
    method: 'POST',
    body: JSON.stringify(memberData)
  });
}

export async function updateMember(id: string, updates: any) {
  return apiCall(`/members/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates)
  });
}

// =============================================================================
// Settlements API
// =============================================================================

export async function fetchAllSettlements() {
  return apiCall('/settlements');
}

export async function fetchMemberSettlements(memberId: string) {
  return apiCall(`/settlements/${memberId}`);
}

export async function createSettlement(settlementData: any) {
  return apiCall('/settlements', {
    method: 'POST',
    body: JSON.stringify(settlementData)
  });
}

// =============================================================================
// M13 EXIT API
// =============================================================================

export async function fetchM13ExitPending() {
  return apiCall('/m13-exit/pending');
}

export async function calculateM13Exit(memberId: string, principal: number) {
  return apiCall('/m13-exit/calculate', {
    method: 'POST',
    body: JSON.stringify({ memberId, principal })
  });
}

export async function processM13Exits() {
  return apiCall('/m13-exit/process', {
    method: 'POST'
  });
}

// =============================================================================
// Statistics API
// =============================================================================

export async function fetchMembersStatistics() {
  return apiCall('/statistics/members');
}

export async function fetchMonthlySummary(month: string) {
  return apiCall(`/statistics/monthly/${month}`);
}

export async function fetchRevenueStatistics() {
  return apiCall('/statistics/revenue');
}

// =============================================================================
// Health & Debug
// =============================================================================

export async function checkHealth() {
  return apiCall('/health');
}

export async function fetchDebugData() {
  return apiCall('/debug/data');
}

// =============================================================================
// 고급 쿼리
// =============================================================================

/**
 * 모든 회원 데이터 한 번에 로드
 */
export async function loadAllDashboardData() {
  try {
    const [members, settlements, m13Pending, stats, revenue] = await Promise.all([
      fetchAllMembers(),
      fetchAllSettlements(),
      fetchM13ExitPending(),
      fetchMembersStatistics(),
      fetchRevenueStatistics()
    ]);

    return {
      members,
      settlements,
      m13Pending,
      stats,
      revenue,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('대시보드 데이터 로드 오류:', error);
    throw error;
  }
}

/**
 * 실시간 수익 데이터 구독 (폴링)
 */
export function subscribeToRevenueUpdates(
  callback: (data: any) => void,
  interval: number = 30000
) {
  const intervalId = setInterval(async () => {
    const response = await fetchRevenueStatistics();
    if (response.data) {
      callback(response.data);
    }
  }, interval);

  return () => clearInterval(intervalId);
}

/**
 * M13 EXIT 실시간 모니터링
 */
export function subscribeToM13ExitUpdates(
  callback: (data: any) => void,
  interval: number = 60000
) {
  const intervalId = setInterval(async () => {
    const response = await fetchM13ExitPending();
    if (response.data) {
      callback(response.data);
    }
  }, interval);

  return () => clearInterval(intervalId);
}
