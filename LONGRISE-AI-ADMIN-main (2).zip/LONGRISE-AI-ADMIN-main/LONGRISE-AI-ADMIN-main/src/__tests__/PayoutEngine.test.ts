/**
 * Phase 3 QA: PayoutEngine 20개 시나리오 자동 테스트
 * 담당: 설리 (QA)
 * 목표: 15% 최소환급금 보장 검증
 */

interface TestCase {
  id: string;
  principal: number;
  monthsElapsed: number;
  package: 'Flexible' | 'Basic' | 'Standard' | 'Premium' | 'VIP';
  expectedBasicRefund: number;
  expectedMinimumRefund: number;
  expectedFinalRefund: number;
  expectsFloorApplied: boolean;
  description: string;
}

// 15% 최소환급금 계산 함수 (PayoutEngine.tsx에서 사용하는 로직)
function calculateEarlyExit(principal: number, monthsElapsed: number, pkg: string) {
  const usedtRate = { Flexible: 4, Basic: 7, Standard: 9, Premium: 11, VIP: 18 }[pkg as any] || 9;
  const cnytRatio = { Basic: 2, Standard: 4, Premium: 6, VIP: 10 }[pkg as any] || 2;

  const usdt = (principal * usedtRate * monthsElapsed) / 100;
  const cnytValue = (principal * cnytRatio * monthsElapsed) / 100;
  const directBonus = principal * 0.12;
  const rollupBonus = usdt * 0.1111;
  const globalPool = (usdt + cnytValue) * 0.02;
  const totalExpense = usdt + cnytValue + directBonus + rollupBonus + globalPool;

  let earlyExitFee = 0;
  if (monthsElapsed <= 6) earlyExitFee = principal * 0.30;
  else if (monthsElapsed <= 9) earlyExitFee = principal * 0.20;
  else if (monthsElapsed <= 11) earlyExitFee = principal * 0.15;
  else earlyExitFee = principal * 0.10;

  const basicRefund = principal - totalExpense - earlyExitFee;
  const minimumRefund = principal * 0.15;
  const finalRefund = Math.max(basicRefund, minimumRefund);
  const companyLoss = Math.min(0, basicRefund - minimumRefund);

  return {
    principal,
    usdt: Math.round(usdt * 100) / 100,
    cnyt: Math.round(cnytValue * 100) / 100,
    directBonus: Math.round(directBonus * 100) / 100,
    rollup: Math.round(rollupBonus * 100) / 100,
    globalPool: Math.round(globalPool * 100) / 100,
    totalExpense: Math.round(totalExpense * 100) / 100,
    basicRefund: Math.round(basicRefund * 100) / 100,
    earlyExitFee: Math.round(earlyExitFee * 100) / 100,
    minimumRefund: Math.round(minimumRefund * 100) / 100,
    finalRefund: Math.round(finalRefund * 100) / 100,
    companyLoss: Math.round(companyLoss * 100) / 100,
    floorApplied: finalRefund > basicRefund
  };
}

// 20개 테스트 케이스
const testCases: TestCase[] = [
  // Group 1: Flexible ($100)
  {
    id: 'TC-1-1',
    principal: 100,
    monthsElapsed: 3,
    package: 'Flexible',
    expectedBasicRefund: 38.31,
    expectedMinimumRefund: 15,
    expectedFinalRefund: 38.31,
    expectsFloorApplied: false,
    description: 'Flexible, M1-M3 (조기 환매 최고 수수료)'
  },
  {
    id: 'TC-1-2',
    principal: 100,
    monthsElapsed: 5,
    package: 'Flexible',
    expectedBasicRefund: 25.18,
    expectedMinimumRefund: 15,
    expectedFinalRefund: 25.18,
    expectsFloorApplied: false,
    description: 'Flexible, M4-M6'
  },
  {
    id: 'TC-1-3',
    principal: 100,
    monthsElapsed: 8,
    package: 'Flexible',
    expectedBasicRefund: 15.49,
    expectedMinimumRefund: 15,
    expectedFinalRefund: 15.49,
    expectsFloorApplied: false,
    description: 'Flexible, M7-M9 (중기 수수료)'
  },
  {
    id: 'TC-1-4',
    principal: 100,
    monthsElapsed: 11,
    package: 'Flexible',
    expectedBasicRefund: 0.79,
    expectedMinimumRefund: 15,
    expectedFinalRefund: 15,
    expectsFloorApplied: true,
    description: 'Flexible, M10-M12 (보장 적용!)'
  },

  // Group 2: Basic ($200)
  {
    id: 'TC-2-1',
    principal: 200,
    monthsElapsed: 3,
    package: 'Basic',
    expectedBasicRefund: 56.25,
    expectedMinimumRefund: 30,
    expectedFinalRefund: 56.25,
    expectsFloorApplied: false,
    description: 'Basic, M1-M3'
  },
  {
    id: 'TC-2-2',
    principal: 200,
    monthsElapsed: 6,
    package: 'Basic',
    expectedBasicRefund: -3.49,
    expectedMinimumRefund: 30,
    expectedFinalRefund: 30,
    expectsFloorApplied: true,
    description: 'Basic, M4-M6 (보장 적용!)'
  },
  {
    id: 'TC-2-3',
    principal: 200,
    monthsElapsed: 8,
    package: 'Basic',
    expectedBasicRefund: -23.32,
    expectedMinimumRefund: 30,
    expectedFinalRefund: 30,
    expectsFloorApplied: true,
    description: 'Basic, M7-M9 (보장 적용!)'
  },
  {
    id: 'TC-2-4',
    principal: 200,
    monthsElapsed: 12,
    package: 'Basic',
    expectedBasicRefund: -82.98,
    expectedMinimumRefund: 30,
    expectedFinalRefund: 30,
    expectsFloorApplied: true,
    description: 'Basic, M10-M12 (보장 적용!)'
  },

  // Group 3: Standard ($500)
  {
    id: 'TC-3-1',
    principal: 500,
    monthsElapsed: 3,
    package: 'Standard',
    expectedBasicRefund: 76.10,
    expectedMinimumRefund: 75,
    expectedFinalRefund: 76.10,
    expectsFloorApplied: false,
    description: 'Standard, M1-M3'
  },
  {
    id: 'TC-3-2',
    principal: 500,
    monthsElapsed: 6,
    package: 'Standard',
    expectedBasicRefund: -137.80,
    expectedMinimumRefund: 75,
    expectedFinalRefund: 75,
    expectsFloorApplied: true,
    description: 'Standard, M4-M6 (보장 적용!)'
  },
  {
    id: 'TC-3-3',
    principal: 500,
    monthsElapsed: 8,
    package: 'Standard',
    expectedBasicRefund: -230.40,
    expectedMinimumRefund: 75,
    expectedFinalRefund: 75,
    expectsFloorApplied: true,
    description: 'Standard, M7-M9 (보장 적용!)'
  },
  {
    id: 'TC-3-4',
    principal: 500,
    monthsElapsed: 12,
    package: 'Standard',
    expectedBasicRefund: -465.60,
    expectedMinimumRefund: 75,
    expectedFinalRefund: 75,
    expectsFloorApplied: true,
    description: 'Standard, M10-M12 (보장 적용!)'
  },

  // Group 4: Premium ($1,000)
  {
    id: 'TC-4-1',
    principal: 1000,
    monthsElapsed: 3,
    package: 'Premium',
    expectedBasicRefund: 23.17,
    expectedMinimumRefund: 150,
    expectedFinalRefund: 150,
    expectsFloorApplied: true,
    description: 'Premium, M1-M3 (보장 적용!)'
  },
  {
    id: 'TC-4-2',
    principal: 1000,
    monthsElapsed: 6,
    package: 'Premium',
    expectedBasicRefund: -533.67,
    expectedMinimumRefund: 150,
    expectedFinalRefund: 150,
    expectsFloorApplied: true,
    description: 'Premium, M4-M6 (보장 적용!)'
  },
  {
    id: 'TC-4-3',
    principal: 1000,
    monthsElapsed: 8,
    package: 'Premium',
    expectedBasicRefund: -804.87,
    expectedMinimumRefund: 150,
    expectedFinalRefund: 150,
    expectsFloorApplied: true,
    description: 'Premium, M7-M9 (보장 적용!)'
  },
  {
    id: 'TC-4-4',
    principal: 1000,
    monthsElapsed: 12,
    package: 'Premium',
    expectedBasicRefund: -1447.45,
    expectedMinimumRefund: 150,
    expectedFinalRefund: 150,
    expectsFloorApplied: true,
    description: 'Premium, M10-M12 (보장 적용!)'
  },

  // Group 5: VIP ($5,000)
  {
    id: 'TC-5-1',
    principal: 5000,
    monthsElapsed: 3,
    package: 'VIP',
    expectedBasicRefund: -1683.97,
    expectedMinimumRefund: 750,
    expectedFinalRefund: 750,
    expectsFloorApplied: true,
    description: 'VIP, M1-M3 (보장 적용!)'
  },
  {
    id: 'TC-5-2',
    principal: 5000,
    monthsElapsed: 6,
    package: 'VIP',
    expectedBasicRefund: -6267.94,
    expectedMinimumRefund: 750,
    expectedFinalRefund: 750,
    expectsFloorApplied: true,
    description: 'VIP, M4-M6 (보장 적용!)'
  },
  {
    id: 'TC-5-3',
    principal: 5000,
    monthsElapsed: 9,
    package: 'VIP',
    expectedBasicRefund: -10351.91,
    expectedMinimumRefund: 750,
    expectedFinalRefund: 750,
    expectsFloorApplied: true,
    description: 'VIP, M7-M9 (보장 적용!)'
  },
  {
    id: 'TC-5-4',
    principal: 5000,
    monthsElapsed: 13,
    package: 'VIP',
    expectedBasicRefund: -15463.87,
    expectedMinimumRefund: 750,
    expectedFinalRefund: 750,
    expectsFloorApplied: true,
    description: 'VIP, M13 EXIT (보장 적용!)'
  }
];

// 테스트 실행
function runTests() {
  console.log('🧪 Phase 3 QA: PayoutEngine 20개 시나리오 자동 테스트\n');
  console.log('=' .repeat(80));

  let passCount = 0;
  let failCount = 0;
  const failedTests: any[] = [];

  testCases.forEach((testCase) => {
    const result = calculateEarlyExit(testCase.principal, testCase.monthsElapsed, testCase.package);

    // 검증
    const basicRefundMatch = Math.abs(result.basicRefund - testCase.expectedBasicRefund) < 0.1;
    const minimumRefundMatch = Math.abs(result.minimumRefund - testCase.expectedMinimumRefund) < 0.1;
    const finalRefundMatch = Math.abs(result.finalRefund - testCase.expectedFinalRefund) < 0.1;
    const floorAppliedMatch = result.floorApplied === testCase.expectsFloorApplied;

    const allMatch = basicRefundMatch && minimumRefundMatch && finalRefundMatch && floorAppliedMatch;

    if (allMatch) {
      passCount++;
      console.log(`✅ ${testCase.id}: ${testCase.description}`);
      console.log(`   최종환급: $${result.finalRefund.toFixed(2)} (보장: ${result.floorApplied ? '⭕ 적용' : '❌ 미적용'})\n`);
    } else {
      failCount++;
      failedTests.push({ testCase, result });
      console.log(`❌ ${testCase.id}: ${testCase.description}`);
      console.log(`   예상: $${testCase.expectedFinalRefund.toFixed(2)} / 실제: $${result.finalRefund.toFixed(2)}`);
      if (!basicRefundMatch) console.log(`   ⚠️  기본계산: 예상 $${testCase.expectedBasicRefund.toFixed(2)}, 실제 $${result.basicRefund.toFixed(2)}`);
      if (!floorAppliedMatch) console.log(`   ⚠️  보장적용: 예상 ${testCase.expectsFloorApplied}, 실제 ${result.floorApplied}`);
      console.log();
    }
  });

  console.log('=' .repeat(80));
  console.log(`\n📊 테스트 결과\n`);
  console.log(`✅ 통과: ${passCount}개 / ❌ 실패: ${failCount}개`);
  console.log(`📈 성공률: ${((passCount / testCases.length) * 100).toFixed(1)}%\n`);

  if (failCount > 0) {
    console.log(`🔴 실패한 테스트 상세:`);
    failedTests.forEach(({ testCase, result }) => {
      console.log(`\n${testCase.id}: ${testCase.description}`);
      console.log(`  기본계산:   예상 $${testCase.expectedBasicRefund.toFixed(2)} / 실제 $${result.basicRefund.toFixed(2)}`);
      console.log(`  최소보장:   예상 $${testCase.expectedMinimumRefund.toFixed(2)} / 실제 $${result.minimumRefund.toFixed(2)}`);
      console.log(`  최종환급:   예상 $${testCase.expectedFinalRefund.toFixed(2)} / 실제 $${result.finalRefund.toFixed(2)}`);
      console.log(`  보장적용:   예상 ${testCase.expectsFloorApplied} / 실제 ${result.floorApplied}`);
    });
  }

  return { passCount, failCount, total: testCases.length };
}

// 테스트 실행 (Node.js 환경)
if (typeof require !== 'undefined' && require.main === module) {
  runTests();
}

export { calculateEarlyExit, testCases, runTests };
