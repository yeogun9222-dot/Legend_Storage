/**
 * M13 EXIT 자동화 테스트
 * 제이크의 M13 EXIT 크론 작업 검증
 */

import { M13ExitService, triggerM13ExitAutomation } from '../services/M13ExitService';
import type { Member } from '../types/M13Exit';

// 테스트 회원 데이터 - 정확히 13개월 전 계산
function createTestMembers(): Member[] {
  const now = new Date();

  // 정확히 13개월 전 날짜 계산
  const m13AgoDate = new Date(now);
  m13AgoDate.setMonth(m13AgoDate.getMonth() - 13);

  // 10개월 전 날짜
  const m10AgoDate = new Date(now);
  m10AgoDate.setMonth(m10AgoDate.getMonth() - 10);

  return [
    {
      id: 'member_001',
      userId: 'user_001',
      package: 'VIP' as const,
      joinDate: m13AgoDate, // 정확히 13개월 전
      status: 'active' as const,
      balance: 5000,
      rank: 'Master Node Level 4'
    },
    {
      id: 'member_002',
      userId: 'user_002',
      package: 'Premium' as const,
      joinDate: m13AgoDate, // 정확히 13개월 전
      status: 'active' as const,
      balance: 1000,
      rank: 'Master Node Level 3'
    },
    {
      id: 'member_003',
      userId: 'user_003',
      package: 'Standard' as const,
      joinDate: m13AgoDate, // 정확히 13개월 전
      status: 'active' as const,
      balance: 500,
      rank: 'Master Node Level 2'
    },
    {
      id: 'member_004',
      userId: 'user_004',
      package: 'Basic' as const,
      joinDate: m10AgoDate, // 10개월 전 (아직 미만기)
      status: 'active' as const,
      balance: 200,
      rank: 'Master Node Level 1'
    }
  ];
}

const testMembers = createTestMembers();

/**
 * 테스트 1: M13 도달 회원 감지
 */
function testCheckM13ExitSchedule() {
  console.log('\n✅ 테스트 1: M13 도달 회원 감지');
  console.log('─'.repeat(60));

  const m13Members = M13ExitService.checkM13ExitSchedule(testMembers);

  console.log(`입력: ${testMembers.length}명`);
  console.log(`감지된 M13: ${m13Members.length}명`);

  if (m13Members.length === 3) {
    console.log('✅ PASS - 13개월 만기 회원 3명 정확히 감지됨');
    return true;
  } else {
    console.log(`❌ FAIL - 예상 3명, 실제 ${m13Members.length}명`);
    return false;
  }
}

/**
 * 테스트 2: M13 정산 계산 (15% 보장)
 */
function testCalculateM13Settlement() {
  console.log('\n✅ 테스트 2: M13 정산 계산 (15% 최소보장)');
  console.log('─'.repeat(60));

  const vipMember = testMembers[0]; // VIP $5,000
  const settlement = M13ExitService.calculateM13Settlement(vipMember, 5000);

  console.log(`\n회원: ${vipMember.userId} (${vipMember.package} $5,000)`);
  console.log(`├─ USDT배당: $${settlement.usdt.toFixed(2)}`);
  console.log(`├─ CNYT매입: $${settlement.cnyt.toFixed(2)}`);
  console.log(`├─ 직접추천: $${settlement.directBonus.toFixed(2)}`);
  console.log(`├─ 롤업: $${settlement.rollupBonus.toFixed(2)}`);
  console.log(`├─ 글로벌풀: $${settlement.globalPool.toFixed(2)}`);
  console.log(`├─ 총지출: $${settlement.totalExpense.toFixed(2)}`);
  console.log(`├─ 기본계산: $${settlement.basicRefund.toFixed(2)}`);
  console.log(`├─ 최소보장: $${settlement.minimumRefund.toFixed(2)}`);
  console.log(`├─ 최종환급: $${settlement.finalRefund.toFixed(2)} ${settlement.floorApplied ? '✅' : '❌'}`);
  console.log(`└─ 보장적용: ${settlement.floorApplied ? '⭕' : '❌'}`);

  // 15% 최소보장이 정확한지 확인
  if (settlement.finalRefund === 750 && settlement.floorApplied) {
    console.log('✅ PASS - 15% 최소보장 ($750) 정확히 적용됨');
    return true;
  } else {
    console.log(
      `❌ FAIL - 예상 $750 (보장), 실제 $${settlement.finalRefund.toFixed(2)} (${settlement.floorApplied ? '적용' : '미적용'})`
    );
    return false;
  }
}

/**
 * 테스트 3: 알림 생성
 */
function testCreateM13Notifications() {
  console.log('\n✅ 테스트 3: M13 EXIT 알림 생성');
  console.log('─'.repeat(60));

  const member = testMembers[1]; // Premium $1,000
  const settlement = M13ExitService.calculateM13Settlement(member, 1000);
  const notifications = M13ExitService.createM13Notifications(
    settlement,
    'user@example.com',
    '010-0000-0000'
  );

  console.log(`생성된 알림: ${notifications.length}개`);
  notifications.forEach((notif) => {
    console.log(`├─ ${notif.type}: ${notif.status}`);
  });

  if (notifications.length === 4) {
    console.log('✅ PASS - SMS, EMAIL, PUSH, IN_APP 4개 알림 생성됨');
    return true;
  } else {
    console.log(`❌ FAIL - 예상 4개, 실제 ${notifications.length}개`);
    return false;
  }
}

/**
 * 테스트 4: 감사 로그 생성
 */
function testCreateAuditLog() {
  console.log('\n✅ 테스트 4: 감사 로그 생성');
  console.log('─'.repeat(60));

  const member = testMembers[2]; // Standard $500
  const settlement = M13ExitService.calculateM13Settlement(member, 500);
  const log = M13ExitService.createAuditLog(settlement, member);

  console.log(`로그: ${log.action}`);
  console.log(`├─ 회원: ${log.memberId}`);
  console.log(`├─ 환급액: $${log.finalRefund.toFixed(2)}`);
  console.log(`├─ 실행자: ${log.executedBy}`);
  console.log(`└─ 시각: ${log.timestamp.toISOString()}`);

  if (log.action === 'M13_EXIT_PROCESSED' && log.finalRefund === 75) {
    console.log('✅ PASS - 감사 로그 정확히 생성됨');
    return true;
  } else {
    console.log('❌ FAIL - 로그 생성 오류');
    return false;
  }
}

/**
 * 테스트 5: 전체 자동화 프로세스
 */
async function testM13ExitAutomation() {
  console.log('\n✅ 테스트 5: 전체 M13 EXIT 자동화 프로세스');
  console.log('─'.repeat(60));

  const result = await triggerM13ExitAutomation(testMembers);

  console.log(`\n처리 결과:`);
  console.log(`├─ 처리된 회원: ${result.processedCount}명`);
  console.log(`├─ 생성된 정산: ${result.settlements.length}개`);
  console.log(`├─ 발송된 알림: ${result.notifications.length}개`);
  console.log(`└─ 기록된 로그: ${result.logs.length}개`);

  // 상세 정산 내역
  console.log(`\n정산 상세:`);
  result.settlements.forEach((settlement) => {
    console.log(
      `├─ ${settlement.memberId} (${settlement.package}): $${settlement.finalRefund.toFixed(2)} ${settlement.floorApplied ? '✅' : '❌'}`
    );
  });

  if (result.processedCount === 3) {
    console.log('\n✅ PASS - 3명 정산 완료');
    return true;
  } else {
    console.log(`\n❌ FAIL - 예상 3명, 실제 ${result.processedCount}명`);
    return false;
  }
}

/**
 * 모든 테스트 실행
 */
async function runAllTests() {
  console.log('\n');
  console.log('╔' + '═'.repeat(60) + '╗');
  console.log('║ 🧪 M13 EXIT 자동화 테스트 시작 (제이크 Phase 3)            ║');
  console.log('╚' + '═'.repeat(60) + '╝');

  const results = [
    testCheckM13ExitSchedule(),
    testCalculateM13Settlement(),
    testCreateM13Notifications(),
    testCreateAuditLog(),
    await testM13ExitAutomation()
  ];

  const passCount = results.filter((r) => r).length;
  const totalCount = results.length;

  console.log('\n');
  console.log('╔' + '═'.repeat(60) + '╗');
  console.log(`║ 📊 최종 결과: ${passCount}/${totalCount} 테스트 통과             ${' '.repeat(10 - String(passCount).length)}║`);
  console.log('╚' + '═'.repeat(60) + '╝');

  if (passCount === totalCount) {
    console.log('\n🎉 모든 M13 EXIT 자동화 테스트 통과!\n');
  } else {
    console.log(`\n⚠️  ${totalCount - passCount}개 테스트 실패 - 확인 필요\n`);
  }
}

// 테스트 실행
runAllTests().catch(console.error);
