/**
 * Database Connection & ORM Setup
 * MySQL/MariaDB 연결 및 쿼리 빌더
 */

import type {
  Member,
  M13ExitSettlement,
  M13ExitNotification,
  M13ExitAuditLog
} from '../types/M13Exit';

/**
 * 간단한 DB 추상화 레이어 (개발용)
 * 실제 프로덕션에서는 TypeORM, Prisma, Sequelize 등을 사용
 */
export class Database {
  private static instance: Database;

  // Mock 데이터 저장소 (개발 중)
  private members: Member[] = [];
  private settlements: M13ExitSettlement[] = [];
  private auditLogs: M13ExitAuditLog[] = [];

  private constructor() {
    console.log('🗄️  Database 초기화 (Mock Mode)');
  }

  static getInstance(): Database {
    if (!Database.instance) {
      Database.instance = new Database();
    }
    return Database.instance;
  }

  // ==========================================================================
  // Members 쿼리
  // ==========================================================================

  async findAllMembers(): Promise<Member[]> {
    return this.members;
  }

  async findActiveMembers(): Promise<Member[]> {
    return this.members.filter(m => m.status === 'active');
  }

  async findMemberById(id: string): Promise<Member | undefined> {
    return this.members.find(m => m.id === id);
  }

  async findMemberByUserId(userId: string): Promise<Member | undefined> {
    return this.members.find(m => m.userId === userId);
  }

  async createMember(member: Member): Promise<Member> {
    this.members.push(member);
    return member;
  }

  async updateMember(id: string, updates: Partial<Member>): Promise<Member | undefined> {
    const index = this.members.findIndex(m => m.id === id);
    if (index === -1) return undefined;

    this.members[index] = { ...this.members[index], ...updates };
    return this.members[index];
  }

  // ==========================================================================
  // Settlements 쿼리
  // ==========================================================================

  async findAllSettlements(): Promise<M13ExitSettlement[]> {
    return this.settlements;
  }

  async findSettlementsByMemberId(memberId: string): Promise<M13ExitSettlement[]> {
    return this.settlements.filter(s => s.memberId === memberId);
  }

  async createSettlement(settlement: M13ExitSettlement): Promise<M13ExitSettlement> {
    this.settlements.push(settlement);
    return settlement;
  }

  async updateSettlement(
    id: string,
    updates: Partial<M13ExitSettlement>
  ): Promise<M13ExitSettlement | undefined> {
    const index = this.settlements.findIndex(s => s.id === id);
    if (index === -1) return undefined;

    this.settlements[index] = { ...this.settlements[index], ...updates };
    return this.settlements[index];
  }

  // ==========================================================================
  // Audit Logs 쿼리
  // ==========================================================================

  async findAllAuditLogs(): Promise<M13ExitAuditLog[]> {
    return this.auditLogs;
  }

  async createAuditLog(log: M13ExitAuditLog): Promise<M13ExitAuditLog> {
    this.auditLogs.push(log);
    return log;
  }

  // ==========================================================================
  // 트랜잭션
  // ==========================================================================

  async transaction<T>(callback: (db: Database) => Promise<T>): Promise<T> {
    try {
      return await callback(this);
    } catch (error) {
      console.error('❌ 트랜잭션 오류:', error);
      throw error;
    }
  }

  // ==========================================================================
  // 통계 쿼리
  // ==========================================================================

  async getActiveMembersSummary() {
    const active = this.members.filter(m => m.status === 'active');

    return {
      total: active.length,
      byPackage: {
        Flexible: active.filter(m => m.package === 'Flexible').length,
        Basic: active.filter(m => m.package === 'Basic').length,
        Standard: active.filter(m => m.package === 'Standard').length,
        Premium: active.filter(m => m.package === 'Premium').length,
        VIP: active.filter(m => m.package === 'VIP').length
      },
      totalBalance: active.reduce((sum, m) => sum + m.balance, 0)
    };
  }

  async getM13ExitPending() {
    const now = new Date();
    return this.members.filter(m => {
      if (m.status !== 'active') return false;

      const joinDate = new Date(m.joinDate);
      const m13Date = new Date(joinDate);
      m13Date.setMonth(m13Date.getMonth() + 13);

      return now >= m13Date;
    });
  }

  async getMonthlySummary(month: Date) {
    const startDate = new Date(month.getFullYear(), month.getMonth(), 1);
    const endDate = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const monthlySettlements = this.settlements.filter(s => {
      const created = new Date(s.createdAt || new Date());
      return created >= startDate && created <= endDate;
    });

    return {
      month: month.toISOString().slice(0, 7),
      count: monthlySettlements.length,
      totalPrincipal: monthlySettlements.reduce((sum, s) => sum + s.principal, 0),
      totalRefund: monthlySettlements.reduce((sum, s) => sum + s.finalRefund, 0),
      totalCompanyLoss: monthlySettlements.reduce((sum, s) => sum + (s.companyLoss || 0), 0),
      floorAppliedRate:
        monthlySettlements.length > 0
          ? (monthlySettlements.filter(s => s.floorApplied).length / monthlySettlements.length) * 100
          : 0
    };
  }

  // ==========================================================================
  // 데이터 초기화 (개발용)
  // ==========================================================================

  async seed(testMembers: Member[], testSettlements?: M13ExitSettlement[]) {
    this.members = testMembers;
    if (testSettlements) {
      this.settlements = testSettlements;
    }
    console.log(`✅ Seed 데이터 로드: ${testMembers.length}명 회원`);
  }

  async clear() {
    this.members = [];
    this.settlements = [];
    this.auditLogs = [];
    console.log('🗑️  데이터베이스 초기화됨');
  }
}

// Singleton 인스턴스 내보내기
export const db = Database.getInstance();
