/**
 * Data Migration Script
 * Mock 데이터 → Production DB 마이그레이션
 */

import { db } from '../db';
import type { Member, M13ExitSettlement } from '../types/M13Exit';

/**
 * Mock 데이터 정의
 */
const MOCK_MEMBERS: Member[] = [
  {
    id: 'member_001',
    userId: 'user_vip_001',
    package: 'VIP',
    joinDate: new Date('2023-01-15'),
    status: 'active',
    balance: 5000,
    rank: 'Master Node Level 4'
  },
  {
    id: 'member_002',
    userId: 'user_premium_001',
    package: 'Premium',
    joinDate: new Date('2023-02-20'),
    status: 'active',
    balance: 1000,
    rank: 'Master Node Level 3'
  },
  {
    id: 'member_003',
    userId: 'user_standard_001',
    package: 'Standard',
    joinDate: new Date('2023-03-10'),
    status: 'active',
    balance: 500,
    rank: 'Master Node Level 2'
  },
  {
    id: 'member_004',
    userId: 'user_basic_001',
    package: 'Basic',
    joinDate: new Date('2023-04-05'),
    status: 'active',
    balance: 200,
    rank: 'Master Node Level 1'
  },
  {
    id: 'member_005',
    userId: 'user_flexible_001',
    package: 'Flexible',
    joinDate: new Date('2023-05-12'),
    status: 'active',
    balance: 100,
    rank: 'Associate'
  }
];

const MOCK_SETTLEMENTS: M13ExitSettlement[] = [
  {
    id: 'settlement_001',
    memberId: 'member_001',
    joinDate: new Date('2022-01-15'),
    m13Date: new Date('2023-02-15'),
    principal: 5000,
    package: 'VIP',
    usdt: 11700,
    cnyt: 6500,
    directBonus: 600,
    rollupBonus: 1299.87,
    globalPool: 364,
    totalExpense: 20463.87,
    basicRefund: -15463.87,
    minimumRefund: 750,
    finalRefund: 750,
    floorApplied: true,
    companyLoss: -16213.87,
    status: 'completed',
    createdAt: new Date('2023-02-15')
  }
];

/**
 * 마이그레이션 실행
 */
async function runMigration() {
  console.log('\n╔════════════════════════════════════════════════════════════╗');
  console.log('║ 📊 데이터 마이그레이션 시작 (Mock → DB)                ║');
  console.log('╚════════════════════════════════════════════════════════════╝\n');

  try {
    // Step 1: 데이터 검증
    console.log('📋 Step 1: 데이터 검증');
    console.log(`  ├─ 회원 데이터: ${MOCK_MEMBERS.length}개`);
    console.log(`  └─ 정산 데이터: ${MOCK_SETTLEMENTS.length}개\n`);

    const validMembers = validateMembers(MOCK_MEMBERS);
    const validSettlements = validateSettlements(MOCK_SETTLEMENTS);

    if (!validMembers || !validSettlements) {
      throw new Error('데이터 검증 실패');
    }

    console.log('✅ 데이터 검증 통과\n');

    // Step 2: 데이터 마이그레이션
    console.log('📥 Step 2: 데이터베이스로 마이그레이션');

    // Mock DB에 데이터 로드
    await db.seed(MOCK_MEMBERS, MOCK_SETTLEMENTS);

    console.log('✅ 데이터 마이그레이션 완료\n');

    // Step 3: 무결성 검사
    console.log('✔️  Step 3: 무결성 검사');

    const verification = await verifyMigration();

    if (!verification.success) {
      throw new Error(`무결성 검사 실패: ${verification.errors?.join(', ')}`);
    }

    console.log('✅ 무결성 검사 통과\n');

    // Step 4: 통계 생성
    console.log('📈 Step 4: 통계 생성');

    const stats = await generateStatistics();

    console.log(`  ├─ 총 회원수: ${stats.totalMembers}명`);
    console.log(`  ├─ 활성 회원: ${stats.activeMembers}명`);
    console.log(`  ├─ 정산된 회원: ${stats.completedMembers}명`);
    console.log(`  ├─ 총 잔액: $${stats.totalBalance.toFixed(2)}`);
    console.log(`  ├─ 총 환급: $${stats.totalRefunds.toFixed(2)}`);
    console.log(`  └─ 순 수익: $${stats.netRevenue.toFixed(2)}\n`);

    // 최종 결과
    console.log('╔════════════════════════════════════════════════════════════╗');
    console.log('║ 🎉 데이터 마이그레이션 완료!                              ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    return {
      success: true,
      migratedMembers: MOCK_MEMBERS.length,
      migratedSettlements: MOCK_SETTLEMENTS.length,
      statistics: stats
    };
  } catch (error) {
    console.error('\n❌ 마이그레이션 실패:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

/**
 * 회원 데이터 검증
 */
function validateMembers(members: Member[]): boolean {
  console.log('  ├─ 회원 데이터 검증 중...');

  for (const member of members) {
    // 필수 필드 확인
    if (!member.id || !member.userId || !member.package || !member.joinDate) {
      console.log(`    ❌ 필수 필드 누락: ${member.userId}`);
      return false;
    }

    // 패키지 유효성
    const validPackages = ['Flexible', 'Basic', 'Standard', 'Premium', 'VIP'];
    if (!validPackages.includes(member.package)) {
      console.log(`    ❌ 잘못된 패키지: ${member.package}`);
      return false;
    }

    // 잔액 유효성
    if (member.balance < 0) {
      console.log(`    ❌ 음수 잔액: ${member.userId}`);
      return false;
    }
  }

  console.log('  ├─ ✅ 회원 데이터 검증 완료');
  return true;
}

/**
 * 정산 데이터 검증
 */
function validateSettlements(settlements: M13ExitSettlement[]): boolean {
  console.log('  ├─ 정산 데이터 검증 중...');

  for (const settlement of settlements) {
    // 필수 필드 확인
    if (!settlement.id || !settlement.memberId || !settlement.principal) {
      console.log(`    ❌ 필수 필드 누락: ${settlement.id}`);
      return false;
    }

    // 최종환급 유효성
    if (settlement.finalRefund < settlement.minimumRefund) {
      console.log(
        `    ❌ 최종환급이 최소보장보다 작음: ${settlement.id}`
      );
      return false;
    }

    // 보장 로직 검증
    if (!settlement.floorApplied && settlement.finalRefund !== settlement.basicRefund) {
      console.log(`    ❌ 보장 적용 상태 불일치: ${settlement.id}`);
      return false;
    }
  }

  console.log('  ├─ ✅ 정산 데이터 검증 완료');
  return true;
}

/**
 * 마이그레이션 검증
 */
async function verifyMigration(): Promise<{ success: boolean; errors?: string[] }> {
  const errors: string[] = [];

  // 회원 수 확인
  const members = await db.findAllMembers();
  if (members.length !== MOCK_MEMBERS.length) {
    errors.push(`회원 수 불일치: ${members.length} != ${MOCK_MEMBERS.length}`);
  }

  // 정산 수 확인
  const settlements = await db.findAllSettlements();
  if (settlements.length !== MOCK_SETTLEMENTS.length) {
    errors.push(
      `정산 수 불일치: ${settlements.length} != ${MOCK_SETTLEMENTS.length}`
    );
  }

  // 정산액 검증
  for (const settlement of settlements) {
    if (settlement.finalRefund < settlement.minimumRefund) {
      errors.push(`정산액 오류: ${settlement.id}`);
    }
  }

  return {
    success: errors.length === 0,
    errors: errors.length > 0 ? errors : undefined
  };
}

/**
 * 통계 생성
 */
async function generateStatistics() {
  const members = await db.findAllMembers();
  const settlements = await db.findAllSettlements();

  const activeMembers = members.filter(m => m.status === 'active');
  const completedMembers = members.filter(m => m.status === 'completed');

  const totalBalance = members.reduce((sum, m) => sum + m.balance, 0);
  const totalRefunds = settlements.reduce((sum, s) => sum + s.finalRefund, 0);

  return {
    totalMembers: members.length,
    activeMembers: activeMembers.length,
    completedMembers: completedMembers.length,
    totalBalance,
    totalRefunds,
    netRevenue: totalBalance - totalRefunds
  };
}

// 직접 실행
runMigration()
  .then((result) => {
    process.exit(result.success ? 0 : 1);
  })
  .catch((error) => {
    console.error('❌ 마이그레이션 중 오류:', error);
    process.exit(1);
  });

export { runMigration };
