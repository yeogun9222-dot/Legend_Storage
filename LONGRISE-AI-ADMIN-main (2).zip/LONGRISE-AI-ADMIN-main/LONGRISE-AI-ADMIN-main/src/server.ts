/**
 * Express API Server
 * Phase 3: 백엔드 API 서버 (개발용)
 */

import express, { Express } from 'express';
import { db } from './db';
import apiRoutes from './api/routes';
import type { Member, M13ExitSettlement } from './types/M13Exit';

const app: Express = express();
const PORT = process.env.PORT || 5000;

// 개발용 Mock 데이터
const MOCK_MEMBERS: Member[] = [
  {
    id: 'member_001',
    userId: 'user_vip_001',
    package: 'VIP',
    joinDate: new Date('2023-01-15'),
    status: 'active',
    balance: 5000,
    rank: 'Master Node Level 4'
  },
  {
    id: 'member_002',
    userId: 'user_premium_001',
    package: 'Premium',
    joinDate: new Date('2023-02-20'),
    status: 'active',
    balance: 1000,
    rank: 'Master Node Level 3'
  },
  {
    id: 'member_003',
    userId: 'user_standard_001',
    package: 'Standard',
    joinDate: new Date('2023-03-10'),
    status: 'active',
    balance: 500,
    rank: 'Master Node Level 2'
  },
  {
    id: 'member_004',
    userId: 'user_basic_001',
    package: 'Basic',
    joinDate: new Date('2023-04-05'),
    status: 'active',
    balance: 200,
    rank: 'Master Node Level 1'
  },
  {
    id: 'member_005',
    userId: 'user_flexible_001',
    package: 'Flexible',
    joinDate: new Date('2023-05-12'),
    status: 'active',
    balance: 100,
    rank: 'Associate'
  }
];

const MOCK_SETTLEMENTS: M13ExitSettlement[] = [
  {
    id: 'settlement_001',
    memberId: 'member_001',
    joinDate: new Date('2022-01-15'),
    m13Date: new Date('2023-02-15'),
    principal: 5000,
    package: 'VIP',
    usdt: 11700,
    cnyt: 6500,
    directBonus: 600,
    rollupBonus: 1299.87,
    globalPool: 364,
    totalExpense: 20463.87,
    basicRefund: -15463.87,
    minimumRefund: 750,
    finalRefund: 750,
    floorApplied: true,
    companyLoss: -16213.87,
    status: 'completed',
    createdAt: new Date('2023-02-15')
  }
];

// 초기화: 서버 시작 시 Mock 데이터 로드
(async () => {
  try {
    await db.seed(MOCK_MEMBERS, MOCK_SETTLEMENTS);
    console.log('✅ Mock 데이터 로드 완료');
  } catch (error) {
    console.error('❌ Mock 데이터 로드 실패:', error);
  }
})();

// 미들웨어
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS 설정
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// 헬스 체크
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// API 라우트 등록
app.use('/api', apiRoutes);

// 에러 핸들러
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('❌ 서버 에러:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// 서버 시작
app.listen(PORT, () => {
  console.log(`\n╔════════════════════════════════════════════════════════════╗`);
  console.log(`║ 🚀 LONGRISE API Server (Phase 3)                         ║`);
  console.log(`║ 📍 http://localhost:${PORT}                          ║`);
  console.log(`║ 🔗 API Base: http://localhost:${PORT}/api                ║`);
  console.log(`╚════════════════════════════════════════════════════════════╝\n`);
  console.log('📊 Available Endpoints:');
  console.log('  ├─ GET  /api/health');
  console.log('  ├─ GET  /api/members');
  console.log('  ├─ POST /api/members');
  console.log('  ├─ GET  /api/members/:id');
  console.log('  ├─ PATCH /api/members/:id');
  console.log('  ├─ GET  /api/settlements');
  console.log('  ├─ GET  /api/settlements/:memberId');
  console.log('  ├─ POST /api/settlements');
  console.log('  ├─ GET  /api/m13-exit/pending');
  console.log('  ├─ POST /api/m13-exit/calculate');
  console.log('  ├─ POST /api/m13-exit/process');
  console.log('  ├─ GET  /api/statistics/members');
  console.log('  ├─ GET  /api/statistics/monthly/:month');
  console.log('  ├─ GET  /api/statistics/revenue');
  console.log('  └─ GET  /api/debug/data\n');
});

export default app;
