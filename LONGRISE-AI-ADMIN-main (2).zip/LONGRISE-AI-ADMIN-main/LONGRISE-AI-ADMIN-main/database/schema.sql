/**
 * LONGRISE V7.5 Database Schema
 * Phase 3: Mock → Production 마이그레이션
 *
 * 테이블:
 * 1. members - 회원 정보
 * 2. withdrawals - 출금 요청
 * 3. settlements - 정산 기록 (중도해지 + M13 EXIT)
 * 4. daily_revenue - 일일 수익 추적
 * 5. audit_logs - 감사 로그
 */

-- =============================================================================
-- 1. Members (회원)
-- =============================================================================
CREATE TABLE IF NOT EXISTS members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id VARCHAR(255) UNIQUE NOT NULL,

  -- 기본 정보
  package VARCHAR(50) NOT NULL CHECK (package IN ('Flexible', 'Basic', 'Standard', 'Premium', 'VIP')),
  balance DECIMAL(20, 2) NOT NULL DEFAULT 0,

  -- 상태
  status VARCHAR(50) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'paused')),
  rank VARCHAR(100),

  -- 날짜
  join_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exit_date TIMESTAMP,

  -- 메타데이터
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- 인덱스
  INDEX idx_members_status (status),
  INDEX idx_members_join_date (join_date),
  INDEX idx_members_user_id (user_id)
);

-- =============================================================================
-- 2. Withdrawals (출금)
-- =============================================================================
CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,

  -- 출금 정보
  amount DECIMAL(20, 2) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),

  -- 네트워크 정보
  network VARCHAR(50) DEFAULT 'TRC-20',
  wallet_address VARCHAR(255),

  -- 인증 정보
  kyc_status VARCHAR(50) DEFAULT 'verified',

  -- 날짜
  request_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approved_date TIMESTAMP,
  rejected_date TIMESTAMP,

  -- 메타데이터
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- 인덱스
  INDEX idx_withdrawals_member_id (member_id),
  INDEX idx_withdrawals_status (status),
  INDEX idx_withdrawals_request_date (request_date)
);

-- =============================================================================
-- 3. Settlements (정산)
-- =============================================================================
CREATE TABLE IF NOT EXISTS settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,

  -- 정산 타입
  settlement_type VARCHAR(50) NOT NULL CHECK (settlement_type IN ('EARLY_EXIT', 'M13_EXIT')),

  -- 원금 정보
  principal DECIMAL(20, 2) NOT NULL,
  package VARCHAR(50) NOT NULL,

  -- 지출 항목
  usdt DECIMAL(20, 2) NOT NULL,
  cnyt DECIMAL(20, 2) NOT NULL,
  direct_bonus DECIMAL(20, 2) NOT NULL,
  rollup_bonus DECIMAL(20, 2) NOT NULL,
  global_pool DECIMAL(20, 2) NOT NULL,
  total_expense DECIMAL(20, 2) NOT NULL,

  -- 정산 결과
  basic_refund DECIMAL(20, 2) NOT NULL,
  minimum_refund DECIMAL(20, 2) NOT NULL,
  final_refund DECIMAL(20, 2) NOT NULL,
  floor_applied BOOLEAN NOT NULL DEFAULT FALSE,
  company_loss DECIMAL(20, 2),

  -- 기간 정보
  months_elapsed INT,
  join_date TIMESTAMP,
  exit_date TIMESTAMP,

  -- 상태
  status VARCHAR(50) NOT NULL DEFAULT 'completed',

  -- 메타데이터
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- 인덱스
  INDEX idx_settlements_member_id (member_id),
  INDEX idx_settlements_type (settlement_type),
  INDEX idx_settlements_created_at (created_at)
);

-- =============================================================================
-- 4. Daily Revenue (일일 수익)
-- =============================================================================
CREATE TABLE IF NOT EXISTS daily_revenue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE UNIQUE NOT NULL,

  -- 수익 정보
  total_revenue DECIMAL(20, 2) NOT NULL DEFAULT 0,
  new_deposits DECIMAL(20, 2) NOT NULL DEFAULT 0,
  early_exits DECIMAL(20, 2) NOT NULL DEFAULT 0,
  m13_exits DECIMAL(20, 2) NOT NULL DEFAULT 0,

  -- 회원 통계
  new_members INT NOT NULL DEFAULT 0,
  completed_members INT NOT NULL DEFAULT 0,
  active_members INT NOT NULL DEFAULT 0,

  -- 메타데이터
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- 인덱스
  INDEX idx_daily_revenue_date (date)
);

-- =============================================================================
-- 5. Audit Logs (감사 로그)
-- =============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- 액션 정보
  action VARCHAR(255) NOT NULL,
  action_type VARCHAR(50),

  -- 사용자 정보
  user_id VARCHAR(255),
  member_id UUID REFERENCES members(id) ON DELETE SET NULL,

  -- 상세 정보
  package VARCHAR(50),
  join_date TIMESTAMP,
  exit_date TIMESTAMP,
  final_refund DECIMAL(20, 2),

  -- 실행 정보
  executed_by VARCHAR(255) DEFAULT 'SYSTEM_AUTO',
  ip_address VARCHAR(45),

  -- 추가 정보
  details JSON,

  -- 메타데이터
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- 인덱스
  INDEX idx_audit_logs_action (action),
  INDEX idx_audit_logs_member_id (member_id),
  INDEX idx_audit_logs_created_at (created_at),
  INDEX idx_audit_logs_executed_by (executed_by)
);

-- =============================================================================
-- Views (뷰)
-- =============================================================================

-- 활성 회원 통계
CREATE OR REPLACE VIEW active_members_summary AS
SELECT
  COUNT(*) as total_active,
  SUM(CASE WHEN package = 'Flexible' THEN 1 ELSE 0 END) as flexible_count,
  SUM(CASE WHEN package = 'Basic' THEN 1 ELSE 0 END) as basic_count,
  SUM(CASE WHEN package = 'Standard' THEN 1 ELSE 0 END) as standard_count,
  SUM(CASE WHEN package = 'Premium' THEN 1 ELSE 0 END) as premium_count,
  SUM(CASE WHEN package = 'VIP' THEN 1 ELSE 0 END) as vip_count,
  SUM(balance) as total_balance
FROM members
WHERE status = 'active';

-- M13 EXIT 대기 회원
CREATE OR REPLACE VIEW m13_exit_pending AS
SELECT
  m.id,
  m.user_id,
  m.package,
  m.balance,
  m.join_date,
  DATE_ADD(m.join_date, INTERVAL 13 MONTH) as m13_date,
  DATEDIFF(DATE_ADD(m.join_date, INTERVAL 13 MONTH), CURDATE()) as days_until_m13
FROM members m
WHERE m.status = 'active'
AND DATE_ADD(m.join_date, INTERVAL 13 MONTH) <= CURDATE();

-- 월간 정산 요약
CREATE OR REPLACE VIEW monthly_settlement_summary AS
SELECT
  DATE_TRUNC('month', created_at) as month,
  settlement_type,
  COUNT(*) as count,
  SUM(principal) as total_principal,
  SUM(final_refund) as total_refund,
  SUM(company_loss) as total_company_loss,
  AVG(CASE WHEN floor_applied THEN 1 ELSE 0 END) * 100 as floor_applied_rate
FROM settlements
GROUP BY DATE_TRUNC('month', created_at), settlement_type;

-- =============================================================================
-- 초기 데이터 (Optional - 개발 목적)
-- =============================================================================

-- 테스트 회원 데이터
INSERT INTO members (user_id, package, balance, status, rank)
VALUES
  ('test_user_001', 'VIP', 5000, 'active', 'Master Node Level 4'),
  ('test_user_002', 'Premium', 1000, 'active', 'Master Node Level 3'),
  ('test_user_003', 'Standard', 500, 'active', 'Master Node Level 2'),
  ('test_user_004', 'Basic', 200, 'active', 'Master Node Level 1'),
  ('test_user_005', 'Flexible', 100, 'active', 'Associate')
ON DUPLICATE KEY UPDATE balance = VALUES(balance);

-- 초기 수익 데이터
INSERT INTO daily_revenue (date, total_revenue, new_members, active_members)
VALUES (CURDATE(), 235000000, 12, 8542)
ON DUPLICATE KEY UPDATE total_revenue = VALUES(total_revenue);

-- =============================================================================
-- 프로시저 (Optional - 자동 정산용)
-- =============================================================================

-- M13 EXIT 자동 정산 프로시저
DELIMITER //

CREATE PROCEDURE sp_process_m13_exit()
BEGIN
  DECLARE v_member_id UUID;
  DECLARE v_package VARCHAR(50);
  DECLARE v_principal DECIMAL(20, 2);
  DECLARE v_months INT DEFAULT 13;

  -- 13개월 만기 회원 커서
  DECLARE member_cursor CURSOR FOR
    SELECT id, package, balance
    FROM members
    WHERE status = 'active'
    AND DATE_ADD(join_date, INTERVAL 13 MONTH) <= CURDATE();

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

  SET @done = 0;
  OPEN member_cursor;

  process_loop: LOOP
    FETCH member_cursor INTO v_member_id, v_package, v_principal;
    IF @done THEN LEAVE process_loop; END IF;

    -- 정산 생성 (실제 계산 로직은 애플리케이션에서 처리)
    INSERT INTO settlements (
      member_id, settlement_type, principal, package,
      usdt, cnyt, direct_bonus, rollup_bonus, global_pool, total_expense,
      basic_refund, minimum_refund, final_refund, floor_applied,
      months_elapsed, status
    ) VALUES (
      v_member_id, 'M13_EXIT', v_principal, v_package,
      0, 0, 0, 0, 0, 0,
      0, v_principal * 0.15, v_principal * 0.15, TRUE,
      13, 'completed'
    );

    -- 회원 상태 업데이트
    UPDATE members
    SET status = 'completed', exit_date = NOW(), updated_at = NOW()
    WHERE id = v_member_id;

  END LOOP;

  CLOSE member_cursor;
END//

DELIMITER ;

-- =============================================================================
-- 권한 설정 (선택사항)
-- =============================================================================

-- API 사용자 계정 (읽기 권한)
-- CREATE USER 'api_read'@'localhost' IDENTIFIED BY 'api_read_password';
-- GRANT SELECT ON longrise.* TO 'api_read'@'localhost';

-- 관리자 계정 (모든 권한)
-- CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin_password';
-- GRANT ALL PRIVILEGES ON longrise.* TO 'admin'@'localhost';

-- 커밋
-- FLUSH PRIVILEGES;
