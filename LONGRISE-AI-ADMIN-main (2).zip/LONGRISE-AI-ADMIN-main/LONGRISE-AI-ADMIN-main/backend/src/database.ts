/**
 * Mock Database - In-memory storage
 * In production, replace with MongoDB, PostgreSQL, etc.
 */

import { UserData, AdminUser, AuditLog } from './types.js';
import { v4 as uuidv4 } from 'uuid';

// In-memory storage
export const db = {
  users: [] as UserData[],
  admins: [] as AdminUser[],
  auditLogs: [] as AuditLog[],
};

// Initialize with mock data
export function initializeMockData() {
  db.users = [
    {
      id: 'user_001',
      nickname: 'GoldenDragon',
      name: 'Dragon Lee',
      email: 'dragon88@longrise.com',
      phone: '+82 10-1234-5678',
      rank: 'Blue Dragon',
      status: 'active',
      joinDate: '2024-12-15',
      balanceUSDT: 142500.50,
      lockedUSDT: 50000,
      balanceCNYT: 85000.00,
      totalAssets: 277500.50,
      package: 'Platinum',
      initialInvestment: 1000,
      investmentDate: '2024-12-15',
      sponsorId: 'user_admin',
      teamSize: 12,
      teamVol: 245000,
      bodyValue: 50000,
      kycLevel: 2,
      kycStatus: 'verified',
      kycUpdatedAt: '2024-12-20',
      pageface: true,
      mobileBinding: true,
      tradingPassword: 'hashed_password_123',
      hasSetTradingPassword: true,
      isTradingPasswordVerified: true,
      otp: true,
      lastLoginAt: '2026-04-22 18:00:00',
      distributorStatus: 'approved',
      distributorCode: 'GD_2024_001',
      distributorApprovedAt: '2025-01-10',
      createdAt: '2024-12-15',
      updatedAt: '2026-04-22',
    },
    {
      id: 'user_002',
      nickname: 'Investor_99',
      name: 'John Park',
      email: 'investor99@longrise.com',
      phone: '+82 10-9876-5432',
      rank: 'Red Dragon',
      status: 'active',
      joinDate: '2025-01-20',
      balanceUSDT: 85000.00,
      lockedUSDT: 25000,
      balanceCNYT: 45000.00,
      totalAssets: 155000.00,
      package: 'Premium',
      initialInvestment: 1000,
      investmentDate: '2025-01-20',
      sponsorId: 'user_001',
      teamSize: 5,
      teamVol: 120000,
      bodyValue: 30000,
      kycLevel: 2,
      kycStatus: 'verified',
      pageface: true,
      mobileBinding: false,
      tradingPassword: 'hashed_password_456',
      hasSetTradingPassword: true,
      otp: false,
      lastLoginAt: '2026-04-21 15:30:00',
      distributorStatus: 'pending',
      distributorCode: null,
      createdAt: '2025-01-20',
      updatedAt: '2026-04-21',
    },
  ];

  db.admins = [
    {
      id: 'admin_001',
      username: 'jake_admin',
      email: 'jake@longrise.com',
      name: '제이크 (총괄 관리자)',
      role: 'super',
      permissions: ['*'],
      isActive: true,
      createdAt: '2024-01-01',
      updatedAt: '2024-12-21',
      lastLogin: '2024-12-21 18:00:00',
    },
  ];
}

// Helper functions
export function findUserById(id: string): UserData | undefined {
  return db.users.find(u => u.id === id);
}

export function findUserByEmail(email: string): UserData | undefined {
  return db.users.find(u => u.email === email);
}

export function updateUser(id: string, updates: Partial<UserData>): UserData | null {
  const index = db.users.findIndex(u => u.id === id);
  if (index === -1) return null;

  const oldUser = db.users[index];
  db.users[index] = { ...oldUser, ...updates, updatedAt: new Date().toISOString() };
  return db.users[index];
}

export function createAuditLog(adminId: string, adminName: string, action: string, resource: 'user' | 'product' | 'transaction' | 'content' | 'system', resourceId: string, before: any, after: any): AuditLog {
  const log: AuditLog = {
    id: uuidv4(),
    adminId,
    adminName,
    action,
    resource,
    resourceId,
    changes: { before, after },
    status: 'success',
    timestamp: new Date().toISOString(),
  };

  db.auditLogs.push(log);
  return log;
}

export function getAuditLogs(resourceId?: string, limit: number = 50): AuditLog[] {
  let logs = db.auditLogs;
  if (resourceId) {
    logs = logs.filter(log => log.resourceId === resourceId);
  }
  return logs.slice(-limit).reverse();
}
