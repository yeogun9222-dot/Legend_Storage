/**
 * Admin Management Routes
 */

import { Router, Request, Response } from 'express';
import { db } from '../database.js';
import { AdminUser, ApiResponse } from '../types.js';

const router = Router();

// GET /api/admin/users - List all admins
router.get('/users', (req: Request, res: Response) => {
  const response: ApiResponse<AdminUser[]> = {
    success: true,
    data: db.admins,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// GET /api/admin/current - Get current admin info (mock)
router.get('/current', (req: Request, res: Response) => {
  // In real app, would get from JWT token
  const currentAdmin = db.admins[0];

  if (!currentAdmin) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'ADMIN_NOT_FOUND',
        message: 'Admin not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const response: ApiResponse<AdminUser> = {
    success: true,
    data: currentAdmin,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// GET /api/admin/audit-logs - Get system audit logs
router.get('/audit-logs', (req: Request, res: Response) => {
  const limit = Math.min(100, parseInt(req.query.limit as string) || 50);
  const logs = db.auditLogs.slice(-limit).reverse();

  const response: ApiResponse<typeof logs> = {
    success: true,
    data: logs,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

export default router;
