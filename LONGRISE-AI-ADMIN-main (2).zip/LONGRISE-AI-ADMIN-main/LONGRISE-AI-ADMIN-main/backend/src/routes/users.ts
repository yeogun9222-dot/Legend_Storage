/**
 * User Management Routes
 */

import { Router, Request, Response } from 'express';
import { db, findUserById, updateUser, createAuditLog, getAuditLogs } from '../database.js';
import { UserData, ApiResponse, PaginatedResponse } from '../types.js';
import { v4 as uuidv4 } from 'uuid';

const router = Router();

// GET /api/users - List all users with pagination
router.get('/', (req: Request, res: Response) => {
  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const pageSize = Math.max(1, Math.min(100, parseInt(req.query.pageSize as string) || 20));
  const search = (req.query.search as string) || '';

  let users = db.users;

  // Filter by search term
  if (search) {
    users = users.filter(u =>
      u.nickname.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.name?.toLowerCase().includes(search.toLowerCase())
    );
  }

  const total = users.length;
  const hasMore = page * pageSize < total;
  const start = (page - 1) * pageSize;
  const paginatedUsers = users.slice(start, start + pageSize);

  const response: ApiResponse<PaginatedResponse<UserData>> = {
    success: true,
    data: {
      data: paginatedUsers,
      total,
      page,
      pageSize,
      hasMore,
    },
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// GET /api/users/:id - Get user details
router.get('/:id', (req: Request, res: Response) => {
  const user = findUserById(req.params.id);

  if (!user) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: 'User not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const response: ApiResponse<UserData> = {
    success: true,
    data: user,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// PUT /api/users/:id/balance - Adjust user balance (ADMIN)
router.put('/:id/balance', (req: Request, res: Response) => {
  const { currency, amount, reason, adminId, adminName } = req.body;
  const user = findUserById(req.params.id);

  if (!user) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: 'User not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const oldBalance = currency === 'USDT' ? user.balanceUSDT : user.balanceCNYT;
  const newBalance = oldBalance + amount;

  const updates: Partial<UserData> = {
    [currency === 'USDT' ? 'balanceUSDT' : 'balanceCNYT']: Math.max(0, newBalance),
  };

  const updated = updateUser(req.params.id, updates);

  // Create audit log
  if (adminId && adminName) {
    createAuditLog(
      adminId,
      adminName,
      `잔액 조정 (${currency})`,
      'user',
      req.params.id,
      { [currency]: oldBalance },
      { [currency]: newBalance }
    );
  }

  const response: ApiResponse<UserData> = {
    success: true,
    data: updated!,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// PUT /api/users/:id/restrictions - Set user restrictions (ADMIN)
router.put('/:id/restrictions', (req: Request, res: Response) => {
  const { restrictionType, enabled, reason, adminId, adminName } = req.body;
  const user = findUserById(req.params.id);

  if (!user) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: 'User not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const restrictions = user.restrictions || {};
  const oldRestrictions = { ...restrictions };

  if (restrictionType === 'withdrawal') {
    restrictions.isWithdrawalBlocked = enabled;
  } else if (restrictionType === 'account') {
    restrictions.isAccountLocked = enabled;
  } else if (restrictionType === 'freeze') {
    restrictions.isFrozen = enabled;
  }

  const updated = updateUser(req.params.id, { restrictions });

  // Create audit log
  if (adminId && adminName) {
    createAuditLog(
      adminId,
      adminName,
      `제한 조건 설정 (${restrictionType})`,
      'user',
      req.params.id,
      { restrictions: oldRestrictions },
      { restrictions }
    );
  }

  const response: ApiResponse<UserData> = {
    success: true,
    data: updated!,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// PUT /api/users/:id/kyc - Reset KYC (ADMIN)
router.put('/:id/kyc', (req: Request, res: Response) => {
  const { adminId, adminName } = req.body;
  const user = findUserById(req.params.id);

  if (!user) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: 'User not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const oldKyc = { kycLevel: user.kycLevel, kycStatus: user.kycStatus };
  const updated = updateUser(req.params.id, {
    kycLevel: 0,
    kycStatus: 'pending' as const,
    pageface: false,
    mobileBinding: false,
  });

  // Create audit log
  if (adminId && adminName) {
    createAuditLog(
      adminId,
      adminName,
      'KYC 초기화',
      'user',
      req.params.id,
      oldKyc,
      { kycLevel: 0, kycStatus: 'pending' }
    );
  }

  const response: ApiResponse<UserData> = {
    success: true,
    data: updated!,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// PUT /api/users/:id/ban - Permanently ban user (ADMIN)
router.put('/:id/ban', (req: Request, res: Response) => {
  const { adminId, adminName } = req.body;
  const user = findUserById(req.params.id);

  if (!user) {
    const response: ApiResponse<null> = {
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: 'User not found',
      },
      timestamp: new Date().toISOString(),
    };
    return res.status(404).json(response);
  }

  const oldStatus = user.status;
  const updated = updateUser(req.params.id, { status: 'banned' });

  // Create audit log
  if (adminId && adminName) {
    createAuditLog(
      adminId,
      adminName,
      '계정 영구 BAN',
      'user',
      req.params.id,
      { status: oldStatus },
      { status: 'banned' }
    );
  }

  const response: ApiResponse<UserData> = {
    success: true,
    data: updated!,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// GET /api/users/:id/audit-logs - Get audit logs for user
router.get('/:id/audit-logs', (req: Request, res: Response) => {
  const logs = getAuditLogs(req.params.id);

  const response: ApiResponse<typeof logs> = {
    success: true,
    data: logs,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

export default router;
