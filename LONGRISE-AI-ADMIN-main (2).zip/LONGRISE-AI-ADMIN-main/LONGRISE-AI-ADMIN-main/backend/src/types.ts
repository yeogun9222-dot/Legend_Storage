/**
 * Backend Types - Shared with Frontend
 */

export interface UserData {
  id: string;
  nickname: string;
  name?: string;
  email: string;
  phone?: string;
  rank: string;
  status: 'active' | 'inactive' | 'banned' | 'suspended';
  joinDate: string;
  balanceUSDT: number;
  lockedUSDT?: number;
  balanceCNYT: number;
  totalAssets?: number;
  package: string;
  initialInvestment: number;
  investmentDate?: string;
  sponsorId: string;
  teamSize: number;
  teamVol: number;
  bodyValue?: number;
  kycLevel: number;
  kycStatus?: 'pending' | 'verified' | 'rejected';
  kycUpdatedAt?: string;
  pageface?: boolean;
  mobileBinding?: boolean;
  tradingPassword?: string;
  hasSetTradingPassword: boolean;
  isTradingPasswordVerified?: boolean;
  otp?: boolean;
  lastLoginAt?: string;
  distributorStatus: 'none' | 'pending' | 'approved';
  distributorCode?: string | null;
  distributorApprovedAt?: string;
  restrictions?: {
    isWithdrawalBlocked?: boolean;
    isAccountLocked?: boolean;
    isFrozen?: boolean;
    blockReason?: string;
    blockExpiresAt?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  name: string;
  role: 'super' | 'finance' | 'community' | 'content';
  permissions: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

export interface AuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  resource: 'user' | 'product' | 'transaction' | 'content' | 'system';
  resourceId: string;
  changes: {
    before: Record<string, any>;
    after: Record<string, any>;
  };
  status: 'success' | 'failure';
  errorMessage?: string;
  timestamp: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}
