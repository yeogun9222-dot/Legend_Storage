/**
 * LONGRISE Admin Panel API Server
 * Express.js + TypeScript
 */

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { initializeMockData } from './database.js';
import userRoutes from './routes/users.js';
import adminRoutes from './routes/admin.js';

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize mock data
initializeMockData();

// Middleware
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// API Routes
app.use('/api/users', userRoutes);
app.use('/api/admin', adminRoutes);

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Root endpoint
app.get('/', (req: Request, res: Response) => {
  res.json({
    name: 'LONGRISE Admin Panel API',
    version: '1.0.0',
    endpoints: {
      users: '/api/users',
      admin: '/api/admin',
      health: '/health',
    },
  });
});

// Error handling middleware
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: {
      code: 'INTERNAL_ERROR',
      message: err.message || 'Internal server error',
    },
    timestamp: new Date().toISOString(),
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: {
      code: 'NOT_FOUND',
      message: 'Endpoint not found',
    },
    timestamp: new Date().toISOString(),
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║  LONGRISE Admin Panel API Server       ║
║  Running on http://localhost:${PORT}     ║
╚════════════════════════════════════════╝

Available Endpoints:
  GET  /api/users              - List all users
  GET  /api/users/:id          - Get user details
  PUT  /api/users/:id/balance  - Adjust user balance
  PUT  /api/users/:id/restrictions - Set restrictions
  PUT  /api/users/:id/kyc      - Reset KYC
  PUT  /api/users/:id/ban      - Ban user
  GET  /api/users/:id/audit-logs - Get user audit logs

  GET  /api/admin/users        - List admins
  GET  /api/admin/current      - Get current admin
  GET  /api/admin/audit-logs   - Get system audit logs

  GET  /health                 - Health check
  `);
});
