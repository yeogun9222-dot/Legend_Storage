# LONGRISE Admin Panel API

Express.js + TypeScript backend for the LONGRISE Admin Panel.

## Setup

```bash
cd backend
npm install
npm run dev
```

Server runs on `http://localhost:5000`

## API Endpoints

### Users Management

#### GET /api/users
List all users with pagination
- Query params: `page`, `pageSize`, `search`
- Response: Paginated user list

#### GET /api/users/:id
Get user details

#### PUT /api/users/:id/balance
Adjust user balance (ADMIN)
```json
{
  "currency": "USDT",
  "amount": 1000,
  "reason": "Manual adjustment",
  "adminId": "admin_001",
  "adminName": "Jake"
}
```

#### PUT /api/users/:id/restrictions
Set user restrictions (ADMIN)
```json
{
  "restrictionType": "withdrawal|account|freeze",
  "enabled": true,
  "reason": "Suspicious activity",
  "adminId": "admin_001",
  "adminName": "Jake"
}
```

#### PUT /api/users/:id/kyc
Reset KYC level (ADMIN)
```json
{
  "adminId": "admin_001",
  "adminName": "Jake"
}
```

#### PUT /api/users/:id/ban
Permanently ban user (ADMIN)
```json
{
  "adminId": "admin_001",
  "adminName": "Jake"
}
```

#### GET /api/users/:id/audit-logs
Get audit logs for specific user

### Admin Management

#### GET /api/admin/users
List all admin users

#### GET /api/admin/current
Get current logged-in admin

#### GET /api/admin/audit-logs
Get system-wide audit logs
- Query params: `limit` (default 50, max 100)

## Data Models

### UserData
- id: string
- nickname: string
- email: string
- rank: string
- status: active | inactive | banned | suspended
- balanceUSDT: number
- balanceCNYT: number
- kycLevel: number
- restrictions: object
- ...and more

### AdminUser
- id: string
- username: string
- email: string
- role: super | finance | community | content
- permissions: string[]

### AuditLog
- id: string
- adminId: string
- action: string
- resource: user | product | transaction | content | system
- changes: { before, after }
- timestamp: string

## Response Format

All API responses follow this format:

```json
{
  "success": true,
  "data": { ... },
  "timestamp": "2026-04-22T12:00:00.000Z"
}
```

Error responses:
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description"
  },
  "timestamp": "2026-04-22T12:00:00.000Z"
}
```

## Environment Variables

- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment (development/production)

## Future Enhancements

1. Database Integration (MongoDB/PostgreSQL)
2. JWT Authentication
3. Rate Limiting
4. Request Validation
5. Advanced Filtering & Search
6. Real-time WebSocket Updates
7. Transaction History
8. Product Management
9. P2P Transaction Monitoring
10. Commission Calculation
