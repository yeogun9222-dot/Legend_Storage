// 15% 최소환급금 계산 함수
function calculateEarlyExit(principal, monthsElapsed, pkg) {
  const usedtRate = { Flexible: 4, Basic: 7, Standard: 9, Premium: 11, VIP: 18 }[pkg] || 9;
  const cnytRatio = { Basic: 2, Standard: 4, Premium: 6, VIP: 10 }[pkg] || 2;

  const usdt = (principal * usedtRate * monthsElapsed) / 100;
  const cnytValue = (principal * cnytRatio * monthsElapsed) / 100;
  const directBonus = principal * 0.12;
  const rollupBonus = usdt * 0.1111;
  const globalPool = (usdt + cnytValue) * 0.02;
  const totalExpense = usdt + cnytValue + directBonus + rollupBonus + globalPool;

  let earlyExitFee = 0;
  if (monthsElapsed <= 6) earlyExitFee = principal * 0.30;
  else if (monthsElapsed <= 9) earlyExitFee = principal * 0.20;
  else if (monthsElapsed <= 11) earlyExitFee = principal * 0.15;
  else earlyExitFee = principal * 0.10;

  const basicRefund = principal - totalExpense - earlyExitFee;
  const minimumRefund = principal * 0.15;
  const finalRefund = Math.max(basicRefund, minimumRefund);

  return {
    principal,
    basicRefund: Math.round(basicRefund * 100) / 100,
    minimumRefund: Math.round(minimumRefund * 100) / 100,
    finalRefund: Math.round(finalRefund * 100) / 100,
    floorApplied: finalRefund > basicRefund
  };
}

const testCases = [
  { id: 'TC-1-1', p: 100, m: 3, pkg: 'Flexible', desc: 'Flexible M1-3' },
  { id: 'TC-1-4', p: 100, m: 11, pkg: 'Flexible', desc: 'Flexible M10-12' },
  { id: 'TC-2-1', p: 200, m: 3, pkg: 'Basic', desc: 'Basic M1-3' },
  { id: 'TC-2-2', p: 200, m: 6, pkg: 'Basic', desc: 'Basic M4-6' },
  { id: 'TC-3-1', p: 500, m: 3, pkg: 'Standard', desc: 'Standard M1-3' },
  { id: 'TC-3-4', p: 500, m: 12, pkg: 'Standard', desc: 'Standard M10-12' },
  { id: 'TC-4-1', p: 1000, m: 3, pkg: 'Premium', desc: 'Premium M1-3' },
  { id: 'TC-4-4', p: 1000, m: 12, pkg: 'Premium', desc: 'Premium M10-12' },
  { id: 'TC-5-1', p: 5000, m: 3, pkg: 'VIP', desc: 'VIP M1-3' },
  { id: 'TC-5-4', p: 5000, m: 13, pkg: 'VIP', desc: 'VIP M13 EXIT' }
];

console.log('\n✅ PayoutEngine 15% 최소환급금 보장 검증 (샘플 10개)\n');
console.log('='.repeat(80));

let applyCount = 0;
let totalLoss = 0;

testCases.forEach(tc => {
  const result = calculateEarlyExit(tc.p, tc.m, tc.pkg);
  const status = result.floorApplied ? '⭕ 보장적용' : '❌ 미적용';
  console.log(`${tc.id} | ${tc.desc.padEnd(20)} | 최종환급: $${result.finalRefund.toString().padStart(7)} | ${status}`);
  
  if (result.floorApplied) {
    applyCount++;
    const loss = result.minimumRefund - result.basicRefund;
    totalLoss += loss;
  }
});

console.log('='.repeat(80));
console.log(`\n📊 결과 요약:`);
console.log(`   ✅ 보장적용: ${applyCount}개 / ${testCases.length}개`);
console.log(`   💰 총 회사손실(보장): $${totalLoss.toFixed(2)}`);
console.log(`   🎯 15% 최소환급금 보장: 정상 작동 ✅\n`);
